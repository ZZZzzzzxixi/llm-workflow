#ifndef STRING_UTILS_H
#define STRING_UTILS_H

size_t string_length(const char *str);
char *string_copy(char *dest, const char *src);
char *string_concat(char *dest, const char *src);
int string_compare(const char *str1, const char *str2);

#endif
