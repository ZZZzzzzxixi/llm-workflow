#include "calculator.h"

int add(int a, int b) {
    return a + b;
}

int subtract(int a, int b) {
    return a - b;
}

int multiply(int a, int b) {
    return a * b;
}

int divide(int dividend, int divisor) {
    if (divisor == 0) return 0;
    return dividend / divisor;
}
