#include "string_utils.h"

size_t string_length(const char *str) {
    if (!str) return 0;
    size_t len = 0;
    while (str[len]) len++;
    return len;
}

char *string_copy(char *dest, const char *src) {
    if (!dest || !src) return NULL;
    char *d = dest;
    while ((*d++ = *src++));
    return dest;
}

char *string_concat(char *dest, const char *src) {
    if (!dest || !src) return NULL;
    while (*dest) dest++;
    while ((*dest++ = *src++));
    return dest - string_length(src) - 1;
}

int string_compare(const char *str1, const char *str2) {
    if (!str1 || !str2) return (str1 == str2) ? 0 : (str1 ? 1 : -1);
    while (*str1 && *str2 && *str1 == *str2) {
        str1++;
        str2++;
    }
    return *str1 - *str2;
}
