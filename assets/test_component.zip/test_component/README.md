# Test Component

测试用的C语言组件库。

## 目录结构
- include/: 头文件
- src/: 源文件
- lib/: 库文件

## 功能
- 计算器模块
- 字符串工具模块
