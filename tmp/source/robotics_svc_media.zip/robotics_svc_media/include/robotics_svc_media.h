#ifndef __ROBOTICS_SVC_MEDIA_H__
#define __ROBOTICS_SVC_MEDIA_H__


#ifdef __cplusplus
extern "C" {
#endif

#include <tuya_error_code.h>
#include "tal_video_enc.h"

OPERATE_RET ty_robot_media_init(void);

OPERATE_RET robotics_svc_media_vision_init(void);

/**
 * @brief 获取一帧rgb数据
 * @param[in out] frame:  输出rgb数据帧
 * @return OPERATE_RET: 0 成功，其余错误码表示失败
 */
OPERATE_RET robotics_svc_media_pic_get(TKL_VENC_FRAME_T* frame);
 
#ifdef __cplusplus
} // extern "C"
#endif

#endif // __ROBOTICS_SVC_MEDIA_H__

