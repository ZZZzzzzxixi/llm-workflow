# robotics_svc_media 模块

## 简介

robotics_svc_media模块是一个基于C语言开发的视觉处理、音频处理、云端连接组件，本文档由代码分析工具自动生成。

本组件提供了完整的C语言API接口，支持图像采集与预处理，支持目标检测与识别，支持物体检测算法，支持实时视频分析，支持音频数据采集。组件采用模块化设计，支持多线程并发处理，适用于嵌入式系统和应用开发场景。

本文档详细介绍了组件的目录结构、API接口、函数调用关系和执行流程，帮助开发者快速理解和使用该组件。

## 目录结构

```
robotics_svc_media/
├── robotics_svc_media/
│   └── include/                        # 公共 API 头文件
│       ├── robotics_svc_media.h        # 头文件
│   └── src/                            # 实现文件
│       ├── media_stream/
│       │   ├── ty_media_audio.c        # 源文件
│       │   ├── ty_media_audio.h        # 头文件
│       │   ├── ty_media_base.c         # 源文件
│       │   ├── ty_media_base.h         # 头文件
│       │   ├── ty_media_init.c         # 源文件
│       │   ├── ty_media_vision.c       # 源文件
│       │   ├── ty_media_vision.h       # 头文件
│       ├── object_detector/
│       │   └── include/                # 公共 API 头文件
│       │       ├── object_detector_api.h # 头文件
│       │       ├── object_detector_config.h # 头文件
│       │   └── input/                  # 输入数据
│       │       ├── cat.jpg
│       │       ├── overcast.png
│       │   └── model/                  # 模型文件
│       │       ├── cat_onnx_fixed.sim_sgsimg.img
│       │       ├── coco_80_labels_list.txt
│       │       ├── onnx_fixed.sim_sgsimg_1016.img
│       │       ├── yolov5.rknn
│       │   └── opencv/                 # [第三方库，略过详细说明]
│       │   └── src/                    # 实现文件
│       │       ├── detector_config.h   # 头文件
│       │       ├── detector_types.cpp  # 源文件
│       │       ├── detector_types.h    # 头文件
│       │       ├── detector_utils.cpp  # 源文件
│       │       ├── detector_utils.h    # 头文件
│       │       ├── inference_engine.h  # 头文件
│       │       ├── letterbox_preprocessor.cpp # 源文件
│       │       ├── object_detector_api.cpp # 源文件
│       │       ├── postprocessor.h     # 头文件
│       │       ├── preprocessor.h      # 头文件
│       │       ├── tkl_npu_engine.cpp  # 源文件
│       │       ├── yolo_detector.cpp   # 源文件
│       │       ├── yolo_detector.h     # 头文件
│       │       ├── yolov5_postprocessor.cpp # 源文件
│       │   └── README.md
│   └── .gitignore
│   └── README.md
│   └── local.mk
```


## API 参考

## 头文件函数详细说明

### robotics_svc_media/src/object_detector/include/object_detector_api.h

#### 函数: `OBJECT_DETECTOR_CONFIG_T object_detector_get_default_config(void)`

| 项目 | 说明 |
|------|------|
| **函数名称** | `OBJECT_DETECTOR_CONFIG_T object_detector_get_default_config(void)` |
| **输入参数** | 无 |
| **返回值** | `OBJECT_DETECTOR_CONFIG_T`: 默认配置结构体 |
| **功能描述** | 获取目标检测器的默认配置，可基于该配置修改部分参数后传给 `object_detector_init()` |

**调用示例**：
```c
// 获取默认配置并修改置信度阈值
OBJECT_DETECTOR_CONFIG_T config = object_detector_get_default_config();
config.conf_threshold = 0.3; // 将置信度阈值从默认0.25调整为0.3
```

---

#### 函数: `OPERATE_RET object_detector_init(const char* model_path, const char* label_path, const OBJECT_DETECTOR_CONFIG_T* config)`

| 项目 | 说明 |
|------|------|
| **函数名称** | `OPERATE_RET object_detector_init(const char* model_path, const char* label_path, const OBJECT_DETECTOR_CONFIG_T* config)` |
| **输入参数** | `const char* model_path`: 模型文件路径<br>`const char* label_path`: 标签文件路径（传NULL使用默认路径）<br>`const OBJECT_DETECTOR_CONFIG_T* config`: 配置参数（传NULL使用默认配置） |
| **返回值** | `OPERATE_RET`: 0 成功，其余错误码表示失败 |
| **功能描述** | 初始化目标检测器，必须在使用其他API前调用，且只能调用一次 |

**调用示例**：
```c
// 使用默认配置初始化检测器
OPERATE_RET ret = object_detector_init(
    "/tuya/models/yolov5s.tflite",
    NULL, // 使用默认标签路径
    NULL  // 使用默认配置
);
if (ret != OPRT_OK) {
    PR_ERR("Detector init failed: %d", ret);
}
```

---

#### 函数: `int object_detector_detect(const unsigned char* image_data, int width, int height, OBJECT_DETECTION_LIST_T* results)`

| 项目 | 说明 |
|------|------|
| **函数名称** | `int object_detector_detect(const unsigned char* image_data, int width, int height, OBJECT_DETECTION_LIST_T* results)` |
| **输入参数** | `const unsigned char* image_data`: RGB图像数据指针<br>`int width`: 图像宽度<br>`int height`: 图像高度 |
| **输出参数** | `OBJECT_DETECTION_LIST_T* results`: 检测结果列表 |
| **返回值** | `int`: 0 成功，其余错误码表示失败 |
| **功能描述** | 检测RGB图像中的目标，调用前必须先初始化检测器 |

**调用示例**：
```c
// 从RGB图像数据检测目标
unsigned char* rgb_data = get_rgb_image(); // 假设已实现获取RGB图像的函数
int width = 640, height = 480;
OBJECT_DETECTION_LIST_T results;

int ret = object_detector_detect(rgb_data, width, height, &results);
if (ret == 0) {
    PR_INFO("Detected %d objects", results.count);
    for (int i = 0; i < results.count; i++) {
        const char* class_name = object_detector_get_class_name(results.results[i].class_id);
        PR_INFO("Object %d: %s (conf: %.2f)", i+1, class_name, results.results[i].confidence);
    }
}
```

---

#### 函数: `int object_detector_detect_from_stream(OBJECT_DETECTION_LIST_T* results)`

| 项目 | 说明 |
|------|------|
| **函数名称** | `int object_detector_detect_from_stream(OBJECT_DETECTION_LIST_T* results)` |
| **输出参数** | `OBJECT_DETECTION_LIST_T* results`: 检测结果列表 |
| **返回值** | `int`: 0 成功，其余错误码表示失败 |
| **功能描述** | 从视频流自动获取图像并检测目标（内部调用 `tuya_get_pic_rgb()` 获取图像） |

**调用示例**：
```c
// 从视频流检测目标
OBJECT_DETECTION_LIST_T stream_results;
int ret = object_detector_detect_from_stream(&stream_results);
if (ret == 0) {
    PR_INFO("Stream detection: %d objects found", stream_results.count);
}
```

---

#### 函数: `int object_detector_get_performance(OBJECT_DETECTOR_PERF_T* perf)`

| 项目 | 说明 |
|------|------|
| **函数名称** | `int object_detector_get_performance(OBJECT_DETECTOR_PERF_T* perf)` |
| **输出参数** | `OBJECT_DETECTOR_PERF_T* perf`: 性能统计数据 |
| **返回值** | `int`: 0 成功，其余错误码表示失败 |
| **功能描述** | 获取检测器的性能统计数据，包括预处理、推理、后处理时间及帧率 |

**调用示例**：
```c
// 获取性能统计
OBJECT_DETECTOR_PERF_T perf;
int ret = object_detector_get_performance(&perf);
if (ret == 0) {
    PR_INFO("Performance: Total time=%.3fs, FPS=%.1f", perf.total_time, perf.fps);
}
```

---

#### 函数: `const char* object_detector_get_class_name(int class_id)`

| 项目 | 说明 |
|------|------|
| **函数名称** | `const char* object_detector_get_class_name(int class_id)` |
| **输入参数** | `int class_id`: 类别ID |
| **返回值** | `const char*`: 类别名称字符串，失败返回 "unknown" |
| **功能描述** | 根据类别ID获取对应的类别名称（如COCO数据集的类别名） |

**调用示例**：
```c
// 获取类别ID对应的名称
int class_id = 0; // COCO数据集中0对应person
const char* class_name = object_detector_get_class_name(class_id);
PR_INFO("Class ID %d: %s", class_id, class_name); // 输出 "Class ID 0: person"
```

---

#### 函数: `int object_detector_update_config(const OBJECT_DETECTOR_CONFIG_T* config)`

| 项目 | 说明 |
|------|------|
| **函数名称** | `int object_detector_update_config(const OBJECT_DETECTOR_CONFIG_T* config)` |
| **输入参数** | `const OBJECT_DETECTOR_CONFIG_T* config`: 新的配置参数 |
| **返回值** | `int`: 0 成功，其余错误码表示失败 |
| **功能描述** | 动态更新检测器的配置参数（如置信度阈值、NMS阈值等） |

**调用示例**：
```c
// 动态更新检测阈值
OBJECT_DETECTOR_CONFIG_T new_config = object_detector_get_default_config();
new_config.nms_threshold = 0.5; // 调整NMS阈值
int ret = object_detector_update_config(&new_config);
if (ret == 0) {
    PR_INFO("Detector config updated successfully");
}
```

---

#### 函数: `int object_detector_deinit(void)`

| 项目 | 说明 |
|------|------|
| **函数名称** | `int object_detector_deinit(void)` |
| **输入参数** | 无 |
| **返回值** | `int`: 0 成功，其余错误码表示失败 |
| **功能描述** | 释放目标检测器的资源，结束后需重新调用 `object_detector_init()` 才能再次使用 |

**调用示例**：
```c
// 释放检测器资源
int ret = object_detector_deinit();
if (ret == 0) {
    PR_INFO("Detector deinitialized successfully");
}
```

---

### robotics_svc_media/include/robotics_svc_media.h

#### 函数: `OPERATE_RET ty_robot_media_init(void)`

| 项目 | 说明 |
|------|------|
| **函数名称** | `OPERATE_RET ty_robot_media_init(void)` |
| **输入参数** | 无 |
| **返回值** | `OPERATE_RET`: 0 成功，其余错误码表示失败 |
| **功能描述** | 初始化机器人媒体服务，包括音视频SDK、存储等组件 |

**调用示例**：
```c
// 初始化机器人媒体服务
OPERATE_RET ret = ty_robot_media_init();
if (ret != OPRT_OK) {
    PR_ERR("Media service init failed: %d", ret);
}
```

---

#### 函数: `OPERATE_RET robotics_svc_media_init(void)`

| 项目 | 说明 |
|------|------|
| **函数名称** | `OPERATE_RET robotics_svc_media_init(void)` |
| **输入参数** | 无 |
| **返回值** | `OPERATE_RET`: 0 成功，其余错误码表示失败 |
| **功能描述** | 初始化媒体视觉相关组件（如摄像头、图像预处理等） |

**调用示例**：
```c
// 初始化媒体视觉组件
OPERATE_RET ret = robotics_svc_media_init();
if (ret != OPRT_OK) {
    PR_ERR("Media vision init failed: %d", ret);
}
```

---

#### 函数: `OPERATE_RET robotics_svc_media_pic_get(TKL_VENC_FRAME_T* frame)`

| 项目 | 说明 |
|------|------|
| **函数名称** | `OPERATE_RET robotics_svc_media_pic_get(TKL_VENC_FRAME_T* frame)` |
| **输入输出参数** | `TKL_VENC_FRAME_T* frame`: 输出RGB图像数据帧 |
| **返回值** | `OPERATE_RET`: 0 成功，其余错误码表示失败 |
| **功能描述** | 获取一帧RGB格式的图像数据 |

**调用示例**：
```c
// 获取RGB图像帧
TKL_VENC_FRAME_T frame;
OPERATE_RET ret = robotics_svc_media_pic_get(&frame);
if (ret == OPRT_OK) {
    PR_INFO("Got image frame: width=%d, height=%d", frame.width, frame.height);
    // 使用frame.data处理图像...
}
```

---

### robotics_svc_media/src/media_stream/include/ty_media_audio.h

#### 函数: `OPERATE_RET robotics_svc_media_audio_init(void)`

| 项目 | 说明 |
|------|------|
| **函数名称** | `OPERATE_RET robotics_svc_media_audio_init(void)` |
| **输入参数** | 无 |
| **返回值** | `OPERATE_RET`: 0 成功，其余错误码表示失败 |
| **功能描述** | 初始化音频服务，包括音频采集、编码等组件 |

**调用示例**：
```c
// 初始化音频服务
OPERATE_RET ret = robotics_svc_media_audio_init();
if (ret != OPRT_OK) {
    PR_ERR("Audio service init failed: %d", ret);
}
```

---

#### 函数: `OPERATE_RET robotics_svc_media_audio_thrd_init(void)`

| 项目 | 说明 |
|------|------|
| **函数名称** | `OPERATE_RET robotics_svc_media_audio_thrd_init(void)` |
| **输入参数** | 无 |
| **返回值** | `OPERATE_RET`: 0 成功，其余错误码表示失败 |
| **功能描述** | 初始化音频采集处理线程，启动音频流任务 |

**调用示例**：
```c
// 初始化音频采集线程
OPERATE_RET ret = robotics_svc_media_audio_thrd_init();
if (ret != OPRT_OK) {
    PR_ERR("Audio thread init failed: %d", ret);
}
```

---

#### 函数: `int Start_Audio_Output(void)`

| 项目 | 说明 |
|------|------|
| **函数名称** | `int Start_Audio_Output(void)` |
| **输入参数** | 无 |
| **返回值** | `int`: 0 成功，-1 失败 |
| **功能描述** | 放音测试函数，从指定PCM文件读取音频数据并播放 |

**调用示例**：
```c
// 启动音频输出测试
int ret = Start_Audio_Output();
if (ret == 0) {
    PR_INFO("Audio output test started successfully");
} else {
    PR_ERR("Audio output test failed");
}
```

## 函数调用关系

## 函数调用关系分析


### 代码执行流程


#### 1. 初始化阶段


**入口函数列表**
- `ty_robot_media_init`：媒体SDK初始化（音视频参数配置、存储初始化）
- `robotics_svc_media_init`：视觉模块初始化（摄像头注册、硬件初始化、线程创建）


**主入口函数分析**  
- 函数名：`robotics_svc_media_init`  
- 主要操作：视觉模块核心初始化，包含线程创建  
  - 步骤1：调用 `robotics_svc_monocular_vision_init` 初始化单目视觉  
  - 步骤2：调用 `tuya_enable_storage_deal` 创建存储任务线程  


**初始化函数分析**  
- `robotics_svc_monocular_vision_init`：单目视觉初始化  
  - 调用：`__camera_register_to_nav_sdk`（摄像头注册到导航SDK）  
  - 调用：`__camera_hw_init`（摄像头硬件初始化）  
  - 调用：`__pic_sample_thrd_init`（图像采集线程初始化）  
  - 调用：`__pic_detect_thrd_init`（目标检测线程初始化）  

- `__camera_hw_init`：摄像头硬件初始化  
  - 调用：`tal_vi_init`（视频输入硬件初始化）  
  - 调用：`tal_venc_init`（视频编码硬件初始化）  
  - 调用：`robotics_svc_media_audio_init`（音频初始化）  

- `robotics_svc_media_audio_init`：音频初始化  
  - 调用：`tkl_ao_init`（音频输出硬件初始化）  
  - 调用：`tkl_ao_set_vol`（设置音量）  
  - 调用：`tkl_ao_start`（启动音频输出）  


**线程创建分析**  
- 线程1：`__sample_proc_task` - 图像采集线程（由 `__pic_sample_thrd_init` 创建）  
- 线程2：`__detect_proc_task` - 目标检测线程（由 `__pic_detect_thrd_init` 创建）  
- 线程3：`thread_md_proc` - 存储任务线程（由 `tuya_enable_storage_deal` 创建）  


#### 2. 运行阶段


**线程执行逻辑**  

**线程1执行（图像采集线程：`__sample_proc_task`）**  
- 线程函数：`__sample_proc_task`  
- while循环处理逻辑：  
  - 步骤1：检查 `vision_enable_oper_type` 是否为TRUE，否则休眠500ms  
  - 步骤2：调用 `tal_venc_get_frame` 获取视频帧数据  
  - 步骤3：设置 `g_pro_hdl.detect_stat = TRUE` 触发检测  
  - 步骤4：调用 `__pack_data_deal` 处理视频帧（写入ring buffer）  

**线程2执行（目标检测线程：`__detect_proc_task`）**  
- 线程函数：`__detect_proc_task`  
- while循环处理逻辑：  
  - 步骤1：检查 `g_pro_hdl.detect_stat` 是否为TRUE，否则休眠500ms  
  - 步骤2：调用 `object_detector_detect_from_stream` 从视频流检测目标  
  - 步骤3：调用 `object_detector_get_performance` 获取性能数据（FPS）  

**线程3执行（存储任务线程：`thread_md_proc`）**  
- 线程函数：`thread_md_proc`  
- while循环处理逻辑：  
  - 步骤1：休眠100ms  
  - 步骤2：检查 `storage_enable_oper_type` 是否为TRUE  
  - 步骤3：调用 `tuya_ipc_start_storage` 启动SD卡/云存储  
  - 步骤4：调用 `sweeper_app_get_snapshot` 获取快照  
  - 步骤5：调用 `tuya_ipc_notify_alarm` 推送告警快照  


#### 3. 跨文件夹调用关系


**media_stream 调用 object_detector**  
- 调用路径：`__detect_proc_task` → `object_detector_detect_from_stream`  
- 调用时机：图像采集线程设置 `g_pro_hdl.detect_stat = TRUE` 时触发  
- 调用流程：  
  1. 图像采集线程获取视频帧后，设置 `g_pro_hdl.detect_stat = TRUE`  
  2. 目标检测线程检测到 `g_pro_hdl.detect_stat = TRUE`，调用 `object_detector_detect_from_stream`  
  3. `object_detector_detect_from_stream` 处理视频流并返回检测结果  
  4. 目标检测线程调用 `object_detector_get_performance` 获取FPS  


**object_detector 内部调用关系**  
- `object_detector_detect_from_stream`：从视频流检测目标  
  - 依赖：`Yolov5Postprocessor::process`（后处理）  
  - 依赖：`Yolov5Preprocessor::process`（预处理）  
  - 依赖：`InferenceEngine::infer`（推理引擎）  


#### 4. 完整调用链


```
robotics_svc_media_init  
├── robotics_svc_monocular_vision_init  
│   ├── __camera_register_to_nav_sdk  
│   ├── __camera_hw_init  
│   │   ├── tal_vi_init  
│   │   ├── tal_venc_init  
│   │   └── robotics_svc_media_audio_init  
│   │       ├── tkl_ao_init  
│   │       ├── tkl_ao_set_vol  
│   │       └── tkl_ao_start  
│   ├── __pic_sample_thrd_init → 创建 __sample_proc_task 线程  
│   └── __pic_detect_thrd_init → 创建 __detect_proc_task 线程  
└── tuya_enable_storage_deal → 创建 thread_md_proc 线程  

__sample_proc_task 线程  
├── tal_venc_get_frame  
└── __pack_data_deal  
    └── tuya_ipc_ring_buffer_append_data  

__detect_proc_task 线程  
├── object_detector_detect_from_stream  
└── object_detector_get_performance  

thread_md_proc 线程  
├── tuya_ipc_start_storage  
├── sweeper_app_get_snapshot  
└── tuya_ipc_notify_alarm  
```


#### 5. 关键共享资源


**全局变量**  
- `g_pro_hdl`：摄像头控制句柄（包含线程ID、帧数据缓冲区、检测状态）  
- `s_ring_buffer_handles`：ring buffer句柄数组（存储音视频帧数据）  
- `storage_enable_oper_type`：存储使能标志  
- `vision_enable_oper_type`：视觉使能标志  

**共享缓冲区**  
- `g_pro_hdl.frame.pbuf`：视频帧缓冲区（大小 `MEDIA_INUSE_BUFFER_SIZE`）  
- `g_pro_hdl.detect_frame.pbuf`：检测帧缓冲区（大小 `MAX_CAPTURED_BUFFER_SIZE`）  
- `g_pro_hdl.audio_frame.pbuf`：音频帧缓冲区（大小 `MAX_AUDIO_FRAME_BUFFER_SIZE`）  


### 模块间关系总结


该组件分为**媒体处理**和**视觉检测**两大模块：  
1. **媒体处理模块**：通过 `ty_robot_media_init` 初始化音视频参数、存储系统  
2. **视觉检测模块**：通过 `robotics_svc_media_init` 初始化摄像头硬件、创建采集/检测线程  
3. **跨模块交互**：媒体模块采集视频帧后，通过 `g_pro_hdl.detect_stat` 触发视觉模块的目标检测  
4. **线程协作**：采集线程、检测线程、存储线程通过全局变量（`g_pro_hdl`、`storage_enable_oper_type`）实现同步  


**核心交互流程**：  
`摄像头硬件 → 视频采集线程 → ring buffer → 目标检测线程 → object_detector → 检测结果输出`  
`存储任务线程 → SD卡/云存储 → 快照推送`

## 处理流程图

```mermaid
graph TD
    A[程序启动] --> B[ty_robot_media_init]
    B --> C[robotics_svc_media_init]
    C --> D[robotics_svc_monocular_vision_init]
    D --> E[__camera_register_to_nav_sdk]
    D --> F[__camera_hw_init]
    F --> G[tal_vi_init]
    F --> H[tal_venc_init]
    F --> I[robotics_svc_media_audio_init]
    I --> J[tkl_ao_init]
    I --> K[tkl_ao_set_vol]
    I --> L[tkl_ao_start]
    D --> M[__pic_sample_thrd_init]
    D --> N[__pic_detect_thrd_init]
    C --> O[tuya_enable_storage_deal]
    M --> P[创建 __sample_proc_task 线程]
    N --> Q[创建 __detect_proc_task 线程]
    O --> R[创建 thread_md_proc 线程]
    P --> S[运行图像采集线程]
    Q --> T[运行目标检测线程]
    R --> U[运行存储任务线程]
```

```mermaid
graph LR
    subgraph 图像采集线程执行流程
        A[__sample_proc_task] --> B{vision_enable_oper_type?}
        B -- 否 --> C[休眠500ms]
        B -- 是 --> D[tal_venc_get_frame]
        D --> E[设置 g_pro_hdl.detect_stat = TRUE]
        E --> F[__pack_data_deal]
        F --> G[tuya_ipc_ring_buffer_append_data]
        G --> B
        C --> B
    end
```

```mermaid
graph LR
    subgraph 目标检测线程执行流程
        A[__detect_proc_task] --> B{g_pro_hdl.detect_stat?}
        B -- 否 --> C[休眠500ms]
        B -- 是 --> D[object_detector_detect_from_stream]
        D --> E[object_detector_get_performance]
        E --> B
        C --> B
    end
```

```mermaid
graph LR
    subgraph 存储任务线程执行流程
        A[thread_md_proc] --> B[休眠100ms]
        B --> C{storage_enable_oper_type?}
        C -- 否 --> B
        C -- 是 --> D[tuya_ipc_start_storage]
        D --> E[sweeper_app_get_snapshot]
        E --> F[tuya_ipc_notify_alarm]
        F --> B
    end
```

```mermaid
graph LR
    subgraph object_detector 内部调用关系
        A[object_detector_detect_from_stream] --> B[Yolov5Preprocessor::process]
        A --> C[InferenceEngine::infer]
        A --> D[Yolov5Postprocessor::process]
    end
```

```mermaid
graph LR
    subgraph 跨文件夹调用关系
        A[__sample_proc_task] --> B[设置 g_pro_hdl.detect_stat = TRUE]
        B --> C[__detect_proc_task]
        C --> D[object_detector_detect_from_stream]
        D --> E[object_detector_get_performance]
    end
```

---

*文档生成时间: 2026-01-12 19:20:37*