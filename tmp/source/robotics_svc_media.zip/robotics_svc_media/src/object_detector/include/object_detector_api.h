/**
 * @file    object_detector_api.h
 * @brief   目标检测模块公共接口（对外暴露的最小化API）
 * @author  Tuya
 * @date    2026-01-09
 */
#ifndef __OBJECT_DETECTOR_API_H__
#define __OBJECT_DETECTOR_API_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "tuya_cloud_types.h"
#include "tkl_video_enc.h"

/* -------------------------------------------------------------------------- */
/*                                 Macros                                     */
/* -------------------------------------------------------------------------- */

/** @brief 最大检测/跟踪目标数 */
#define DET_MAX_TARGETS            20u
#define DET_MAX_TRACK_TARGETS      DET_MAX_TARGETS

/* -------------------------------------------------------------------------- */
/*                                 Types                                      */
/* -------------------------------------------------------------------------- */

/**
 * @brief 获取图像数据回调函数类型
 * @param[out] frame: 视频帧结构体指针
 * @return OPRT_OK 成功，其余错误码表示失败
 */
typedef OPERATE_RET (*DET_GET_FRAME_CB)(TKL_VENC_FRAME_T* frame);

/**
 * @brief 跟踪目标状态（用于获取检测结果）
 */
typedef struct {
    int32_t  id;                /**< 目标ID */
    int32_t  class_id;          /**< 类别ID */
    float    confidence;        /**< 置信度 */
    float    x;                 /**< 左上角x坐标 */
    float    y;                 /**< 左上角y坐标 */
    float    width;             /**< 宽度 */
    float    height;            /**< 高度 */
    float    vx;                /**< x方向速度(像素/毫秒) */
    float    vy;                /**< y方向速度(像素/毫秒) */
    uint64_t last_update_time;  /**< 最后更新时间(毫秒) */
    uint8_t  is_valid;          /**< 是否有效 */
    uint8_t  frames_since_update;/**< 自上次更新后的帧数 */
} DET_TRACK_TARGET_T;

/**
 * @brief 检测任务配置结构体
 */
typedef struct {
    /* 模型配置 */
    uint32_t model_width;         /**< 模型输入宽度 */
    uint32_t model_height;        /**< 模型输入高度 */
    float    conf_threshold;      /**< 置信度阈值 */
    float    nms_threshold;       /**< NMS阈值 */
    uint32_t max_detections;      /**< 最大检测数量 */
    
    /* 跟踪器配置 */
    uint32_t max_predict_ms;      /**< 跟踪器最大预测时间(毫秒) */
    float    iou_threshold;       /**< IOU匹配阈值 */
    uint32_t max_miss_frames;     /**< 最大丢失帧数 */
    float    velocity_smooth;     /**< 速度平滑因子 */
    
    /* 任务配置 */
    /* 任务配置 */
    uint32_t sleep_interval_ms;   /**< 检测间隔(毫秒) */
    DET_GET_FRAME_CB get_frame_cb;/**< 获取图像回调函数 */
    
    /* 调试配置 */
    uint8_t  enable_timing;       /**< 启用性能统计 */
    uint8_t  save_debug_images;   /**< 保存调试图像 */
    uint32_t debug_image_interval;/**< 调试图像保存间隔(帧) */
} DET_TASK_CONFIG_T;

/* -------------------------------------------------------------------------- */
/*                           Public API                                       */
/* -------------------------------------------------------------------------- */

/**
 * @brief 获取检测任务默认配置
 * @return 默认配置结构体
 */
DET_TASK_CONFIG_T det_task_get_default_config(void);

/**
 * @brief 初始化并启动检测任务
 * @param[in] config: 配置结构体指针（此处不能为NULL)
 * @return OPRT_OK 成功，其余错误码表示失败
 */
OPERATE_RET det_task_init(const DET_TASK_CONFIG_T* config);

/**
 * @brief 设置检测功能开关
 * @param[in] enable: true 启动检测，false 暂停检测
 */
void det_task_set_enable(bool_t enable);

/**
 * @brief 获取检测功能当前状态
 * @return true 已启用，false 已暂停
 */
bool_t det_task_is_enabled(void);

/**
 * @brief 停止并释放检测任务资源
 * @return OPRT_OK 成功，其余错误码表示失败
 */
OPERATE_RET det_task_deinit(void);

/**
 * @brief 获取用于显示的目标列表（优先预测，失败则读缓存）
 * @param[out] results: 输出目标位置
 * @param[in] max_count: 最大输出数量
 * @param[in] timestamp_ms: 当前时间戳
 * @return 输出的目标数量
 */
int32_t det_tracker_get_display_targets(
    DET_TRACK_TARGET_T* results,
    int32_t max_count,
    uint64_t timestamp_ms
);

#ifdef __cplusplus
}
#endif

#endif /* __OBJECT_DETECTOR_API_H__ */
