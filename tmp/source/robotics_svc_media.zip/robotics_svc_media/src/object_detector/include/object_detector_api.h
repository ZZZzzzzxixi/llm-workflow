/**
 * @file object_detector_api.h
 * @brief 目标检测器C接口
 * @author lzq
 * @version 1.0
 * @date 2025-12-29 09:42:40
 * 
 * Copyright (c) tuya.inc 2023-2033.
 * 
 */

#ifndef __OBJECT_DETECTOR_API_H__
#define __OBJECT_DETECTOR_API_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "tuya_error_code.h"
#include "object_detector_config.h"
#include "tuya_cloud_types.h"

/**
 * @brief 检测结果结构体
 */
typedef struct {
    int left;                     // 边界框左上角x坐标
    int top;                      // 边界框左上角y坐标
    int right;                    // 边界框右下角x坐标
    int bottom;                   // 边界框右下角y坐标
    int class_id;                 // 类别ID（0-79 for COCO）
    float confidence;             // 置信度（0.0-1.0）
} OBJECT_DETECTION_RESULT_T;

/**
 * @brief 检测结果列表
 */
typedef struct {
    int count;                    // 检测到的目标数量
    OBJECT_DETECTION_RESULT_T results[100];  // 检测结果数组
} OBJECT_DETECTION_LIST_T;

/**
 * @brief 性能统计结构
 */
typedef struct {
    double preprocess_time;       // 预处理时间（秒）
    double inference_time;        // 推理时间（秒）
    double postprocess_time;      // 后处理时间（秒）
    double total_time;            // 总时间（秒）
    double fps;                   // 帧率
} OBJECT_DETECTOR_PERF_T;

/**
 * @brief 获取默认配置
 * @return OBJECT_DETECTOR_CONFIG_T: 默认配置结构
 * @note 可以基于默认配置修改部分参数后传给 object_detector_init()
 */
OBJECT_DETECTOR_CONFIG_T object_detector_get_default_config(void);

/**
 * @brief 初始化检测器
 * @param[in] model_path: 模型文件路径
 * @param[in] label_path: 标签文件路径（传NULL使用默认路径）
 * @param[in] config: 配置参数（传NULL使用默认配置）
 * @return OPERATE_RET: 0 成功，其余错误码表示失败
 * @note 必须在使用其他API前调用此函数，且只能调用一次，重复调回用会返回错误
 */
OPERATE_RET object_detector_init(
    const char* model_path,
    const char* label_path,
    const OBJECT_DETECTOR_CONFIG_T* config
);

/**
 * @brief 检测图像中的目标
 * @param[in] image_data: RGB图像数据指针
 * @param[in] width: 图像宽度
 * @param[in] height: 图像高度
 * @param[out] results: 检测结果列表
 * @return int: 0 成功，其余错误码表示失败
 * @note image_data必须是RGB格式，且调用前必须先调object_detector_init()
 */
int object_detector_detect(
    const unsigned char* image_data,
    int width,
    int height,
    OBJECT_DETECTION_LIST_T* results
);

/**
 * @brief 从视频流检测目标（自动获取图像）
 * @param[out] results: 检测结果列表
 * @return int: 0 成功，其余错误码表示失败
 * @note 自动从tuya_get_pic_rgb()获取图像
 */
int object_detector_detect_from_stream(
    OBJECT_DETECTION_LIST_T* results
);

/**
 * @brief 获取性能统计
 * @param[out] perf: 性能统计数据
 * @return int: 0 成功，其余错误码表示失败
 */
int object_detector_get_performance(
    OBJECT_DETECTOR_PERF_T* perf
);

/**
 * @brief 获取类别名称
 * @param[in] class_id: 类别ID
 * @return const char*: 类别名称字符串，失败返回 unknown
 */
const char* object_detector_get_class_name(int class_id);

/**
 * @brief 更新配置
 * @param[in] config: 新的配置参数
 * @return int: 0 成功，其余错误码表示失败
 * @note 支持在运行过程中动态更新配置参数
 */
int object_detector_update_config(
    const OBJECT_DETECTOR_CONFIG_T* config
);

/**
 * @brief 释放检测器资源
 * @return int: 0 成功，其余错误码表示失败
 */
int object_detector_deinit(void);

#ifdef __cplusplus
}
#endif

#endif // __OBJECT_DETECTOR_API_H__
