/**
 * @file object_detector_config.h
 * @brief 目标检测器配置
 * @author lzq
 * @version 1.0
 * @date 2025-12-29 09:56:14
 * 
 * Copyright (c) tuya.inc 2023-2033.
 * 
 */

#ifndef __OBJECT_DETECTOR_CONFIG_H__
#define __OBJECT_DETECTOR_CONFIG_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 检测器配置结构
 */
typedef struct {
    // 模型参数
    int model_width;              // 模型输入宽度（默认640）
    int model_height;             // 模型输入高度（默认640）
    
    // 检测参数
    float conf_threshold;         // 置信度阈值（默认0.25，范围0.0-1.0）
    float nms_threshold;          // NMS阈值（默认0.45，范围0.0-1.0）
    int max_detections;           // 最大检测数量（默认100）
    
    // 性能选项
    int enable_timing;            // 启用性能统计（1=启用，0=禁用）
    int save_debug_images;        // 保存调试图像（1=启用，0=禁用）
    int debug_image_interval;     // 调试图像保存间隔（帧数）
    
} OBJECT_DETECTOR_CONFIG_T;

#ifdef __cplusplus
}
#endif

#endif // __OBJECT_DETECTOR_CONFIG_H__
