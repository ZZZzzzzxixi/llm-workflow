/**
 * @file detection_task.c
 * @brief 目标检测任务实现
 * @author lzq
 * @version 1.0
 * @date 2026-01-13 10:31:36
 * 
 * Copyright (c) tuya.inc 2023-2033.
 * 
 */

#include <pthread.h>
#include <unistd.h>

#include "object_detector_internal.h"
#include "tal_time_service.h"
#include "uni_log.h"

/* -------------------------------------------------------------------------- */
/*                              私有宏定义                                     */
/* -------------------------------------------------------------------------- */

/* 模型/检测器/跟踪器配置使用 object_detector_internal.h 中定义的 DET_DEFAULT_* 宏 */
#define DEFAULT_SLEEP_INTERVAL_MS 10u   /**< 检测循环间隔(ms) */

/* -------------------------------------------------------------------------- */
/*                              私有变量                                       */
/* -------------------------------------------------------------------------- */

static volatile bool_t g_detection_enable = FALSE;
static volatile bool_t s_task_running = FALSE;
static pthread_mutex_t s_detection_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t s_detection_cond = PTHREAD_COND_INITIALIZER;
static pthread_t s_detection_tid = (pthread_t)-1;
static DET_TASK_CONFIG_T s_config;

/* -------------------------------------------------------------------------- */
/*                              私有函数                                       */
/* -------------------------------------------------------------------------- */

/**
 * @brief 等待检测功能启用
 */
static void __wait_for_detection_enable(void)
{
    pthread_mutex_lock(&s_detection_mutex);
    while (FALSE == g_detection_enable && TRUE == s_task_running) {
        pthread_cond_wait(&s_detection_cond, &s_detection_mutex);
    }
    pthread_mutex_unlock(&s_detection_mutex);
}

/**
 * @brief 处理检测结果并更新缓存
 * @param[in] results: 检测结果列表
 * @param[in] now_ms: 当前时间戳
 */
static void __process_detection_results(const DET_DETECTION_LIST_T* results, uint64_t now_ms)
{
    TKL_VI_DETECT_TARGET_T tracker_targets[DET_MAX_TARGETS];
    
    if (NULL == results || 0 == results->count) {
        det_tracker_update(NULL, 0, now_ms);
        return;
    }
    
    int32_t count = results->count;
    if (count > (int32_t)DET_MAX_TARGETS) {
        count = (int32_t)DET_MAX_TARGETS;
    }
    
    for (int32_t i = 0; i < count; i++) { 
        const DET_DETECTION_RESULT_T* r = &results->results[i];
        tracker_targets[i].id = (uint32_t)i;
        tracker_targets[i].type = (uint32_t)r->class_id;
        tracker_targets[i].score = r->confidence;
        tracker_targets[i].draw_rect.x = r->left;
        tracker_targets[i].draw_rect.y = r->top;
        tracker_targets[i].draw_rect.width = r->right - r->left;
        tracker_targets[i].draw_rect.height = r->bottom - r->top;
    }
    
    
    int32_t track_count = det_tracker_update(tracker_targets, count, now_ms);
}

/**
 * @brief 检测任务线程函数
 * @param[in] args: 线程参数（未使用）
 * @return NULL
 */
static void* __detection_thread(void* args)
{
    (void)args;
    DET_DETECTION_LIST_T results;
    DET_PERF_T perf;
    PR_INFO("Detection task started, waiting for enable...");
    
    for (;;) {
        __wait_for_detection_enable();
        if (FALSE == s_task_running) {
            break;
        }

        if (OPRT_OK == det_detector_detect_from_stream(&results)) {
            uint64_t now_ms = tal_time_get_posix_ms();
            __process_detection_results(&results, now_ms);
            
            if (s_config.enable_timing) {
                det_detector_get_performance(&perf);
                PR_DEBUG("Detection FPS: %.2f (inference: %.1fms)",
                         perf.fps, perf.inference_time * 1000.0f);
            }
        }
        
        usleep(s_config.sleep_interval_ms * 1000u);
    }
    
    PR_INFO("Detection task exited");
    return NULL;
}

/**
 * @brief 初始化跟踪器
 * @param[in] config: 配置参数
 * @return OPRT_OK 成功，其余错误码表示失败
 */
static OPERATE_RET __init_tracker(const DET_TASK_CONFIG_T* config)
{
    DET_TRACKER_CONFIG_T tracker_config = det_tracker_get_default_config();
    tracker_config.max_predict_ms = config->max_predict_ms;
    tracker_config.iou_threshold = config->iou_threshold;
    tracker_config.max_miss_frames = config->max_miss_frames;
    tracker_config.velocity_smooth = config->velocity_smooth;
    
    OPERATE_RET ret = det_tracker_init(&tracker_config);
    if (OPRT_OK != ret) {
        PR_ERR("Tracker init failed: %d", ret);
        return ret;
    }
    
    PR_INFO("Tracker initialized: predict=%ums, smooth=%.2f",
            tracker_config.max_predict_ms, tracker_config.velocity_smooth);
    
    return OPRT_OK;
}

/**
 * @brief 初始化检测器
 * @param[in] config: 配置参数
 * @return OPRT_OK 成功，其余错误码表示失败
 */
static OPERATE_RET __init_detector(const DET_TASK_CONFIG_T* config)
{
    DET_CONFIG_T detector_config;
    
    /* 从任务配置映射到检测器配置 */
    detector_config.model_width = config->model_width;
    detector_config.model_height = config->model_height;
    detector_config.conf_threshold = config->conf_threshold;
    detector_config.nms_threshold = config->nms_threshold;
    detector_config.max_detections = config->max_detections;
    detector_config.enable_timing = config->enable_timing;
    detector_config.save_debug_images = config->save_debug_images;
    detector_config.debug_image_interval = config->debug_image_interval;
    detector_config.get_frame_cb = config->get_frame_cb;
    
    OPERATE_RET ret = det_detector_init(DET_DEFAULT_MODEL_PATH, NULL, &detector_config);
    if (OPRT_OK != ret) {
        PR_ERR("Object detector init failed: %d", ret);
        return ret;
    }
    
    PR_INFO("Object detector initialized");
    return OPRT_OK;
}

/* -------------------------------------------------------------------------- */
/*                              公共接口                                       */
/* -------------------------------------------------------------------------- */

/**
 * @brief 获取检测任务默认配置
 * @return 默认配置结构体
 */
DET_TASK_CONFIG_T det_task_get_default_config(void)
{
    DET_TASK_CONFIG_T config = {
        /* 模型配置 */
        .model_width         = DET_DEFAULT_MODEL_WIDTH,
        .model_height        = DET_DEFAULT_MODEL_HEIGHT,
        .conf_threshold      = DET_DEFAULT_CONF_THRESHOLD,
        .nms_threshold       = DET_DEFAULT_NMS_THRESHOLD,
        .max_detections      = DET_DEFAULT_MAX_DETECTIONS,
        
        /* 跟踪器配置 */
        .max_predict_ms      = DET_DEFAULT_MAX_PREDICT_MS,
        .iou_threshold       = DET_DEFAULT_IOU_THRESHOLD,
        .max_miss_frames     = DET_DEFAULT_MAX_MISS_FRAMES,
        .velocity_smooth     = DET_DEFAULT_VELOCITY_SMOOTH,
        
        /* 任务配置 */
        .sleep_interval_ms   = DEFAULT_SLEEP_INTERVAL_MS,
        .get_frame_cb        = NULL,
        
        /* 调试配置 */
        .enable_timing       = DET_DEFAULT_ENABLE_TIMING,
        .save_debug_images   = DET_DEFAULT_SAVE_DEBUG_IMAGES,
        .debug_image_interval = DET_DEFAULT_DEBUG_INTERVAL,
    };
    return config;
}


OPERATE_RET det_task_init(const DET_TASK_CONFIG_T* config)
{
    OPERATE_RET rt = OPRT_OK;
    if (TRUE == s_task_running) {
        PR_WARN("Detection task already running");
        return OPRT_OK;
    }
    
    if (NULL == config || NULL == config->get_frame_cb) {
        PR_ERR("Config cannot be NULL");
        return OPRT_INVALID_PARM;
    }
    s_config = *config;
    
    TUYA_CALL_ERR_GOTO(__init_tracker(&s_config), __EXIT);
    TUYA_CALL_ERR_GOTO(__init_detector(&s_config), __EXIT);
    
    s_task_running = TRUE;
    g_detection_enable = FALSE;
    
    int32_t thread_ret = pthread_create(&s_detection_tid, NULL, __detection_thread, NULL);
    if (0 != thread_ret) {
        PR_ERR("pthread_create failed: %d", thread_ret);
        goto __EXIT;
    }
    
    PR_INFO("Detection task init success");
    return OPRT_OK;

__EXIT:
    s_task_running = FALSE;
    det_detector_deinit();
    det_tracker_deinit();
    return rt;
}

/**
 * @brief 设置检测功能开关
 * @param[in] enable: true 启动检测，false 暂停检测
 */
void det_task_set_enable(bool_t enable)
{
    pthread_mutex_lock(&s_detection_mutex);
    g_detection_enable = enable;
    if (enable) {
        pthread_cond_signal(&s_detection_cond);
        PR_INFO("Detection task RESUMED");
    } else {
        PR_INFO("Detection task SUSPENDED");
    }
    pthread_mutex_unlock(&s_detection_mutex);
}

/**
 * @brief 获取检测功能当前状态
 * @return true 已启用，false 已暂停
 */
bool_t det_task_is_enabled(void)
{
    bool_t ret = false;
    pthread_mutex_lock(&s_detection_mutex);
    ret = (TRUE == g_detection_enable) ? true : false;
    pthread_mutex_unlock(&s_detection_mutex);
    return ret;
}

/**
 * @brief 停止并释放检测任务资源
 * @return OPRT_OK 成功，其余错误码表示失败
 */
OPERATE_RET det_task_deinit(void)
{
    if (FALSE == s_task_running) {
        return OPRT_OK;
    }
    
    pthread_mutex_lock(&s_detection_mutex);
    s_task_running = FALSE;
    g_detection_enable = TRUE;
    pthread_cond_signal(&s_detection_cond);
    pthread_mutex_unlock(&s_detection_mutex);
    
    if ((pthread_t)-1 != s_detection_tid) {
        pthread_join(s_detection_tid, NULL);
        s_detection_tid = (pthread_t)-1;
    }
    
    det_detector_deinit();
    det_tracker_deinit();
    
    PR_INFO("Detection task deinit success");
    return OPRT_OK;
}
