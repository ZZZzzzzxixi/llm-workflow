/**
 * @file yolo_detector.cpp
 * @brief YOLO检测器主类实现
 * @author lzq
 * @version 1.0
 * @date 2025-12-29 11:26:00
 * 
 * Copyright (c) tuya.inc 2023-2033.
 * 
 */

#ifndef __YOLO_DETECTOR_H__
#define __YOLO_DETECTOR_H__

#include "detector_types.h"
#include "detector_config.h"
#include "preprocessor.h"
#include "inference_engine.h"
#include "postprocessor.h"
#include <memory>
#include <string>
#include <vector>

namespace detector {

/**
 * @brief 性能统计
 */
struct PerformanceStats {
    double preprocess_time; 
    double inference_time;
    double postprocess_time;
    double total_time;
    
    PerformanceStats() 
        : preprocess_time(0.0)
        , inference_time(0.0)
        , postprocess_time(0.0)
        , total_time(0.0) 
    {}
    
    double get_fps() const {
        return total_time > 0.0 ? 1.0 / total_time : 0.0;
    }
};


class YoloDetector {
public:
    explicit YoloDetector(const DetectorConfig& config = DetectorConfig());
    
    ~YoloDetector();

    /**
     * @brief 初始化检测器
     * @param[in] model_path: 模型文件路径
     * @param[in] label_file: 标签文件路径
     * @return int: 0 成功，其余错误码表示失败
     */
    int initialize(const char* model_path, const char* label_file = nullptr);

    /**
     * @brief 检测图像中的目标
     * @param[in] image: 输入图像
     * @return DetectionList: 0 成功，其余错误码表示失败
     */
    DetectionList detect(const cv::Mat& image);
    
    /**
     * @brief 获取性能统计
     */
    const PerformanceStats& get_performance_stats() const {
        return perf_stats_;
    }
    
    /**
     * @brief 获取配置
     */
    const DetectorConfig& get_config() const {
        return config_;
    }
    
    /**
     * @brief 更新配置
     */
    void update_config(const DetectorConfig& config) {
        config_ = config;
    }
    
    /**
     * @brief 加载标签
     */
    int load_labels(const char* label_file);
    
    /**
     * @brief 获取类别名称
     */
    std::string get_class_name(int class_id) const;

private:
    DetectorConfig config_;
    
    std::unique_ptr<IPreprocessor> preprocessor_;
    std::unique_ptr<IInferenceEngine> inference_engine_;
    std::unique_ptr<IPostprocessor> postprocessor_;
    
    std::vector<std::string> labels_;
    PreprocessParams last_preprocess_params_;
    PerformanceStats perf_stats_;
    
    bool initialized_;
};

} // namespace detector

#endif // __YOLO_DETECTOR_H__
