/**
 * @file detector_config.h
 * @brief 目标检测器内部配置
 * @author lzq
 * @version 1.0
 * @date 2025-12-25 14:39:09
 * 
 * Copyright (c) tuya.inc 2023-2033.
 * 
 */
#ifndef __DETECTOR_CONFIG_H__
#define __DETECTOR_CONFIG_H__

#include <string>
#include <array>

namespace detector {

/**
 * @brief YOLOv5配置
 */
struct YoloConfig {
    // 模型参数
    int model_width;                    // 模型输入宽度
    int model_height;                   // 模型输入高度
    int num_classes;                    // 类别数量
    
    // Anchor配置（3层 × 3个anchor × 2个值(w,h)）
    std::array<std::array<int, 6>, 3> anchors;
    
    // 检测参数
    float conf_threshold;               // 置信度阈值
    float nms_threshold;                // NMS阈值
    int max_detections;                 // 最大检测数量
    
    // 标签文件
    std::string label_file;
    
    // 默认配置（YOLOv5s COCO）
    YoloConfig() 
        : model_width(640)
        , model_height(640)
        , num_classes(1) 
        , anchors({{
            {{10, 13, 16, 30, 33, 23}},      // 小目标层
            {{30, 61, 62, 45, 59, 119}},     // 中目标层
            {{116, 90, 156, 198, 373, 326}}  // 大目标层
          }})
        , conf_threshold(0.5f)   
        , nms_threshold(0.6f)   
        , max_detections(100)
        , label_file("/tuya/data/coco_80_labels_list.txt")
    {}
    
    // 获取特定层的anchor
    const int* get_anchor(int layer_idx) const {
        return anchors[layer_idx].data();
    }
    
    // 计算步长
    int get_stride(int layer_idx) const {
        const int grid_sizes[] = {80, 40, 20};
        return model_height / grid_sizes[layer_idx];
    }
};

/**
 * @brief 性能配置
 */
struct PerformanceConfig {
    bool enable_timing;                 // 启用性能统计
    bool save_debug_images;             // 保存调试图像
    int debug_image_interval;           // 调试图像保存间隔（帧）
    std::string debug_image_path;       // 调试图像保存路径
    
    PerformanceConfig()
        : enable_timing(true)
        , save_debug_images(true)
        , debug_image_interval(10)
        , debug_image_path("/tuya/data/tuya_image")
    {}
};

/**
 * @brief 检测器配置
 */
struct DetectorConfig {
    YoloConfig yolo;
    PerformanceConfig performance;
    
    DetectorConfig() = default;
};

} // namespace detector

#endif // __DETECTOR_CONFIG_H__
