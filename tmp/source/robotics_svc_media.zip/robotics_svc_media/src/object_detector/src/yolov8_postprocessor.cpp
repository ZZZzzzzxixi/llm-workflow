/**
 * @file yolov8_postprocessor.cpp
 * @brief YOLOv8后处理器实现
 * @author lzq
 * @version 1.0
 * @date 2025-12-29 11:33:44
 * 
 * Copyright (c) tuya.inc 2023-2033.
 * 
 */

#include "postprocessor.h"
#include <algorithm>
#include <set>
#include <cmath>
#include "uni_log.h"
#include <opencv2/dnn/dnn.hpp>

namespace detector {

/**
 * @brief 处理推理输出，生成检测结果
 * @param[in] raw_output: 推理引擎的原始输出
 * @param[in] config: 检测器配置
 * @return DetectionList: 检测结果列表
 */
DetectionList Yolov8Postprocessor::process(
    const InferenceOutput& raw_output,
    const YoloConfig& config) 
{
    if (raw_output.layers.empty()) {
        PR_WARN("No output layers");
        return DetectionList();
    }

    DetectionList all_detections;

    PR_INFO("Detected YOLOv8 output format, starting transpose and decode...");
    
    // --- YOLOv8 解析分支 ---
    const auto& layer = raw_output.layers[0];
    float* data = (float*)layer.data;
    int rows = 8400;
    int dimensions = 84;

    std::vector <int> Ids;
    std::vector <float> confidences;
    std::vector<cv::Rect> boxes;
    for (int i = 0; i < rows; ++i) {
        float* row_ptr = data + (i * dimensions);
        float* classes_scores = row_ptr + 4; // 跳过 x,y,w,h

        // 寻找分类最大分值
        float max_score = 0;
        int class_id = 0;
        for (int c = 0; c < config.num_classes; ++c) {
            if (classes_scores[c] > max_score) {
                max_score = classes_scores[c];
                class_id = c;
            }
        }

        if (max_score > config.conf_threshold) {
            float cx = row_ptr[0];
            float cy = row_ptr[1];
            float w  = row_ptr[2];
            float h  = row_ptr[3];

            // 转换中心点坐标到左上角坐标
            int left   = cx - 0.5f * w;
            int top    = cy - 0.5f * h;
            int width  = int(w) ;
            int height = int(h);
            confidences.push_back(max_score);
            Ids.push_back(class_id);
            boxes.push_back(cv::Rect(left, top, width, height));
        }
    }

    std::vector<int> nms_result;
    cv::dnn::NMSBoxes(boxes, confidences, config.conf_threshold, config.nms_threshold, nms_result);
        
    // 生成detections结构体
    for (unsigned long i = 0; i < nms_result.size(); ++i) {
        int idx = nms_result[i];
        auto box = boxes[idx];
        Detection det;
        det.box.left   = box.x;
        det.box.top    = box.y;
        det.box.right  = box.x + box.width;
        det.box.bottom = box.y + box.height;
        det.confidence = confidences[idx];
        det.class_id   = Ids[idx];
        all_detections.push_back(det);
    }

    return all_detections;
}

/**
 * @brief 解码单层输出
 * @param[in] input: 输入数据指针
 * @param[in] anchor: 当前层的anchor配置
 * @param[in] grid_h: 网格高度
 * @param[in] grid_w: 网格宽度
 * @param[in] num_classes: 类别数量
 * @param[in] stride: 步长
 * @param[in] threshold: 置信度阈值
 * @param[out] boxes: 输出边界框列表
 * @param[out] scores: 输出置信度列表
 * @param[out] class_ids: 输出类别ID列表
 * @return int: 检测到的目标数量
 */
int Yolov8Postprocessor::decode_layer(
    const float* input,
    const int* anchor,
    int grid_h, int grid_w,
    int num_classes,
    int stride,
    float threshold,
    std::vector<float>& boxes,
    std::vector<float>& scores,
    std::vector<int>& class_ids)
{
    if (!input || !anchor || stride == 0) {
        return 0;
    }

    int validCount = 0;
    const int anchor_per_branch = 3;
    const int prop_box_size = 5 + num_classes;
    const int align_c = prop_box_size * anchor_per_branch;
    
    const float* input_float = input;
    
    for (int h = 0; h < grid_h; h++) {
        for (int w = 0; w < grid_w; w++) {
            for (int a = 0; a < anchor_per_branch; a++) {
                int hw_offset = h * grid_w * align_c + w * align_c + a * prop_box_size;
                const float* hw_ptr = input_float + hw_offset;
                float box_confidence = hw_ptr[4];

                if (box_confidence >= threshold) {
                    float maxClassProbs = hw_ptr[5];
                    int maxClassId = 0;
                    for (int k = 1; k < num_classes; ++k) {
                        float prob = hw_ptr[5 + k];
                        if (prob > maxClassProbs) {
                            maxClassId = k;
                            maxClassProbs = prob;
                        }
                    }

                    float limit_score = box_confidence * maxClassProbs;

                    if (limit_score > threshold) {
                        float box_x, box_y, box_w, box_h;

                        box_x = hw_ptr[0] * 2.0 - 0.5;
                        box_y = hw_ptr[1] * 2.0 - 0.5;
                        box_w = hw_ptr[2] * 2.0;
                        box_h = hw_ptr[3] * 2.0;
                        box_w = box_w * box_w;
                        box_h = box_h * box_h;

                        box_x = (box_x + w) * (float)stride;
                        box_y = (box_y + h) * (float)stride;
                        box_w *= (float)anchor[a * 2];
                        box_h *= (float)anchor[a * 2 + 1];

                        box_x -= (box_w / 2.0);
                        box_y -= (box_h / 2.0);

                        boxes.push_back(box_x);
                        boxes.push_back(box_y);
                        boxes.push_back(box_w);
                        boxes.push_back(box_h);
                        scores.push_back(limit_score);
                        class_ids.push_back(maxClassId);
                        validCount++;
                    }
                }
            }
        }
    }

    return validCount;
}

/**
 * @brief 按置信度降序排序
 * @param[in] scores: 置信度列表
 * @param[in/out] indices: 索引列表
 */
void Yolov8Postprocessor::sort_by_confidence(
    std::vector<float>& scores,
    std::vector<int>& indices)
{
    std::sort(indices.begin(), indices.end(),
        [&scores](int a, int b) {
            return scores[a] > scores[b];
        });
}

/**
 * @brief 非极大值抑制
 * @param[in] validCount: 有效检测数量
 * @param[in] outputLocations: 边界框列表
 * @param[in] classIds: 类别ID列表
 * @param[in/out] order: 索引排序列表
 * @param[in] filterId: 当前处理的类别ID
 * @param[in] threshold: NMS阈值
 */
void Yolov8Postprocessor::apply_nms(
    int validCount,
    const std::vector<float>& outputLocations,
    const std::vector<int>& classIds,
    std::vector<int>& order,
    int filterId,
    float threshold)
{
    for (int i = 0; i < validCount; ++i) {
        if (order[i] == -1 || classIds[i] != filterId) {
            continue;
        }
        int n = order[i];
        for (int j = i + 1; j < validCount; ++j) {
            int m = order[j];
            if (m == -1 || classIds[m] != filterId) {
                continue;
            }
            
            float xmin0 = outputLocations[n * 4 + 0];
            float ymin0 = outputLocations[n * 4 + 1];
            float xmax0 = outputLocations[n * 4 + 0] + outputLocations[n * 4 + 2];
            float ymax0 = outputLocations[n * 4 + 1] + outputLocations[n * 4 + 3];

            float xmin1 = outputLocations[m * 4 + 0];
            float ymin1 = outputLocations[m * 4 + 1];
            float xmax1 = outputLocations[m * 4 + 0] + outputLocations[m * 4 + 2];
            float ymax1 = outputLocations[m * 4 + 1] + outputLocations[m * 4 + 3];

            float w = fmax(0.f, fmin(xmax0, xmax1) - fmax(xmin0, xmin1) + 1.0);
            float h = fmax(0.f, fmin(ymax0, ymax1) - fmax(ymin0, ymin1) + 1.0);
            float inter = w * h;
            float u = (xmax0 - xmin0 + 1.0) * (ymax0 - ymin0 + 1.0) + 
                      (xmax1 - xmin1 + 1.0) * (ymax1 - ymin1 + 1.0) - inter;
            float iou = u <= 0.f ? 0.f : (inter / u);

            if (iou > threshold) {
                order[j] = -1;
            }
        }
    }
}

/**
 * @brief 转换为Detection结构
 * @param[in] filterBoxes: 边界框列表
 * @param[in] objProbs: 置信度列表
 * @param[in] classId: 类别ID列表
 * @param[in] indexArray: 索引列表
 * @param[in] model_width: 模型输入宽度
 * @param[in] model_height: 模型输入高度
 * @return DetectionList: 检测结果列表
 */
DetectionList Yolov8Postprocessor::convert_to_detections(
    const std::vector<float>& filterBoxes,
    const std::vector<float>& objProbs,
    const std::vector<int>& classId,
    const std::vector<int>& indexArray,
    int model_width,
    int model_height)
{
    DetectionList detections;
    int validCount = static_cast<int>(indexArray.size());
    
    auto clamp = [](float val, int min_val, int max_val) -> int {
        return val > min_val ? (val < max_val ? static_cast<int>(val) : max_val) : min_val;
    };

    for (int i = 0; i < validCount; ++i) {
        if (indexArray[i] == -1) {
            continue;
        }
        
        int n = indexArray[i];

        float x1 = filterBoxes[n * 4 + 0];
        float y1 = filterBoxes[n * 4 + 1];
        float x2 = x1 + filterBoxes[n * 4 + 2];
        float y2 = y1 + filterBoxes[n * 4 + 3];
        int id = classId[n];
        float obj_conf = objProbs[n];

        BoundingBox box(
            clamp(x1, 0, model_width),
            clamp(y1, 0, model_height),
            clamp(x2, 0, model_width),
            clamp(y2, 0, model_height)
        );
        
        Detection det(box, id, obj_conf);
        detections.push_back(det);
    }
    
    return detections;
}

} // namespace detector
