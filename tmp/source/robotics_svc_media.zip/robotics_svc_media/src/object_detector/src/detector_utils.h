/**
 * @file detector_utils.h
 * @brief 检测器工具函数实现
 * @author lzq
 * @version 1.0
 * @date 2025-12-25 10:18:12
 * 
 * Copyright (c) tuya.inc 2023-2033.
 * 
 */

#ifndef __DETECTOR_UTILS_H__
#define __DETECTOR_UTILS_H__

#include "detector_types.h"
#include <opencv2/core/core.hpp>
#include <string>
#include <vector>

namespace detector {

struct PerformanceStats;

namespace utils {

/**
 * @brief 数值裁剪
 */
template<typename T>
inline T clamp(T value, T min_val, T max_val) {
    return value < min_val ? min_val : (value > max_val ? max_val : value);
}

/**
 * @brief 反量化：int8 -> float32
 */
inline float dequantize(int8_t qnt, int32_t zero_point, float scale) {
    return (static_cast<float>(qnt) - static_cast<float>(zero_point)) * scale;
}

/**
 * @brief 量化：float32 -> int8
 */
inline int8_t quantize(float value, int32_t zero_point, float scale) {
    float dst = (value / scale) + zero_point;
    return static_cast<int8_t>(clamp(dst, -128.0f, 127.0f));
}

/**
 * @brief 绘制检测结果
 */
void draw_detections(
    cv::Mat& image,
    const DetectionList& detections,
    const cv::Scalar& color = cv::Scalar(0, 255, 0),
    int thickness = 2);

/**
 * @brief 保存检测结果图像
 */
bool save_detection_image(
    const cv::Mat& image,
    const DetectionList& detections,
    const std::string& filename);

/**
 * @brief 加载标签文件
 */
std::vector<std::string> load_labels(const std::string& filename);

/**
 * @brief 性能统计格式化输出
 */
std::string format_performance_stats(const PerformanceStats& stats);

} // namespace utils
} // namespace detector

#endif // __DETECTOR_UTILS_H__
