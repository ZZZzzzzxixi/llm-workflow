/**
 * @file letterbox_preprocessor.cpp
 * @brief LetterBox预处理器实现 - 与原始代码letter_box函数一致
 * @author lzq
 * @version 2.0
 * @date 2025-12-25
 * 
 * Copyright (c) tuya.inc 2023-2033.
 */

#include "preprocessor.h"
#include <opencv2/imgproc/imgproc.hpp>
#include <algorithm>
#include <cmath>

namespace detector {

LetterBoxPreprocessor::LetterBoxPreprocessor(
    const cv::Size& target_size,
    const cv::Scalar& fill_color)
    : target_size_(target_size)
    , fill_color_(fill_color)
{
}

PreprocessResult LetterBoxPreprocessor::process(const cv::Mat& input) {
    PreprocessResult result;
    
    // 保存原始尺寸
    result.params.original_size = input.size();
    result.params.target_size = target_size_;
    
    cv::Size shape = input.size();  // 获取照片的size
    
    // 计算缩放比例 - 与原始代码一致
    float r = std::min(
        (float)target_size_.height / (float)shape.height,  // 计算高度缩放比例
        (float)target_size_.width / (float)shape.width     // 计算宽度缩放比例
    );

    float ratio[2] = { r, r };
    int new_un_pad[2] = { 
        (int)std::round((float)shape.width * r),
        (int)std::round((float)shape.height * r) 
    };

    auto dw = (float)(target_size_.width - new_un_pad[0]);
    auto dh = (float)(target_size_.height - new_un_pad[1]);

    dw /= 2.0f;
    dh /= 2.0f;

    cv::Mat outImage;
    if (shape.width != new_un_pad[0] && shape.height != new_un_pad[1]) {
        cv::resize(input, outImage, cv::Size(new_un_pad[0], new_un_pad[1]));
    } else {
        outImage = input.clone();
    }

    int top = int(std::round(dh - 0.1f));
    int bottom = int(std::round(dh + 0.1f));
    int left = int(std::round(dw - 0.1f));
    int right = int(std::round(dw + 0.1f));
    
    result.params.transform_params[0] = ratio[0];
    result.params.transform_params[1] = ratio[1];
    result.params.transform_params[2] = left;
    result.params.transform_params[3] = top;
    
    // 添加边框 - 与原始代码一致
    cv::copyMakeBorder(outImage, result.processed_image, 
                       top, bottom, left, right, 
                       cv::BORDER_CONSTANT, fill_color_);
    
    return result;
}

/**
 * @brief 还原到原图坐标
 * @param[in/out] box: 
 * @param[in/out] params: 
 * @return BoundingBox: 0 成功，其余错误码表示失败
 */
BoundingBox LetterBoxPreprocessor::restore_coordinates(
    const BoundingBox& box, 
    const PreprocessParams& params) const 
{
    float scale_x = params.transform_params[0];
    float scale_y = params.transform_params[1];
    int pad_left = static_cast<int>(params.transform_params[2]);
    int pad_top = static_cast<int>(params.transform_params[3]);
    
    BoundingBox restored;
    // 与原始代码完全一致的还原公式
    restored.left = static_cast<int>((box.left - pad_left) / scale_x);
    restored.top = static_cast<int>((box.top - pad_top) / scale_y);
    restored.right = static_cast<int>((box.right - pad_left) / scale_x);
    restored.bottom = static_cast<int>((box.bottom - pad_top) / scale_y);
    
    // 裁剪到原图范围
    restored.clip(params.original_size.width, params.original_size.height);
    
    return restored;
}

} // namespace detector
