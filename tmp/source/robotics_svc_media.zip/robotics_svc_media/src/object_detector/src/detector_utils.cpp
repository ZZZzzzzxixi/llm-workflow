/**
 * @file detector_utils.cpp
 * @brief 检测器工具函数实现
 * @author lzq
 * @version 1.0
 * @date 2025-12-25 10:18:12
 * 
 * Copyright (c) tuya.inc 2023-2033.
 * 
 */

#include "detector_utils.h"
#include "yolo_detector.h"
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <fstream>
#include <sstream>
#include <iomanip>

namespace detector {
namespace utils {

void draw_detections(
    cv::Mat& image,
    const DetectionList& detections,
    const cv::Scalar& color,
    int thickness)
{
    for (const auto& det : detections) {
        // 绘制边界框
        cv::rectangle(image,
                     cv::Point(det.box.left, det.box.top),
                     cv::Point(det.box.right, det.box.bottom),
                     color, thickness);
        
        // 绘制标签
        std::ostringstream oss;
        oss << det.class_name << " " 
            << std::fixed << std::setprecision(1) 
            << (det.confidence * 100) << "%";
        
        cv::putText(image, oss.str(),
                   cv::Point(det.box.left, det.box.top - 10),
                   cv::FONT_HERSHEY_SIMPLEX, 0.7,
                   color, 2);
    }
}

bool save_detection_image(
    const cv::Mat& image,
    const DetectionList& detections,
    const std::string& filename)
{
    cv::Mat output = image.clone();
    draw_detections(output, detections);
    return cv::imwrite(filename, output);
}

std::vector<std::string> load_labels(const std::string& filename) {
    std::vector<std::string> labels;
    std::ifstream file(filename);
    
    if (!file.is_open()) {
        return labels;
    }
    
    std::string line;
    while (std::getline(file, line)) {
        labels.push_back(line);
    }
    
    file.close();
    return labels;
}

std::string format_performance_stats(const PerformanceStats& stats) {
    std::ostringstream oss;
    
    oss << "========== Performance Statistics ==========\n";
    oss << std::fixed << std::setprecision(6);
    oss << "Preprocess  time: " << stats.preprocess_time << " s ("
        << std::setprecision(2) << (stats.preprocess_time / stats.total_time * 100) << "%)\n";
    oss << std::setprecision(6);
    oss << "Inference   time: " << stats.inference_time << " s ("
        << std::setprecision(2) << (stats.inference_time / stats.total_time * 100) << "%)\n";
    oss << std::setprecision(6);
    oss << "Postprocess time: " << stats.postprocess_time << " s ("
        << std::setprecision(2) << (stats.postprocess_time / stats.total_time * 100) << "%)\n";
    oss << std::setprecision(6);
    oss << "Total       time: " << stats.total_time << " s\n";
    oss << std::setprecision(2);
    oss << "FPS: " << stats.get_fps() << "\n";
    oss << "============================================";
    
    return oss.str();
}

} // namespace utils
} // namespace detector
