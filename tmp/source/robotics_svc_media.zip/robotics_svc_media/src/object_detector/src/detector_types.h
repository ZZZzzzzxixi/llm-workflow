/**
 * @file detector_types.cpp
 * @brief 目标检测器数据类型实现
 * @author lzq
 * @version 1.0
 * @date 2025-12-25 10:09:56
 * 
 * Copyright (c) tuya.inc 2023-2033.
 * 
 */

#ifndef __DETECTOR_TYPES_H__
#define __DETECTOR_TYPES_H__

#include <vector>
#include <string>
#include <opencv2/core/core.hpp>

namespace detector {

/**
 * @brief 边界框结构
 */
struct BoundingBox {
    int left;
    int top;
    int right;
    int bottom;

    BoundingBox() : left(0), top(0), right(0), bottom(0) {}
    
    BoundingBox(int l, int t, int r, int b) 
        : left(l), top(t), right(r), bottom(b) {}

    // 计算宽度
    int width() const { return right - left; }
    
    // 计算高度
    int height() const { return bottom - top; }
    
    // 计算面积
    int area() const { return width() * height(); }
    
    // 计算交并比
    float iou(const BoundingBox& other) const;
    
    // 裁剪到指定范围
    void clip(int max_width, int max_height);
};

/**
 * @brief 检测结果
 */
struct Detection {
    BoundingBox box;        // 边界框
    int class_id;           // 类别ID (0-79 for COCO)
    float confidence;       // 置信度 (0.0-1.0)
    std::string class_name; // 类别名称

    Detection() : class_id(-1), confidence(0.0f) {}
    
    Detection(const BoundingBox& b, int cls_id, float conf)
        : box(b), class_id(cls_id), confidence(conf) {}
};

/**
 * @brief 检测结果列表
 */
using DetectionList = std::vector<Detection>;

/**
 * @brief 预处理参数
 */
struct PreprocessParams {
    cv::Vec4d transform_params;  // letterbox变换参数 [scale_x, scale_y, pad_left, pad_top]
    cv::Size original_size;      // 原始图像尺寸
    cv::Size target_size;        // 目标尺寸
    
    PreprocessParams() : target_size(640, 640) {}
};

/**
 * @brief 数据类型枚举
 */
enum class DataType {
    INT8,
    FLOAT32
};

/**
 * @brief 量化参数
 */
struct QuantParams {
    int32_t zero_point;
    float scale;
    
    QuantParams() : zero_point(0), scale(1.0f) {}
    
    QuantParams(int32_t zp, float s) : zero_point(zp), scale(s) {}
};

} // namespace detector

#endif // __DETECTOR_TYPES_H__
