/**
 * @file postprocessor.h
 * @brief 后处理器接口
 * @author lzq
 * @version 1.0
 * @date 2025-12-25
 * 
 * Copyright (c) tuya.inc 2023-2033.
 * 
 */

#ifndef __POSTPROCESSOR_H__
#define __POSTPROCESSOR_H__

#include "detector_types.h"
#include "inference_engine.h"
#include <memory>

namespace detector {

/**
 * @brief 后处理器接口
 */
class IPostprocessor {
public:
    virtual ~IPostprocessor() = default;

    /**
     * @brief 处理推理输出
     * @param[out] raw_output: 推理引擎的原始输出
     * @param[in] config: 检测器配置
     * @return 检测结果列表
     */
    virtual DetectionList process(
        const InferenceOutput& raw_output,
        const YoloConfig& config) = 0;
};

/**
 * @brief YOLOv5后处理器
 */
class Yolov5Postprocessor : public IPostprocessor {
public:
    Yolov5Postprocessor() = default;
    ~Yolov5Postprocessor() override = default;
    
    DetectionList process(
        const InferenceOutput& raw_output,
        const YoloConfig& config) override;

    int decode_layer(
        const float* input,
        const int* anchor,
        int grid_h, int grid_w,
        int num_classes,
        int stride,
        float threshold,
        std::vector<float>& boxes,
        std::vector<float>& scores,
        std::vector<int>& class_ids);

private:
    /**
     * @brief 按置信度排序
     */
    void sort_by_confidence(
        std::vector<float>& scores,
        std::vector<int>& indices);
    
    /**
     * @brief 非极大值抑制 - 与原始代码nms函数签名一致
     */
    void apply_nms(
        int validCount,
        const std::vector<float>& outputLocations,
        const std::vector<int>& classIds,
        std::vector<int>& order,
        int filterId,
        float threshold);
    
    /**
     * @brief 转换为Detection结构
     */
    DetectionList convert_to_detections(
        const std::vector<float>& boxes,
        const std::vector<float>& scores,
        const std::vector<int>& class_ids,
        const std::vector<int>& indices,
        int model_width,
        int model_height);
};

/**
 * @brief YOLOv8后处理器
 */
class Yolov8Postprocessor : public IPostprocessor {
public:
    Yolov8Postprocessor() = default;
    ~Yolov8Postprocessor() override = default;
    
    DetectionList process(
        const InferenceOutput& raw_output,
        const YoloConfig& config) override;

    int decode_layer(
        const float* input,
        const int* anchor,
        int grid_h, int grid_w,
        int num_classes,
        int stride,
        float threshold,
        std::vector<float>& boxes,
        std::vector<float>& scores,
        std::vector<int>& class_ids);

private:
    /**
     * @brief 按置信度排序
     */
    void sort_by_confidence(
        std::vector<float>& scores,
        std::vector<int>& indices);
    
    /**
     * @brief 非极大值抑制 - 与原始代码nms函数签名一致
     */
    void apply_nms(
        int validCount,
        const std::vector<float>& outputLocations,
        const std::vector<int>& classIds,
        std::vector<int>& order,
        int filterId,
        float threshold);
    
    /**
     * @brief 转换为Detection结构
     */
    DetectionList convert_to_detections(
        const std::vector<float>& boxes,
        const std::vector<float>& scores,
        const std::vector<int>& class_ids,
        const std::vector<int>& indices,
        int model_width,
        int model_height);
};

} // namespace detector

#endif // __POSTPROCESSOR_H__
