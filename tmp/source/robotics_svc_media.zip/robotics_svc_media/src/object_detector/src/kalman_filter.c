/**
 * @file kalman_filter.c
 * @brief 简化卡尔曼滤波器
 * @author lzq
 * @version 1.0
 * @date 2026-01-12 17:08:06
 * @note    6维状态向量: [x, y, w, h, vx, vy]
 *          4维观测向量: [x, y, w, h]
 *          使用对角矩阵简化，避免矩阵求逆运算
 * Copyright (c) tuya.inc 2023-2033.
 * 
 */

#include "kalman_filter.h"
#include <string.h>

/* -------------------------------------------------------------------------- */
/*                              默认配置                                       */
/* -------------------------------------------------------------------------- */

/* 调参说明：
 * - process_noise 越大，越信任观测，响应越快（但可能更抖）
 * - measurement_noise 越大，越信任预测，越平滑（但可能滞后）
 * - Q/R 比值决定了平滑度 vs 响应速度的权衡
 */
#define DEFAULT_PROCESS_NOISE       0.05f   /**< 过程噪声（原0.01，增大以减少滞后）*/
#define DEFAULT_MEASUREMENT_NOISE   0.05f   /**< 观测噪声（原0.1，减小以更信任观测）*/
#define DEFAULT_INIT_VELOCITY_VAR   1.0f    /**< 初始速度方差 */

/* -------------------------------------------------------------------------- */
/*                              接口实现                                       */
/* -------------------------------------------------------------------------- */

/**
 * @brief 获取卡尔曼滤波器默认配置
 */
KF_CONFIG_T kf_get_default_config(void)
{
    KF_CONFIG_T config = {
        .process_noise = DEFAULT_PROCESS_NOISE,
        .measurement_noise = DEFAULT_MEASUREMENT_NOISE,
        .initial_velocity_var = DEFAULT_INIT_VELOCITY_VAR
    };
    return config;
}

/**
 * @brief 初始化卡尔曼滤波器
 */
void kf_init(KF_STATE_T* kf, const KF_CONFIG_T* config, 
             float initial_x, float initial_y, float initial_w, float initial_h)
{
    if (NULL == kf) {
        return;
    }
    
    memset(kf, 0, sizeof(KF_STATE_T));
    
    // 初始化状态向量 [x, y, w, h, vx, vy]
    kf->x[0] = initial_x;
    kf->x[1] = initial_y;
    kf->x[2] = initial_w;
    kf->x[3] = initial_h;
    kf->x[4] = 0.0f;  // 初始速度为0
    kf->x[5] = 0.0f;
    
    // 使用默认配置或传入配置
    KF_CONFIG_T cfg = (NULL != config) ? *config : kf_get_default_config();
    
    // 初始化协方差矩阵 P (对角)
    kf->P[0] = 1.0f;   // x
    kf->P[1] = 1.0f;   // y
    kf->P[2] = 1.0f;   // w
    kf->P[3] = 1.0f;   // h
    kf->P[4] = cfg.initial_velocity_var;  // 速度方差大
    kf->P[5] = cfg.initial_velocity_var;  // vy
    
    // 过程噪声 Q (对角)
    kf->Q[0] = cfg.process_noise;
    kf->Q[1] = cfg.process_noise;
    kf->Q[2] = cfg.process_noise;
    kf->Q[3] = cfg.process_noise;
    kf->Q[4] = cfg.process_noise * 10.0f; // 速度噪声更大
    kf->Q[5] = cfg.process_noise * 10.0f;
    
    // 观测噪声 R (对角)
    kf->R[0] = cfg.measurement_noise;
    kf->R[1] = cfg.measurement_noise;
    kf->R[2] = cfg.measurement_noise;
    kf->R[3] = cfg.measurement_noise;
    
    kf->initialized = TRUE;
}

/**
 * @brief 预测步骤
 * @param[in] kf: 卡尔曼滤波器状态指针
 * @param[in] dt: 时间间隔(秒)
 * @note 状态转移方程 (匀速运动模型):
 *   x' = x + vx * dt
 *   y' = y + vy * dt
 *   w' = w
 *   h' = h
 *   vx' = vx
 *   vy' = vy
 */
void kf_predict(KF_STATE_T* kf, float dt)
{
    if (NULL == kf || FALSE == kf->initialized || dt <= 0.0f) {
        return;
    }
    
    // 状态预测
    kf->x[0] += kf->x[4] * dt;  // x += vx * dt
    kf->x[1] += kf->x[5] * dt;  // y += vy * dt
    // w, h, vx, vy 保持不变
    
    // 由于 F 不是对角阵，需要特殊处理位置和速度的关联,同时为了简化处理，直接增加协方差
    float dt2 = dt * dt;
    kf->P[0] += kf->P[4] * dt2 + kf->Q[0];  // P_x 受 vx 影响
    kf->P[1] += kf->P[5] * dt2 + kf->Q[1];  // P_y 受 vy 影响
    kf->P[2] += kf->Q[2];
    kf->P[3] += kf->Q[3];
    kf->P[4] += kf->Q[4];
    kf->P[5] += kf->Q[5];
}

/**
 * @brief 更新步骤
 * 
 * 使用观测值修正预测值，并根据位置残差估计速度
 */
void kf_update(KF_STATE_T* kf, float z_x, float z_y, float z_w, float z_h)
{
    if (NULL == kf || FALSE == kf->initialized) {
        return;
    }
    
    // 观测向量
    float z[KF_MEAS_DIM] = {z_x, z_y, z_w, z_h};
    
    // 计算增益
    float K[KF_MEAS_DIM];
    for (int i = 0; i < KF_MEAS_DIM; i++) {
        float S = kf->P[i] + kf->R[i];
        K[i] = (S > 1e-6f) ? (kf->P[i] / S) : 0.0f;
    }
    
    // 计算残差 y = z - x_predicted
    float y[KF_MEAS_DIM];
    for (int i = 0; i < KF_MEAS_DIM; i++) {
        y[i] = z[i] - kf->x[i];
    }
    
    // 更新位置状态
    for (int i = 0; i < KF_MEAS_DIM; i++) {
        kf->x[i] += K[i] * y[i];
    }
    
    // 关键：根据位置残差更新速度
    // 残差表示预测位置和实际位置的差距，用它来修正速度估计
    float velocity_gain = 0.8f;  // 速度修正增益（增大到0.8以减少滞后）
    kf->x[4] += velocity_gain * y[0];  // vx += gain * (观测x - 预测x)
    kf->x[5] += velocity_gain * y[1];  // vy += gain * (观测y - 预测y)
    
    // 更新协方差
    for (int i = 0; i < KF_MEAS_DIM; i++) {
        kf->P[i] *= (1.0f - K[i]);
    }
}

/**
 * @brief 获取当前位置估计
 */
void kf_get_position(const KF_STATE_T* kf, float* x, float* y, float* w, float* h)
{
    if (NULL == kf || FALSE == kf->initialized) {
        return;
    }
    
    if (NULL != x) *x = kf->x[0];
    if (NULL != y) *y = kf->x[1];
    if (NULL != w) *w = kf->x[2];
    if (NULL != h) *h = kf->x[3];
}

/**
 * @brief 获取当前速度估计
 */
void kf_get_velocity(const KF_STATE_T* kf, float* vx, float* vy)
{
    if (NULL == kf || FALSE == kf->initialized) {
        return;
    }
    
    if (NULL != vx) *vx = kf->x[4];
    if (NULL != vy) *vy = kf->x[5];
}
