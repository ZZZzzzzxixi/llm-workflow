/**
 * @file yolov5_postprocessor.cpp
 * @brief YOLOv5后处理器实现 - 与原始代码object_detector.cpp一致
 * @author lzq
 * @version 1.0
 * @date 2025-12-29 11:33:44
 * 
 * Copyright (c) tuya.inc 2023-2033.
 * 
 */

#include "postprocessor.h"
#include <algorithm>
#include <set>
#include <cmath>
#include "uni_log.h"

namespace detector {

// 与原始代码相同的anchor配置
static const int g_anchors[3][6] = {
    {10, 13, 16, 30, 33, 23},
    {30, 61, 62, 45, 59, 119},
    {116, 90, 156, 198, 373, 326}
};

DetectionList Yolov5Postprocessor::process(
    const InferenceOutput& raw_output,
    const YoloConfig& config) 
{
    PR_INFO("Processing %zu layers\n", raw_output.layers.size());
    
    if (raw_output.layers.empty()) {
        PR_ERR("No output layers!\n");
        return DetectionList();
    }
    
    std::vector<float> filterBoxes;
    std::vector<float> objProbs;
    std::vector<int> classId;
    
    // 解码所有层
    for (size_t i = 0; i < raw_output.layers.size(); ++i) {
        const auto& layer = raw_output.layers[i];
        
        if (!layer.data) {
            PR_WARN("Layer %zu: data is NULL, skipping\n", i);
            continue;
        }
        
        PR_INFO("Layer %zu: grid=%dx%d, stride=%d\n",
               i, layer.grid_w, layer.grid_h, layer.stride);
        
        const int* anchor = (i < 3) ? g_anchors[i] : config.get_anchor(i);
        
        int num_dets = decode_layer(
            static_cast<const float*>(layer.data),
            anchor,
            layer.grid_h, layer.grid_w,
            config.model_height, config.model_width,
            layer.stride,
            config.conf_threshold,
            filterBoxes, objProbs, classId
        );
        
        PR_INFO("Layer %zu: found %d detections\n", i, num_dets);
    }
    
    int validCount = static_cast<int>(objProbs.size());
    PR_INFO("[%s] validCount = %d\n", __func__, validCount);
    
    if (validCount <= 0) {
        PR_INFO("[%s] validCount <= 0\n", __func__);
        return DetectionList();
    }
    
    std::vector<int> indexArray;
    for (int i = 0; i < validCount; ++i) {
        indexArray.push_back(i);
    }
    
    // 按置信度排序
    sort_by_confidence(objProbs, indexArray);
    
    // 获取所有唯一类别
    std::set<int> class_set(classId.begin(), classId.end());
    
    // NMS去重 - 对每个类别分别做NMS
    for (int c : class_set) {
        apply_nms(validCount, filterBoxes, classId, indexArray, c, config.nms_threshold);
    }
    
    // 转换为Detection结构
    return convert_to_detections(
        filterBoxes,
        objProbs,
        classId,
        indexArray,
        config.model_width,
        config.model_height);
}

/**
 * @brief 解码单层输出 - 与原始代码process_yolov5完全一致
 */
int Yolov5Postprocessor::decode_layer(
    const float* input,
    const int* anchor,
    int grid_h, int grid_w,
    int model_h, int model_w,
    int stride,
    float threshold,
    std::vector<float>& boxes,
    std::vector<float>& scores,
    std::vector<int>& class_ids)
{
    if (!input || !anchor || stride == 0) {
        PR_ERR("Invalid parameters\n");
        return 0;
    }

    int validCount = 0;
    int anchor_per_branch = 3;
    
    // 与原始postprocess.h中的定义一致
    // #define OBJ_CLASS_NUM 1
    // #define PROP_BOX_SIZE (5 + OBJ_CLASS_NUM) = 6
    const int OBJ_CLASS_NUM = 1;    // 单类别模型
    const int PROP_BOX_SIZE = 5 + OBJ_CLASS_NUM;  // = 6
    int align_c = PROP_BOX_SIZE * anchor_per_branch;
    
    const float* input_float = input;

    printf("process_yolov5 start, grid_h = %d, grid_w = %d, anchor_per_branch = %d\n", 
           grid_h, grid_w, anchor_per_branch);
    
    // 调试：打印前几个值
    if (grid_h == 80) {  // 只在第一层打印
        printf("DEBUG: First 20 values: ");
        for (int i = 0; i < 20 && i < grid_h * grid_w * align_c; ++i) {
            printf("%.4f ", input_float[i]);
        }
        printf("\n");
        
        // 找到最大的 box_confidence 值
        float max_conf = 0.0f;
        int max_h = 0, max_w = 0, max_a = 0;
        for (int h = 0; h < grid_h; h++) {
            for (int w = 0; w < grid_w; w++) {
                for (int a = 0; a < anchor_per_branch; a++) {
                    int hw_offset = h * grid_w * align_c + w * align_c + a * PROP_BOX_SIZE;
                    const float* hw_ptr = input_float + hw_offset;
                    if (hw_ptr[4] > max_conf) {
                        max_conf = hw_ptr[4];
                        max_h = h; max_w = w; max_a = a;
                    }
                }
            }
        }
        printf("DEBUG: Max box_confidence = %.6f at (h=%d, w=%d, a=%d), threshold=%.2f\n", 
               max_conf, max_h, max_w, max_a, threshold);
    }
    
    for (int h = 0; h < grid_h; h++) {
        for (int w = 0; w < grid_w; w++) {
            for (int a = 0; a < anchor_per_branch; a++) {
                int hw_offset = h * grid_w * align_c + w * align_c + a * PROP_BOX_SIZE;
                const float* hw_ptr = input_float + hw_offset;
                float box_confidence = hw_ptr[4];

                if (box_confidence >= threshold) {
                    float maxClassProbs = hw_ptr[5];
                    int maxClassId = 0;
                    for (int k = 1; k < OBJ_CLASS_NUM; ++k) {
                        float prob = hw_ptr[5 + k];
                        if (prob > maxClassProbs) {
                            maxClassId = k;
                            maxClassProbs = prob;
                        }
                    }

                    float box_conf_f32 = box_confidence;
                    float class_prob_f32 = maxClassProbs;
                    float limit_score = box_conf_f32 * class_prob_f32;

                    if (limit_score > threshold) {
                        float box_x, box_y, box_w, box_h;

                        box_x = hw_ptr[0] * 2.0 - 0.5;
                        box_y = hw_ptr[1] * 2.0 - 0.5;
                        box_w = hw_ptr[2] * 2.0;
                        box_h = hw_ptr[3] * 2.0;
                        box_w = box_w * box_w;
                        box_h = box_h * box_h;

                        box_x = (box_x + w) * (float)stride;
                        box_y = (box_y + h) * (float)stride;
                        box_w *= (float)anchor[a * 2];
                        box_h *= (float)anchor[a * 2 + 1];

                        box_x -= (box_w / 2.0);
                        box_y -= (box_h / 2.0);

                        // 存储格式：x, y, w, h
                        boxes.push_back(box_x);
                        boxes.push_back(box_y);
                        boxes.push_back(box_w);
                        boxes.push_back(box_h);
                        scores.push_back(limit_score);
                        class_ids.push_back(maxClassId);
                        validCount++;
                    }
                }
            }
        }
    }
    printf("process_yolov5 end\n");

    return validCount;
}

/**
 * @brief 按置信度降序排序
 */
void Yolov5Postprocessor::sort_by_confidence(
    std::vector<float>& scores,
    std::vector<int>& indices)
{
    std::sort(indices.begin(), indices.end(),
        [&scores](int a, int b) {
            return scores[a] > scores[b];
        });
}

/**
 * @brief 非极大值抑制 - 与原始代码nms完全一致
 */
void Yolov5Postprocessor::apply_nms(
    int validCount,
    const std::vector<float>& outputLocations,
    const std::vector<int>& classIds,
    std::vector<int>& order,
    int filterId,
    float threshold)
{
    for (int i = 0; i < validCount; ++i) {
        if (order[i] == -1 || classIds[i] != filterId) {
            continue;
        }
        int n = order[i];
        for (int j = i + 1; j < validCount; ++j) {
            int m = order[j];
            if (m == -1 || classIds[m] != filterId) {
                continue;
            }
            
            float xmin0 = outputLocations[n * 4 + 0];
            float ymin0 = outputLocations[n * 4 + 1];
            float xmax0 = outputLocations[n * 4 + 0] + outputLocations[n * 4 + 2];
            float ymax0 = outputLocations[n * 4 + 1] + outputLocations[n * 4 + 3];

            float xmin1 = outputLocations[m * 4 + 0];
            float ymin1 = outputLocations[m * 4 + 1];
            float xmax1 = outputLocations[m * 4 + 0] + outputLocations[m * 4 + 2];
            float ymax1 = outputLocations[m * 4 + 1] + outputLocations[m * 4 + 3];

            float w = fmax(0.f, fmin(xmax0, xmax1) - fmax(xmin0, xmin1) + 1.0);
            float h = fmax(0.f, fmin(ymax0, ymax1) - fmax(ymin0, ymin1) + 1.0);
            float inter = w * h;
            float u = (xmax0 - xmin0 + 1.0) * (ymax0 - ymin0 + 1.0) + 
                      (xmax1 - xmin1 + 1.0) * (ymax1 - ymin1 + 1.0) - inter;
            float iou = u <= 0.f ? 0.f : (inter / u);

            if (iou > threshold) {
                order[j] = -1;
            }
        }
    }
}

/**
 * @brief 转换为Detection结构 - 与原始代码一致
 */
DetectionList Yolov5Postprocessor::convert_to_detections(
    const std::vector<float>& filterBoxes,
    const std::vector<float>& objProbs,
    const std::vector<int>& classId,
    const std::vector<int>& indexArray,
    int model_width,
    int model_height)
{
    DetectionList detections;
    int validCount = static_cast<int>(indexArray.size());
    
    auto clamp = [](float val, int min_val, int max_val) -> int {
        return val > min_val ? (val < max_val ? static_cast<int>(val) : max_val) : min_val;
    };

    for (int i = 0; i < validCount; ++i) {
        if (indexArray[i] == -1) {
            continue;
        }
        
        int n = indexArray[i];

        float x1 = filterBoxes[n * 4 + 0];
        float y1 = filterBoxes[n * 4 + 1];
        float x2 = x1 + filterBoxes[n * 4 + 2];
        float y2 = y1 + filterBoxes[n * 4 + 3];
        int id = classId[n];
        float obj_conf = objProbs[n];

        BoundingBox box(
            clamp(x1, 0, model_width),
            clamp(y1, 0, model_height),
            clamp(x2, 0, model_width),
            clamp(y2, 0, model_height)
        );
        
        Detection det(box, id, obj_conf);
        detections.push_back(det);
    }
    
    PR_INFO("Found %zu valid detections\n", detections.size());
    return detections;
}

} // namespace detector
