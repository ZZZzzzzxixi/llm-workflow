/**
 * @file yolov5_postprocessor.cpp
 * @brief YOLOv5后处理器实现
 * @author lzq
 * @version 1.0
 * @date 2025-12-29 11:33:44
 * 
 * Copyright (c) tuya.inc 2023-2033.
 * 
 */

#include "postprocessor.h"
#include <algorithm>
#include <set>
#include <cmath>
#include "uni_log.h"

namespace detector {

/**
 * @brief 处理推理输出，生成检测结果
 * @param[in] raw_output: 推理引擎的原始输出
 * @param[in] config: 检测器配置
 * @return DetectionList: 检测结果列表
 */
DetectionList Yolov5Postprocessor::process(
    const InferenceOutput& raw_output,
    const YoloConfig& config) 
{
    if (raw_output.layers.empty()) {
        PR_WARN("No output layers");
        return DetectionList();
    }
    
    std::vector<float> filterBoxes;
    std::vector<float> objProbs;
    std::vector<int> classId;
    
    // 解码所有层
    for (size_t i = 0; i < raw_output.layers.size(); ++i) {
        const auto& layer = raw_output.layers[i];
        
        if (!layer.data) {
            continue;
        }
        
        // 统一使用配置中的 anchor
        const int* anchor = config.get_anchor(static_cast<int>(i));
        
        decode_layer(
            static_cast<const float*>(layer.data),
            anchor,
            layer.grid_h, layer.grid_w,
            config.num_classes,
            layer.stride,
            config.conf_threshold,
            filterBoxes, objProbs, classId
        );
    }
    
    int validCount = static_cast<int>(objProbs.size());
    
    if (validCount <= 0) {
        return DetectionList();
    }
    
    std::vector<int> indexArray;
    for (int i = 0; i < validCount; ++i) {
        indexArray.push_back(i);
    }
    
    // 按置信度排序
    sort_by_confidence(objProbs, indexArray);
    
    // 获取所有唯一类别
    std::set<int> class_set(classId.begin(), classId.end());
    
    // NMS去重
    for (int c : class_set) {
        apply_nms(validCount, filterBoxes, classId, indexArray, c, config.nms_threshold);
    }
    
    // 转换为Detection结构
    return convert_to_detections(
        filterBoxes,
        objProbs,
        classId,
        indexArray,
        config.model_width,
        config.model_height);
}

/**
 * @brief 解码单层输出
 * @param[in] input: 输入数据指针
 * @param[in] anchor: 当前层的anchor配置
 * @param[in] grid_h: 网格高度
 * @param[in] grid_w: 网格宽度
 * @param[in] num_classes: 类别数量
 * @param[in] stride: 步长
 * @param[in] threshold: 置信度阈值
 * @param[out] boxes: 输出边界框列表
 * @param[out] scores: 输出置信度列表
 * @param[out] class_ids: 输出类别ID列表
 * @return int: 检测到的目标数量
 */
int Yolov5Postprocessor::decode_layer(
    const float* input,
    const int* anchor,
    int grid_h, int grid_w,
    int num_classes,
    int stride,
    float threshold,
    std::vector<float>& boxes,
    std::vector<float>& scores,
    std::vector<int>& class_ids)
{
    if (!input || !anchor || stride == 0) {
        return 0;
    }

    int validCount = 0;
    const int anchor_per_branch = 3;
    const int prop_box_size = 5 + num_classes;
    const int align_c = prop_box_size * anchor_per_branch;
    
    const float* input_float = input;
    
    for (int h = 0; h < grid_h; h++) {
        for (int w = 0; w < grid_w; w++) {
            for (int a = 0; a < anchor_per_branch; a++) {
                int hw_offset = h * grid_w * align_c + w * align_c + a * prop_box_size;
                const float* hw_ptr = input_float + hw_offset;
                float box_confidence = hw_ptr[4];

                if (box_confidence >= threshold) {
                    float maxClassProbs = hw_ptr[5];
                    int maxClassId = 0;
                    for (int k = 1; k < num_classes; ++k) {
                        float prob = hw_ptr[5 + k];
                        if (prob > maxClassProbs) {
                            maxClassId = k;
                            maxClassProbs = prob;
                        }
                    }

                    float limit_score = box_confidence * maxClassProbs;

                    if (limit_score > threshold) {
                        float box_x, box_y, box_w, box_h;

                        box_x = hw_ptr[0] * 2.0 - 0.5;
                        box_y = hw_ptr[1] * 2.0 - 0.5;
                        box_w = hw_ptr[2] * 2.0;
                        box_h = hw_ptr[3] * 2.0;
                        box_w = box_w * box_w;
                        box_h = box_h * box_h;

                        box_x = (box_x + w) * (float)stride;
                        box_y = (box_y + h) * (float)stride;
                        box_w *= (float)anchor[a * 2];
                        box_h *= (float)anchor[a * 2 + 1];

                        box_x -= (box_w / 2.0);
                        box_y -= (box_h / 2.0);

                        boxes.push_back(box_x);
                        boxes.push_back(box_y);
                        boxes.push_back(box_w);
                        boxes.push_back(box_h);
                        scores.push_back(limit_score);
                        class_ids.push_back(maxClassId);
                        validCount++;
                    }
                }
            }
        }
    }

    return validCount;
}

/**
 * @brief 按置信度降序排序
 * @param[in] scores: 置信度列表
 * @param[in/out] indices: 索引列表
 */
void Yolov5Postprocessor::sort_by_confidence(
    std::vector<float>& scores,
    std::vector<int>& indices)
{
    std::sort(indices.begin(), indices.end(),
        [&scores](int a, int b) {
            return scores[a] > scores[b];
        });
}

/**
 * @brief 非极大值抑制
 * @param[in] validCount: 有效检测数量
 * @param[in] outputLocations: 边界框列表
 * @param[in] classIds: 类别ID列表
 * @param[in/out] order: 索引排序列表
 * @param[in] filterId: 当前处理的类别ID
 * @param[in] threshold: NMS阈值
 */
void Yolov5Postprocessor::apply_nms(
    int validCount,
    const std::vector<float>& outputLocations,
    const std::vector<int>& classIds,
    std::vector<int>& order,
    int filterId,
    float threshold)
{
    for (int i = 0; i < validCount; ++i) {
        if (order[i] == -1 || classIds[i] != filterId) {
            continue;
        }
        int n = order[i];
        for (int j = i + 1; j < validCount; ++j) {
            int m = order[j];
            if (m == -1 || classIds[m] != filterId) {
                continue;
            }
            
            float xmin0 = outputLocations[n * 4 + 0];
            float ymin0 = outputLocations[n * 4 + 1];
            float xmax0 = outputLocations[n * 4 + 0] + outputLocations[n * 4 + 2];
            float ymax0 = outputLocations[n * 4 + 1] + outputLocations[n * 4 + 3];

            float xmin1 = outputLocations[m * 4 + 0];
            float ymin1 = outputLocations[m * 4 + 1];
            float xmax1 = outputLocations[m * 4 + 0] + outputLocations[m * 4 + 2];
            float ymax1 = outputLocations[m * 4 + 1] + outputLocations[m * 4 + 3];

            float w = fmax(0.f, fmin(xmax0, xmax1) - fmax(xmin0, xmin1) + 1.0);
            float h = fmax(0.f, fmin(ymax0, ymax1) - fmax(ymin0, ymin1) + 1.0);
            float inter = w * h;
            float u = (xmax0 - xmin0 + 1.0) * (ymax0 - ymin0 + 1.0) + 
                      (xmax1 - xmin1 + 1.0) * (ymax1 - ymin1 + 1.0) - inter;
            float iou = u <= 0.f ? 0.f : (inter / u);

            if (iou > threshold) {
                order[j] = -1;
            }
        }
    }
}

/**
 * @brief 转换为Detection结构
 * @param[in] filterBoxes: 边界框列表
 * @param[in] objProbs: 置信度列表
 * @param[in] classId: 类别ID列表
 * @param[in] indexArray: 索引列表
 * @param[in] model_width: 模型输入宽度
 * @param[in] model_height: 模型输入高度
 * @return DetectionList: 检测结果列表
 */
DetectionList Yolov5Postprocessor::convert_to_detections(
    const std::vector<float>& filterBoxes,
    const std::vector<float>& objProbs,
    const std::vector<int>& classId,
    const std::vector<int>& indexArray,
    int model_width,
    int model_height)
{
    DetectionList detections;
    int validCount = static_cast<int>(indexArray.size());
    
    auto clamp = [](float val, int min_val, int max_val) -> int {
        return val > min_val ? (val < max_val ? static_cast<int>(val) : max_val) : min_val;
    };

    for (int i = 0; i < validCount; ++i) {
        if (indexArray[i] == -1) {
            continue;
        }
        
        int n = indexArray[i];

        float x1 = filterBoxes[n * 4 + 0];
        float y1 = filterBoxes[n * 4 + 1];
        float x2 = x1 + filterBoxes[n * 4 + 2];
        float y2 = y1 + filterBoxes[n * 4 + 3];
        int id = classId[n];
        float obj_conf = objProbs[n];

        BoundingBox box(
            clamp(x1, 0, model_width),
            clamp(y1, 0, model_height),
            clamp(x2, 0, model_width),
            clamp(y2, 0, model_height)
        );
        
        Detection det(box, id, obj_conf);
        detections.push_back(det);
    }
    
    return detections;
}

} // namespace detector
