/**
 * @file inference_engine.h
 * @brief npu推理引擎接口
 * @author lzq
 * @version 1.0
 * @date 2025-12-30 14:41:27
 * 
 * Copyright (c) tuya.inc 2023-2033.
 * 
 */

#ifndef __INFERENCE_ENGINE_H__
#define __INFERENCE_ENGINE_H__

#include "detector_types.h"
#include <opencv2/core/core.hpp>
#include <vector>
#include <memory>
#include "tkl_npu.h"
namespace detector {

/**
 * @brief 推理输出层信息
 */
struct OutputLayerInfo {
    void* data;             // 输出数据指针（由tkl_npu管理，不需要释放）
    size_t size;            // 数据大小（字节）
    int grid_h;             // 网格高度
    int grid_w;             // 网格宽度
    int stride;             // 步长
    QuantParams quant;      // 量化参数
    
    OutputLayerInfo() 
        : data(nullptr), size(0), grid_h(0), grid_w(0), stride(0) {}
};

/**
 * @brief 推理输出结果
 */
struct InferenceOutput {
    std::vector<OutputLayerInfo> layers;  // 多层输出
    DataType data_type;                   // 数据类型
    
    InferenceOutput() : data_type(DataType::FLOAT32) {}
};

/**
 * @brief 推理引擎接口
 */
class IInferenceEngine {
public:
    virtual ~IInferenceEngine() = default;
    
    /**
     * @brief 初始化引擎
     * @param model_path 模型文件路径
     * @return 0成功，<0失败
     */
    virtual int initialize(const char* model_path) = 0;
    
    /**
     * @brief 执行推理
     * @param input 输入图像（已预处理）
     * @return 推理输出
     */
    virtual InferenceOutput run(const cv::Mat& input) = 0;
    
    /**
     * @brief 释放资源
     */
    virtual void release() = 0;
};

/**
 * @brief TKL NPU推理引擎
 * 
 * 封装 tkl_npu 接口
 */
class TklNpuEngine : public IInferenceEngine {
public:
    TklNpuEngine();
    ~TklNpuEngine() override;
    
    int initialize(const char* model_path) override;
    InferenceOutput run(const cv::Mat& input) override;
    void release() override;

private:
    int npu_handle_;
    bool initialized_;
    tkl_npu_data *data_;
};

} // namespace detector

#endif // __INFERENCE_ENGINE_H__
