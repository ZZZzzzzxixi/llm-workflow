/**
 * @file tkl_npu_engine.cpp
 * @brief TKL NPU推理引擎实现
 * @author lzq
 * @version 1.0
 * @date 2025-12-29 16:18:00
 * 
 * Copyright (c) tuya.inc 2023-2033.
 * 
 */

#include "inference_engine.h"
#include "tkl_npu.h"
#include <cstring>
#include "uni_log.h"
// #include "yolov5.h"  

// extern rknn_app_context_t g_rknn_app_ctx;

namespace detector {

TklNpuEngine::TklNpuEngine()
    : npu_handle_(-1)
    , model_width_(640)
    , model_height_(640)
    , is_quantized_(true)
    , initialized_(false)
{
}

TklNpuEngine::~TklNpuEngine() {
    release();
}

int TklNpuEngine::initialize(const char* model_path) {
    if (initialized_) {
        return 0;  // 已初始化
    }
    
    PR_INFO("Initializing with model: %s", model_path);
    
    data_ = tkl_npu_param_create();
    npu_handle_ = tkl_npu_init(const_cast<char*>(model_path), data_);
    if (npu_handle_ < 0) {
        PR_ERR("tkl_npu_init failed: %d\n", npu_handle_);
        return -1;
    }
    
    // // 获取模型信息
    // tkl_npu_model_info* info = tkl_get_info();
    // if (info) {
    //     model_width_ = info->model_width;
    //     model_height_ = info->model_height;
    //     PR_INFO("Model size: %dx%d\n", model_width_, model_height_);
        
    //     if (model_width_ == 0 || model_height_ == 0) {
    //         model_width_ = 640;
    //         model_height_ = 640;
    //         PR_WARN("Using default size: %dx%d\n", model_width_, model_height_);
    //     }
        
    //     is_quantized_ = true;
    // } else {
    //     PR_WARN("Failed to get model info, using defaults\n");
    //     model_width_ = 640;
    //     model_height_ = 640;
    // }

    // 获取模型信息
    if (data_) {
        model_width_ = data_->model_width;
        model_height_ = data_->model_height;
        PR_INFO("Model size: %dx%d\n", model_width_, model_height_);
        
        if (model_width_ == 0 || model_height_ == 0) {
            model_width_ = 640;
            model_height_ = 640;
            PR_WARN("Using default size: %dx%d\n", model_width_, model_height_);
        }
        
        is_quantized_ = true;
    } else {
        PR_WARN("Failed to get model info, using defaults\n");
        model_width_ = 640;
        model_height_ = 640;
    }

    
    
    initialized_ = true;
    return 0;
}

InferenceOutput TklNpuEngine::run(const cv::Mat& input) {
    InferenceOutput output;
    
    if (!initialized_ || npu_handle_ < 0) {
        PR_ERR("Not initialized!\n");
        return output;
    }
    
    PR_INFO("Input: %dx%d, channels=%d\n", 
           input.cols, input.rows, input.channels());
    
    // if (g_rknn_app_ctx.input_mems[0] && g_rknn_app_ctx.input_mems[0]->virt_addr) {
    //     memcpy(g_rknn_app_ctx.input_mems[0]->virt_addr, input.data, 
    //            input.total() * input.elemSize());
    //     PR_INFO("Copied %zu bytes to NPU input memory\n", input.total() * input.elemSize());
    // } else {
    //     PR_WARN("NPU input memory not available, using direct pointer\n");
    // }

    PR_INFO("data->input_tensors.tensors[0].size = %d\n", data_->input_tensors.tensors[0].size);
    memcpy(data_->input_tensors.tensors[0].data, input.data, data_->input_tensors.tensors[0].size);   //把输入数据更新到data中

    // 执行推理
    int ret = tkl_npu_run(npu_handle_, data_);
    
    if (ret < 0) {
        PR_ERR("tkl_npu_run failed: %d\n", ret);
        return output;
    }
    
    tkl_npu_dequantization_tensors *outputdata = NULL;
    int outputnums = tkl_npu_get_output_tensors(npu_handle_, &outputdata);

    PR_INFO("Output layers: %d\n", outputnums);
    
    if (outputnums <= 0) {
        PR_ERR("No output data!\n");
        return output;
    }
    
    // 填充输出层信息
    output.data_type = DataType::FLOAT32;  

    #if 0
        output.layers.resize(outputnums);
        for (int i = 0; i < outputnums; ++i) {
            OutputLayerInfo& layer = output.layers[i];
            
            if (!outputdata->dequantization_tensor[i].data) {
                PR_WARN("Layer %d: data is NULL!\n", i);
                continue;
            }
            
            // 直接使用tkl_npu返回的float数据（数据由tkl_npu管理）
            layer.data = outputdata->dequantization_tensor[i].data;
            layer.size = outputdata->dequantization_tensor[i].size;
            
            // 获取模型信息
            layer.grid_h = data_->output_tensors.tensors[i].dims[2];
            layer.grid_w = data_->output_tensors.tensors[i].dims[1];
            layer.stride = model_height_ / layer.grid_h;
            
            // 量化参数（虽然已经反量化了，但保留信息）
            layer.quant.zero_point = data_->output_tensors.tensors[i].zp;
            layer.quant.scale = data_->output_tensors.tensors[i].scale;
            
            // 新增：打印dims数组的长度和所有元素（关键！）
            int dims_len = data_->output_tensors.tensors[i].n_dims; // 先确认dims数组的长度（不同SDK字段名可能是dim_count/ndims）
            PR_INFO("Layer %d: dims长度=%d, dims数组=[", i, dims_len);
            for (int j = 0; j < dims_len; j++) {
                PR_INFO("%d%s", data_->output_tensors.tensors[i].dims[j], (j==dims_len-1) ? "]\n" : ", ");
            }

            PR_INFO("Layer %d: grid=%dx%d, stride=%d, size=%ld, dims=%dx%dx%d\n",
                i, layer.grid_w, layer.grid_h, layer.stride, layer.size,
                data_->output_tensors.tensors[i].dims[1],
                data_->output_tensors.tensors[i].dims[2],
                data_->output_tensors.tensors[i].dims[3]);
        }
    #else
        for (int i = 0; i < outputnums; ++i) {
            OutputLayerInfo layer;
            memset(&layer, 0, sizeof(OutputLayerInfo));

            if (!outputdata->dequantization_tensor[i].data) {
                PR_WARN("Layer %d: data is NULL!\n", i);
                continue;
            }
            
            // 直接使用tkl_npu返回的float数据（数据由tkl_npu管理）
            layer.data = outputdata->dequantization_tensor[i].data;
            layer.size = outputdata->dequantization_tensor[i].size;

            // 量化参数（虽然已经反量化了，但保留信息）
            layer.quant.zero_point = data_->output_tensors.tensors[i].zp;
            layer.quant.scale = data_->output_tensors.tensors[i].scale;
            
            // 新修复代码：手动还原YOLOv5 3个检测层的grid和stride（适配NPU拼接后的张量）
            // 第一步：定义YOLOv5 640×640的3个检测层参数（固定值）
            const int grid_sizes[3] = {80, 40, 20};    // 小/中/大目标层的grid尺寸（h=w）
            const int strides[3] = {8, 16, 32};        // 对应stride（640/80=8，640/40=16，640/20=32）
            const int grid_counts[3] = {6400, 1600, 400}; // 每个层的空间维度长度（80×80=6400，40×40=1600，20×20=400）

            // 第二步：因为NPU把3层拼接成1个张量，需要拆分处理
            if (outputnums == 1) { // 只有1个输出张量（拼接后的）
                // 遍历3个检测层（原本的3层，现在合并在1个张量里）
                for (int layer_idx = 0; layer_idx < 3; layer_idx++) {
                    OutputLayerInfo sub_layer; // 定义每个子层的信息
                    sub_layer.grid_h = grid_sizes[layer_idx];
                    sub_layer.grid_w = grid_sizes[layer_idx];
                    sub_layer.stride = strides[layer_idx];
                    sub_layer.quant = layer.quant; // 复用量化参数
                    
                    // 拆分张量数据：从总数据中截取当前层的部分（关键！）
                    int start_offset = 0;
                    for (int k = 0; k < layer_idx; k++) {
                        start_offset += grid_counts[k] * 84; // 84是通道数，对应dims[1]
                    }
                    // 数据指针偏移：指向当前层的起始位置
                    sub_layer.data = (float*)((char*)layer.data + start_offset);
                    sub_layer.size = grid_counts[layer_idx] * 84 * sizeof(float); // 当前层的总字节数
                    
                    // 打印修正后的维度信息（验证）
                    PR_INFO("SubLayer %d: grid=%dx%d, stride=%d, size=%ld\n",
                        layer_idx, sub_layer.grid_w, sub_layer.grid_h,
                        sub_layer.stride, sub_layer.size);
                    
                    // 把拆分后的子层加入输出列表，供后处理使用
                    output.layers.push_back(sub_layer);
                }
            } else {
                // 兼容正常情况（如果NPU输出3个独立张量）
                layer.grid_h = grid_sizes[i];
                layer.grid_w = grid_sizes[i];
                layer.stride = strides[i];
            }
            
            // 打印拆分后的子层信息（新增）
            if (outputnums == 1) {
                for (int j = 0; j < output.layers.size(); j++) {
                    PR_INFO("SubLayer %d: grid=%dx%d, stride=%d\n",
                        j, output.layers[j].grid_w,
                        output.layers[j].grid_h,
                        output.layers[j].stride);
                }
            }
        }
    #endif
    return output;
}

void TklNpuEngine::release() {
    if (initialized_ && npu_handle_ >= 0) {
        tkl_npu_release(npu_handle_);
        npu_handle_ = -1;
        initialized_ = false;
    }
}

} // namespace detector
