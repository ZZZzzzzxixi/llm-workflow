/**
 * @file tkl_npu_engine.cpp
 * @brief TKL NPU推理引擎实现
 * @author lzq
 * @version 1.0
 * @date 2025-12-29 16:18:00
 * 
 * Copyright (c) tuya.inc 2023-2033.
 * 
 */

#include "inference_engine.h"
#include "tkl_npu.h"
#include <cstring>
#include "uni_log.h"

namespace detector {

TklNpuEngine::TklNpuEngine()
    : npu_handle_(-1)
    , initialized_(false)
    , data_(nullptr)
{
}

TklNpuEngine::~TklNpuEngine() {
    release();
}

/**
 * @brief 初始化NPU推理引擎
 * @param[in] model_path: 模型文件路径
 * @return 0 成功，其余错误码表示失败
 */
int TklNpuEngine::initialize(const char* model_path) {
    if (initialized_) {
        return 0;
    }
    
    PR_INFO("Initializing NPU with model: %s", model_path);
    
    data_ = tkl_npu_param_create();
    if (nullptr == data_) {
        PR_ERR("tkl_npu_param_create failed");
        return -1;
    }
    
    npu_handle_ = tkl_npu_init(const_cast<char*>(model_path), data_);
    if (npu_handle_ < 0) {
        PR_ERR("tkl_npu_init failed: %d", npu_handle_);
        tkl_npu_param_destroy(data_);
        data_ = nullptr;
        return -1;
    }
    
    PR_INFO("NPU init success. Input tensors: %d, Output tensors: %d", 
            data_->input_tensors.tensor_num, data_->output_tensors.tensor_num);
    
    initialized_ = true;
    return 0;
}

/**
 * @brief 执行NPU推理
 * @param[in] input: 预处理后的输入图像
 * @return InferenceOutput: 推理输出结果
 */
InferenceOutput TklNpuEngine::run(const cv::Mat& input) {
    InferenceOutput output;
    
    // 基本状态检查
    if (!initialized_ || npu_handle_ < 0 || !data_) {
        PR_ERR("NPU not ready. handle: %d, data: %p", npu_handle_, data_);
        return output;
    }

    // 详细的内存边界检查
    size_t mat_byte_size = input.total() * input.elemSize();
    int tensor_byte_size = data_->input_tensors.tensors[0].size;
    
    if (mat_byte_size != tensor_byte_size) {
        PR_ERR("Dimension mismatch! Mat bytes: %zu, Tensor bytes: %d", mat_byte_size, tensor_byte_size);
        // return output; // 根据情况决定是否退出
    }

    if (!data_->input_tensors.tensors[0].data) {
        PR_ERR("NPU input buffer is NULL!");
        return output;
    }

    // 执行拷贝 (确保不溢出)
    size_t copy_size = std::min((size_t)tensor_byte_size, mat_byte_size);
    memcpy(data_->input_tensors.tensors[0].data, input.data, copy_size);

    // 执行推理
    int ret = tkl_npu_run(npu_handle_, data_);
    
    if (ret < 0) {
        PR_ERR("tkl_npu_run failed: %d", ret);
        return output;
    }
    
    tkl_npu_dequantization_tensors* outputdata_raw = nullptr;
    int outputnums = tkl_npu_get_output_tensors(npu_handle_, &outputdata_raw);
    
    if (outputnums <= 0 || !outputdata_raw) {
        PR_ERR("No output data from get_output_tensors");
        return output;
    }

    tkl_npu_dequantization_tensor* outputdata = outputdata_raw->dequantization_tensor;
    
    output.data_type = DataType::FLOAT32;  

    // 4. 处理 YOLOv8 输出 (1x84x8400)
    #ifdef DET_USING_YOLOV8
    {

        int dimensions = 84; 
        int rows = 8400;

        // 由于 NPU 输出是 [84, 8400]，需要转置为 [8400, 84]
        // 否则后处理指针读取的数据是错位的
        unsigned char* raw_ptr = outputdata[0].data;
        
        // 使用 OpenCV 进行高效转置
        cv::Mat mat_src(dimensions, rows, CV_32FC1, raw_ptr);
        cv::Mat mat_dst = mat_src.t(); // 转置操作

        // 将转置后的数据存入 output
        cv::Mat m_transposed_data;
        m_transposed_data = mat_dst.clone(); 

        OutputLayerInfo layer;
        layer.data = m_transposed_data.data;    // 指向转置后的行优先数据
        layer.size = m_transposed_data.total() * m_transposed_data.elemSize();
        layer.grid_w = rows;                    // 存储总行数 8400
        layer.grid_h = dimensions;              // 存储维度 84
        layer.stride = 0;                       // YOLOv8 不使用 stride 概念
        
        output.layers.push_back(layer);
        PR_INFO("YOLOv8 Data Transposed to 8400x84.");
    }
    #endif
    #ifdef DET_USING_YOLOV5
    {
        output.layers.resize(outputnums);
        
        for (int i = 0; i < outputnums; ++i) {
            OutputLayerInfo& layer = output.layers[i];
            
            if (!outputdata[i].data) {
                PR_WARN("Layer %d: data is NULL", i);
                continue;
            }
            
            layer.data = outputdata[i].data;
            layer.size = outputdata[i].size;
            
            if (data_->output_tensors.tensor_num > i) {
                tkl_npu_tensor& t = data_->output_tensors.tensors[i];
                layer.grid_w = t.dims[1]; 
                layer.grid_h = t.dims[2];
                layer.quant.zero_point = t.zp;
                layer.quant.scale = t.scale;
            }
            
            if (layer.grid_h > 0)
                layer.stride = input.rows / layer.grid_h;
            else 
                layer.stride = 0;
        }
    }
    #endif
    
    return output;
}

/**
 * @brief 释放NPU资源
 */
void TklNpuEngine::release() {
    if (initialized_ && npu_handle_ >= 0) {
        tkl_npu_release(npu_handle_);
        npu_handle_ = -1;
    }
    
    if (nullptr != data_) {
        tkl_npu_param_destroy(data_);
        data_ = nullptr;
    }
    
    initialized_ = false;
}

} // namespace detector
