/**
 * @file detection_tracker.c
 * @brief 目标检测跟踪器实现
 * @author lzq
 * @version 1.0
 * @date 2026-01-12 18:00:31
 * 
 * Copyright (c) tuya.inc 2023-2033.
 * 
 */

#include "object_detector_internal.h"
#include "kalman_filter.h"
#include "tal_time_service.h"
#include <string.h>
#include <math.h>
#include <pthread.h>
#include "uni_log.h"

/* -------------------------------------------------------------------------- */
/*                              私有变量                                       */
/* -------------------------------------------------------------------------- */

static DET_TRACK_TARGET_T s_tracks[DET_MAX_TRACK_TARGETS];
static KF_STATE_T s_kf[DET_MAX_TRACK_TARGETS];  /**< 每个目标对应的卡尔曼滤波器 */
static int32_t s_track_count = 0;
static DET_TRACKER_CONFIG_T s_config;
static int32_t s_tracker_initialized = 0;
static pthread_mutex_t s_tracker_mutex = PTHREAD_MUTEX_INITIALIZER;

/* -------------------------------------------------------------------------- */
/*                              私有函数                                       */
/* -------------------------------------------------------------------------- */

/**
 * @brief 计算两个框的中心点距离
 * @param[in] x1: 第一个框的x坐标
 * @param[in] y1: 第一个框的y坐标
 * @param[in] w1: 第一个框的宽度
 * @param[in] h1: 第一个框的高度
 * @param[in] x2: 第二个框的x坐标
 * @param[in] y2: 第二个框的y坐标
 * @param[in] w2: 第二个框的宽度
 * @param[in] h2: 第二个框的高度
 * @return 中心点距离
 */
static float __calc_center_distance(float x1, float y1, float w1, float h1,
                                    float x2, float y2, float w2, float h2)
{
    float cx1 = x1 + w1 / 2.0f;
    float cy1 = y1 + h1 / 2.0f;
    float cx2 = x2 + w2 / 2.0f;
    float cy2 = y2 + h2 / 2.0f;
    
    return sqrtf((cx1 - cx2) * (cx1 - cx2) + (cy1 - cy2) * (cy1 - cy2));
}

/**
 * @brief 计算两个框的IOU
 * @param[in] x1: 第一个框的x坐标
 * @param[in] y1: 第一个框的y坐标
 * @param[in] w1: 第一个框的宽度
 * @param[in] h1: 第一个框的高度
 * @param[in] x2: 第二个框的x坐标
 * @param[in] y2: 第二个框的y坐标
 * @param[in] w2: 第二个框的宽度
 * @param[in] h2: 第二个框的高度
 * @return IOU值
 */
static float __calc_iou(float x1, float y1, float w1, float h1,
                        float x2, float y2, float w2, float h2)
{
    float left = fmaxf(x1, x2);
    float top = fmaxf(y1, y2);
    float right = fminf(x1 + w1, x2 + w2);
    float bottom = fminf(y1 + h1, y2 + h2);
    
    if (right <= left || bottom <= top) {
        return 0.0f;
    }
    
    float inter = (right - left) * (bottom - top);
    float union_area = w1 * h1 + w2 * h2 - inter;
    
    return (union_area > 0.0f) ? (inter / union_area) : 0.0f;
}

/**
 * @brief 获取当前跟踪目标数量（内部版本，调用时必须持有锁）
 * @return int32_t: 跟踪目标数量
 */
static int32_t __det_tracker_get_count_internal(void)
{
    int32_t count = 0;
    for (int32_t t = 0; t < s_track_count; t++) {
        if (0 != s_tracks[t].is_valid) {
            count++;
        }
    }
    return count;
}

/**
 * @brief 老化所有有效目标（递增 frames_since_update）
 * @note 必须在持有锁时调用
 * @return 
 */
static void __age_all_tracks(void)
{
    for (int32_t t = 0; t < s_track_count; t++) {
        if (0 != s_tracks[t].is_valid) {
            s_tracks[t].frames_since_update++;
        }
    }
}

/**
 * @brief 标记超时目标为无效
 * @note 必须在持有锁时调用
 * @return 
 */
static void __mark_timeout_tracks(void)
{
    for (int32_t t = 0; t < s_track_count; t++) {
        if (0 != s_tracks[t].is_valid &&
            s_tracks[t].frames_since_update > (uint8_t)s_config.max_miss_frames) {
            s_tracks[t].is_valid = 0u;
        }
    }
}

/**
 * @brief 为单个目标寻找最佳匹配的检测框
 * @param[in] t: 目标索引
 * @param[in] detections: 检测结果数组
 * @param[in] match_count: 检测框数量
 * @param[in] dt: 时间差(毫秒)
 * @param[in] det_matched: 已匹配标记数组
 * @return 最佳匹配的索引，-1表示无匹配
 */
static int32_t __find_best_match_for_track(int32_t t, const TKL_VI_DETECT_TARGET_T* detections,
                                            int32_t match_count, float dt, const int32_t* det_matched)
{
    float pred_x = s_tracks[t].x + s_tracks[t].vx * dt;
    float pred_y = s_tracks[t].y + s_tracks[t].vy * dt;
    
    float avg_size = (s_tracks[t].width + s_tracks[t].height) / 2.0f;
    float speed = sqrtf(s_tracks[t].vx * s_tracks[t].vx + s_tracks[t].vy * s_tracks[t].vy) * dt;
    float dist_threshold = fmaxf(avg_size * s_config.dist_size_factor,
                                  speed * s_config.dist_speed_factor + avg_size * s_config.dist_base_factor);
    
    float best_score = -1.0f;
    int32_t best_match = -1;
    
    for (int32_t d = 0; d < match_count; d++) {
        if (0 != det_matched[d]) continue;
        
        float det_x = (float)detections[d].draw_rect.x;
        float det_y = (float)detections[d].draw_rect.y;
        float det_w = (float)detections[d].draw_rect.width;
        float det_h = (float)detections[d].draw_rect.height;
        
        float dist = __calc_center_distance(pred_x, pred_y, s_tracks[t].width, s_tracks[t].height,
                                            det_x, det_y, det_w, det_h);
        if (dist > dist_threshold) continue;
        
        float iou = __calc_iou(pred_x, pred_y, s_tracks[t].width, s_tracks[t].height,
                               det_x, det_y, det_w, det_h);
        float dist_score = 1.0f - (dist / dist_threshold);
        float score = dist_score * s_config.dist_score_weight + iou * s_config.iou_score_weight;
        
        if (score > best_score) {
            best_score = score;
            best_match = d;
        }
    }
    return best_match;
}

/**
 * @brief 使用卡尔曼或EMA更新目标状态
 * @param[in] t: 目标索引
 * @param[in] det_x: 检测框x坐标
 * @param[in] det_y: 检测框y坐标
 * @param[in] det_w: 检测框宽度
 * @param[in] det_h: 检测框高度
 * @param[in] conf: 置信度
 * @param[in] timestamp_ms: 当前时间戳
 * @param[in] dt: 时间差(毫秒)
 * @return 无
 */
static void __update_track_with_detection(int32_t t, float det_x, float det_y, float det_w, float det_h,
                                           float conf, uint64_t timestamp_ms, float dt)
{
    if (s_kf[t].initialized && dt > 0.0f) {
        float dt_sec = dt / 1000.0f;
        kf_predict(&s_kf[t], dt_sec);
        kf_update(&s_kf[t], det_x, det_y, det_w, det_h);
        kf_get_position(&s_kf[t], &s_tracks[t].x, &s_tracks[t].y, &s_tracks[t].width, &s_tracks[t].height);
        kf_get_velocity(&s_kf[t], &s_tracks[t].vx, &s_tracks[t].vy);
        // 卡尔曼输出的速度单位是 像素/秒，需要转换为 像素/毫秒
        s_tracks[t].vx /= 1000.0f;
        s_tracks[t].vy /= 1000.0f;
    } else {
        if (dt > 0.0f) {
            float new_vx = (det_x - s_tracks[t].x) / dt;
            float new_vy = (det_y - s_tracks[t].y) / dt;
            s_tracks[t].vx = s_config.velocity_smooth * s_tracks[t].vx + (1.0f - s_config.velocity_smooth) * new_vx;
            s_tracks[t].vy = s_config.velocity_smooth * s_tracks[t].vy + (1.0f - s_config.velocity_smooth) * new_vy;
        }
        s_tracks[t].x = det_x;
        s_tracks[t].y = det_y;
        s_tracks[t].width = det_w;
        s_tracks[t].height = det_h;
    }
    s_tracks[t].confidence = conf;
    s_tracks[t].last_update_time = timestamp_ms;
    s_tracks[t].frames_since_update = 0u;
}

/**
 * @brief 创建新跟踪目标
 * @param[in] slot: 目标槽位索引
 * @param[in] det: 检测结果指针
 * @param[in] timestamp_ms: 当前时间戳
 * @return 无
 */
static void __create_new_track(int32_t slot, const TKL_VI_DETECT_TARGET_T* det, uint64_t timestamp_ms)
{
    float det_x = (float)det->draw_rect.x;
    float det_y = (float)det->draw_rect.y;
    float det_w = (float)det->draw_rect.width;
    float det_h = (float)det->draw_rect.height;
    
    s_tracks[slot].id = slot;
    s_tracks[slot].class_id = (int32_t)det->type;
    s_tracks[slot].confidence = det->score;
    s_tracks[slot].x = det_x;
    s_tracks[slot].y = det_y;
    s_tracks[slot].width = det_w;
    s_tracks[slot].height = det_h;
    s_tracks[slot].vx = 0.0f;
    s_tracks[slot].vy = 0.0f;
    s_tracks[slot].last_update_time = timestamp_ms;
    s_tracks[slot].is_valid = 1u;
    s_tracks[slot].frames_since_update = 0u;
    kf_init(&s_kf[slot], NULL, det_x, det_y, det_w, det_h);
}

/* -------------------------------------------------------------------------- */
/*                              公共接口                                       */
/* -------------------------------------------------------------------------- */

/**
 * @brief 获取跟踪器默认配置
 * @return 默认配置结构体
 */
DET_TRACKER_CONFIG_T det_tracker_get_default_config(void)
{
    DET_TRACKER_CONFIG_T config = {
        .max_predict_ms = DET_DEFAULT_MAX_PREDICT_MS,
        .iou_threshold = DET_DEFAULT_IOU_THRESHOLD,
        .max_miss_frames = DET_DEFAULT_MAX_MISS_FRAMES,
        .velocity_smooth = DET_DEFAULT_VELOCITY_SMOOTH,
        .speed_sq_threshold = DET_DEFAULT_SPEED_SQ_THRESHOLD,
        .overlap_iou_threshold = DET_DEFAULT_OVERLAP_IOU,
        .max_dt_ms = DET_DEFAULT_MAX_DT_MS,
        .dist_size_factor = DET_DEFAULT_DIST_SIZE_FACTOR,
        .dist_speed_factor = DET_DEFAULT_DIST_SPEED_FACTOR,
        .dist_base_factor = DET_DEFAULT_DIST_BASE_FACTOR,
        .dist_score_weight = DET_DEFAULT_DIST_SCORE_WEIGHT,
        .iou_score_weight = DET_DEFAULT_IOU_SCORE_WEIGHT
    };
    return config;
}

/**
 * @brief 初始化跟踪器
 * @param[in] config: 配置参数（传NULL使用默认配置）
 * @return OPRT_OK 成功，其余错误码表示失败
 */
OPERATE_RET det_tracker_init(const DET_TRACKER_CONFIG_T* config)
{
    memset(s_tracks, 0, sizeof(s_tracks));
    memset(s_kf, 0, sizeof(s_kf));  // 初始化卡尔曼滤波器数组
    s_track_count = 0;
    
    if (NULL != config) {
        s_config = *config;
    } else {
        s_config = det_tracker_get_default_config();
    }
    
    s_tracker_initialized = 1;
    return OPRT_OK;
}

/**
 * @brief 更新跟踪器
 * @param[in] detections: 检测结果数组
 * @param[in] count: 检测结果数量
 * @param[in] timestamp_ms: 当前时间戳(毫秒)，用于计算速度
 * @return int32_t:更新后的跟踪目标数量
 * @note 如果目标过多且密集，可以考虑引入匈牙利算法，但对性能影响也很大，建议不使用
 */
int32_t det_tracker_update(const TKL_VI_DETECT_TARGET_T* detections, int32_t count, uint64_t timestamp_ms)
{
    pthread_mutex_lock(&s_tracker_mutex);
    
    if (0 == s_tracker_initialized) { // 递归调用前需要解锁，init 内部也可能加锁
        PR_ERR("Tracker not initialized, initializing now.");
        pthread_mutex_unlock(&s_tracker_mutex);
        det_tracker_init(NULL);
        pthread_mutex_lock(&s_tracker_mutex);
    }
    __age_all_tracks();
    
    // 无检测结果时只标记超时
    if (NULL == detections || count <= 0) {
        PR_ERR("No detections, marking timeout tracks.");
        __mark_timeout_tracks();
        int32_t cnt = __det_tracker_get_count_internal();
        pthread_mutex_unlock(&s_tracker_mutex);
        return cnt;
    }
    
    int32_t det_matched[DET_MAX_TRACK_TARGETS] = {0}; 
    int32_t match_count = (count > (int32_t)DET_MAX_TRACK_TARGETS) ? (int32_t)DET_MAX_TRACK_TARGETS : count;
    // 匹配并更新已有目标
    for (int32_t t = 0; t < s_track_count; t++) {
        if (0 == s_tracks[t].is_valid) {
            continue;
        }
        
        float dt = (float)(timestamp_ms - s_tracks[t].last_update_time);
        int32_t best_match = __find_best_match_for_track(t, detections, match_count, dt, det_matched);
        
        if (best_match >= 0) {
            det_matched[best_match] = 1;
            __update_track_with_detection(t,
                (float)detections[best_match].draw_rect.x,
                (float)detections[best_match].draw_rect.y,
                (float)detections[best_match].draw_rect.width,
                (float)detections[best_match].draw_rect.height,
                detections[best_match].score, timestamp_ms, dt);
        } else {
            if (s_tracks[t].frames_since_update > (uint8_t)s_config.max_miss_frames) {
                s_tracks[t].is_valid = 0u;
            }
        }
    }
    // 为未匹配的检测框创建新目标
    for (int32_t d = 0; d < match_count; d++) {
        if (0 != det_matched[d]) continue;
        
        float det_x = (float)detections[d].draw_rect.x;
        float det_y = (float)detections[d].draw_rect.y;
        float det_w = (float)detections[d].draw_rect.width;
        float det_h = (float)detections[d].draw_rect.height;
        
        // 检查是否与现有目标重叠
        int32_t overlap_found = 0;
        for (int32_t t = 0; t < s_track_count && 0 == overlap_found; t++) {
            if (0 != s_tracks[t].is_valid) {
                float iou = __calc_iou(s_tracks[t].x, s_tracks[t].y, s_tracks[t].width, s_tracks[t].height,
                                       det_x, det_y, det_w, det_h);
                if (iou > s_config.overlap_iou_threshold) overlap_found = 1;
            }
        }
        if (0 != overlap_found) {
            PR_ERR("Track %d overlaps with existing track, skipping.", d);
            continue;
        }
        
        // 寻找空槽位
        int32_t slot = -1;
        for (int32_t t = 0; t < (int32_t)DET_MAX_TRACK_TARGETS && slot < 0; t++) {
            if (0 == s_tracks[t].is_valid) slot = t;
        }
        if (slot < 0 && s_track_count < (int32_t)DET_MAX_TRACK_TARGETS) {
            slot = s_track_count++;
        }
        
        if (slot >= 0) {
            __create_new_track(slot, &detections[d], timestamp_ms);
        }
    }
    
    int32_t cnt = __det_tracker_get_count_internal();
    pthread_mutex_unlock(&s_tracker_mutex);
    return cnt;
}

/**
 * @brief 获取预测位置
 * @param[out] results: 输出预测后的目标位置
 * @param[in] max_count: 最大输出数量
 * @param[in] timestamp_ms: 目标时间戳
 * @return 输出的目标数量
 */
int32_t det_tracker_predict(DET_TRACK_TARGET_T* results, int32_t max_count, uint64_t timestamp_ms)
{
    if (NULL == results || max_count <= 0) {
        return 0;
    }
    
    pthread_mutex_lock(&s_tracker_mutex);
    
    if (0 == s_tracker_initialized) {
        pthread_mutex_unlock(&s_tracker_mutex);
        return 0;
    }
    
    // 动态过载保护：如果目标过多，跳过预测以节省CPU，直接返回0触发回退逻辑
    if (s_track_count > DET_PREDICT_MAX_TARGETS) {
        pthread_mutex_unlock(&s_tracker_mutex);
        return 0;
    }
    
    int32_t output_count = 0;
    
    for (int32_t t = 0; t < s_track_count && output_count < max_count; t++) {
        // 跳过无效/超时/速度过快的目标
        if (0 == s_tracks[t].is_valid ||
            timestamp_ms < s_tracks[t].last_update_time) {
            continue;
        }
        
        float dt = (float)(timestamp_ms - s_tracks[t].last_update_time);
        float speed_sq = s_tracks[t].vx * s_tracks[t].vx + s_tracks[t].vy * s_tracks[t].vy;
        
        if (dt > s_config.max_dt_ms || 
            dt > (float)s_config.max_predict_ms ||
            speed_sq >= s_config.speed_sq_threshold) {
            continue;
        }
        
        // 复制基础信息
        results[output_count] = s_tracks[t];
        
        // 预测位置
        float pred_x, pred_y, pred_w, pred_h;
        
        // 额外补偿延迟：检测+传输 约 30-50ms，让预测稍微"超前"
        float predict_dt = dt + 30.0f;  // 可调：增大减少滞后，但可能过冲
        
        if (s_kf[t].initialized) {
            KF_STATE_T kf_temp = s_kf[t];
            kf_predict(&kf_temp, predict_dt / 1000.0f);
            kf_get_position(&kf_temp, &pred_x, &pred_y, &pred_w, &pred_h);
        } else {
            pred_x = s_tracks[t].x + s_tracks[t].vx * predict_dt;
            pred_y = s_tracks[t].y + s_tracks[t].vy * predict_dt;
            pred_w = s_tracks[t].width;
            pred_h = s_tracks[t].height;
        }
        
        // 边界保护
        results[output_count].x = (pred_x < 0.0f) ? 0.0f : pred_x;
        results[output_count].y = (pred_y < 0.0f) ? 0.0f : pred_y;
        results[output_count].width = pred_w;
        results[output_count].height = pred_h;
        
        output_count++;
    }
    
    pthread_mutex_unlock(&s_tracker_mutex);
    return output_count;
}

/**
 * @brief 获取用于显示的目标列表（优先预测，失败则读缓存）
 * @param[out] results: 输出目标位置
 * @param[in] max_count: 最大输出数量
 * @param[in] timestamp_ms: 当前时间戳
 * @return 输出的目标数量
 */
int32_t det_tracker_get_display_targets(DET_TRACK_TARGET_T* results, int32_t max_count, uint64_t timestamp_ms)
{
    if (NULL == results || max_count <= 0) {
        return 0;
    }

    // 优先获取预测结果（predict内部会根据负载动态决定是否启用）
    int32_t count = det_tracker_predict(results, max_count, timestamp_ms);

    // 无预测结果时或被跳过，回退到 Tracker 最后一次的有效状态
    if (0 == count) {
        PR_ERR("Predict failed or skipped, falling back to last known states.");
        pthread_mutex_lock(&s_tracker_mutex);
        for (int32_t t = 0; t < s_track_count && count < max_count; t++) {
            if (0 != s_tracks[t].is_valid) {
                results[count++] = s_tracks[t];
            }
        }
        pthread_mutex_unlock(&s_tracker_mutex);
    }
    
    return count;
}

/**
 * @brief 获取当前跟踪目标数量
 * @return int32_t:跟踪目标数量
 */
int32_t det_tracker_get_count(void)
{
    pthread_mutex_lock(&s_tracker_mutex);
    if (0 == s_tracker_initialized) {
        pthread_mutex_unlock(&s_tracker_mutex);
        return 0;
    }
    int32_t count = __det_tracker_get_count_internal();
    pthread_mutex_unlock(&s_tracker_mutex);
    return count;
}

/**
 * @brief 释放跟踪器资源
 * @return 
 */
void det_tracker_deinit(void)
{
    pthread_mutex_lock(&s_tracker_mutex);
    memset(s_tracks, 0, sizeof(s_tracks));
    memset(s_kf, 0, sizeof(s_kf));  // 清理卡尔曼滤波器状态
    s_track_count = 0;
    s_tracker_initialized = 0;
    pthread_mutex_unlock(&s_tracker_mutex);
}
