/**
 * @file yolo_detector.cpp
 * @brief YOLO检测器主类实现
 * @author lzq
 * @version 1.0
 * @date 2025-12-29 11:26:00
 * 
 * Copyright (c) tuya.inc 2023-2033.
 * 
 */

#include "yolo_detector.h"
#include <fstream>
#include <sstream>
#include <sys/time.h>

extern "C" {
#include "tuya_cloud_types.h"
#include "uni_log.h"
}

namespace detector {

/**
 * @brief 获取当前时间（毫秒）
 * @return 当前时间戳（毫秒）
 */
static double get_time_ms() {
    struct timeval tv;
    gettimeofday(&tv, nullptr);
    return tv.tv_sec * 1000.0 + tv.tv_usec / 1000.0;
}

YoloDetector::YoloDetector(const DetectorConfig& config)
    : config_(config)
    , initialized_(false)
{
    preprocessor_ = std::make_unique<LetterBoxPreprocessor>(
        cv::Size(config.yolo.model_width, config.yolo.model_height));
    
    inference_engine_ = std::make_unique<TklNpuEngine>();
    #ifdef DET_USING_YOLOV8
        postprocessor_ = std::make_unique<Yolov8Postprocessor>();
    #endif
    #ifdef DET_USING_YOLOV5
        postprocessor_ = std::make_unique<Yolov5Postprocessor>();
    #endif
}

YoloDetector::~YoloDetector() {
    if (inference_engine_) {
        inference_engine_->release();
    }
}

/**
 * @brief 初始化检测器
 * @param[in] model_path: 模型文件路径
 * @param[in] label_file: 标签文件路径（可选）
 * @return OPRT_OK 成功，其余错误码表示失败
 */
OPERATE_RET YoloDetector::initialize(const char* model_path, const char* label_file) {
    if (initialized_) {
        return OPRT_OK;
    }
    
    const char* label_path = label_file ? label_file : config_.yolo.label_file.c_str();
    if (load_labels(label_path) < 0) {
        PR_ERR("Load labels failed: %s", label_path);
        return OPRT_NOT_SUPPORTED;
    }

    int ret = inference_engine_->initialize(model_path);
    if (ret < 0) {
        PR_ERR("Inference engine init failed: %s", model_path);
        return OPRT_COM_ERROR;
    }
    
    initialized_ = true;
    return OPRT_OK;
}

/**
 * @brief 检测图像中的目标
 * @param[in] image: 输入图像
 * @return 检测结果列表
 */
DetectionList YoloDetector::detect(const cv::Mat& image) {
    if (!initialized_) {
        return DetectionList();
    }
    
    double t_start = get_time_ms();
    
    // 预处理
    double t_preprocess_start = get_time_ms();
    PreprocessResult preprocess_result = preprocessor_->process(image);
    last_preprocess_params_ = preprocess_result.params;
    double t_preprocess_end = get_time_ms();
    
    // 推理
    double t_inference_start = get_time_ms();
    InferenceOutput inference_output = inference_engine_->run(preprocess_result.processed_image);
    double t_inference_end = get_time_ms();
    
    // 后处理
    double t_postprocess_start = get_time_ms();
    DetectionList detections = postprocessor_->process(inference_output, config_.yolo);
    double t_postprocess_end = get_time_ms();
    
    // 坐标还原到原图
    for (auto& det : detections) {
        det.box = preprocessor_->restore_coordinates(det.box, last_preprocess_params_);
        det.class_name = get_class_name(det.class_id);
    }
    
    double t_end = get_time_ms();
    
    // 更新性能统计
    if (config_.performance.enable_timing) {
        perf_stats_.preprocess_time = (t_preprocess_end - t_preprocess_start) / 1000.0;
        perf_stats_.inference_time = (t_inference_end - t_inference_start) / 1000.0;
        perf_stats_.postprocess_time = (t_postprocess_end - t_postprocess_start) / 1000.0;
        perf_stats_.total_time = (t_end - t_start) / 1000.0;
    }
    
    return detections;
}

/**
 * @brief 加载标签文件
 * @param[in] label_file: 标签文件路径
 * @return 加载的标签数量，负数表示失败
 */
int YoloDetector::load_labels(const char* label_file) {
    std::ifstream file(label_file);
    if (!file.is_open()) {
        return -1;
    }
    
    labels_.clear();
    std::string line;
    while (std::getline(file, line)) {
        labels_.push_back(line);
    }
    
    file.close();
    return static_cast<int>(labels_.size());
}

/**
 * @brief 获取类别名称
 * @param[in] class_id: 类别ID
 * @return 类别名称
 */
std::string YoloDetector::get_class_name(int class_id) const {
    if (class_id < 0 || class_id >= static_cast<int>(labels_.size())) {
        return "unknown";
    }
    return labels_[class_id];
}

} // namespace detector
