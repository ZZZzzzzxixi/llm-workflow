/**
 * @file object_detector_api.cpp
 * @brief C API实现
 * @author Refactored by AI Assistant
 * @version 2.0
 * @date 2025-12-25
 */

#include "object_detector_api.h"
#include "yolo_detector.h"
#include "detector_utils.h"
#include "uni_log.h"
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <memory>
#include <cstring>
#include <unistd.h>

extern "C" {
#include "tkl_video_enc.h"
#include "robotics_svc_media.h"
}

using namespace detector;

// 配置常量
#define DEFAULT_LABEL_FILE      "/tuya/data/coco_80_labels_list.txt"
#define DEBUG_IMAGE_DIR         "/tuya/data/tuya_image"
#define FRAME_BUFFER_SIZE       (8 * 1024 * 1024)  // 8MB
#define MAX_DETECTION_RESULTS   100

// 全局检测器实例
static std::unique_ptr<YoloDetector> g_detector;
static bool g_initialized = false;
static UCHAR_T* g_frame_buffer = nullptr;

/**
 * @brief 配置转换函数
 * @param[in] c_config: C语言配置结构体 
 * @return DetectorConfig: 检测器配置
 */
static DetectorConfig convert_config(const OBJECT_DETECTOR_CONFIG_T* c_config) 
{
    DetectorConfig config;
    
    if (c_config) {
        config.yolo.model_width = c_config->model_width;
        config.yolo.model_height = c_config->model_height;
        config.yolo.conf_threshold = c_config->conf_threshold;
        config.yolo.nms_threshold = c_config->nms_threshold;
        config.yolo.max_detections = c_config->max_detections;
        config.performance.enable_timing = (c_config->enable_timing != 0);
        config.performance.save_debug_images = (c_config->save_debug_images != 0);
        config.performance.debug_image_interval = c_config->debug_image_interval;
    }
    
    return config;
}

// 结果转换函数
static void convert_detections(
    const DetectionList& cpp_dets,
    OBJECT_DETECTION_LIST_T* c_results)
{
    c_results->count = std::min(static_cast<int>(cpp_dets.size()), MAX_DETECTION_RESULTS);
    
    for (int i = 0; i < c_results->count; ++i) {
        const auto& det = cpp_dets[i];
        c_results->results[i].left = det.box.left;
        c_results->results[i].top = det.box.top;
        c_results->results[i].right = det.box.right;
        c_results->results[i].bottom = det.box.bottom;
        c_results->results[i].class_id = det.class_id;
        c_results->results[i].confidence = det.confidence;
    }
}

// ========== C API实现 ==========

OBJECT_DETECTOR_CONFIG_T object_detector_get_default_config(void) {
    OBJECT_DETECTOR_CONFIG_T config;
    
    config.model_width = 640;
    config.model_height = 640;
    config.conf_threshold = 0.5f;   
    config.nms_threshold = 0.6f;    
    config.max_detections = 100;
    config.enable_timing = 1;
    config.save_debug_images = 0;  // 默认关闭以提升性能
    config.debug_image_interval = 10;
    
    return config;
}

OPERATE_RET object_detector_init(
    const char* model_path,
    const char* label_path,
    const OBJECT_DETECTOR_CONFIG_T* config)
{
    if (g_initialized) {
        PR_WARN("Detector already initialized");
        return OPRT_OK;
    }
    
    PR_INFO("Initializing object detector (refactored version)");
    
    // 创建调试图像目录
    system("mkdir -p " DEBUG_IMAGE_DIR);
    if (access(DEBUG_IMAGE_DIR, F_OK) != 0) {
        PR_ERR("Failed to create debug image directory: " DEBUG_IMAGE_DIR);
        return OPRT_COM_ERROR;
    }
    
    // 分配帧缓冲区
    g_frame_buffer = (UCHAR_T*)malloc(FRAME_BUFFER_SIZE);
    if (!g_frame_buffer) {
        PR_ERR("Failed to allocate frame buffer");
        return OPRT_MALLOC_FAILED;
    }
    
    // 转换配置
    DetectorConfig cpp_config = convert_config(config);
    
    // 设置标签文件路径
    if (label_path) {
        cpp_config.yolo.label_file = label_path;
    } else {
        cpp_config.yolo.label_file = DEFAULT_LABEL_FILE;
    }
    
    // 创建检测器
    g_detector = std::make_unique<YoloDetector>(cpp_config);
    
    // 初始化
    int ret = g_detector->initialize(model_path);
    if (ret < 0) {
        PR_ERR("Failed to initialize detector, error code: %d", ret);
        g_detector.reset();
        free(g_frame_buffer);
        g_frame_buffer = nullptr;
        return OPRT_COM_ERROR;
    }
    
    g_initialized = true;
    PR_INFO("Object detector initialized successfully");
    
    return OPRT_OK;
}

int object_detector_detect(
    const unsigned char* image_data,
    int width,
    int height,
    OBJECT_DETECTION_LIST_T* results)
{
    if (!g_initialized || !g_detector) {
        PR_ERR("Detector not initialized");
        return -1;
    }
    
    if (!image_data || !results) {
        PR_ERR("Invalid parameters");
        return -2;
    }
    cv::Mat bgra_image(height, width, CV_8UC4, const_cast<unsigned char*>(image_data));
    
    // 转换为BGR
    cv::Mat bgr_image;
    cv::cvtColor(bgra_image, bgr_image, cv::COLOR_BGRA2BGR);
    
    DetectionList detections = g_detector->detect(bgr_image);
    
    // 转换结果
    convert_detections(detections, results);
    
    static uint8_t turnoff = 0;
    if(g_detector->get_config().performance.save_debug_images) {
        turnoff = 1;
    }

    if (turnoff) {
        static int s_debug_index = 0;
         // 确保目录存在
        if (access(DEBUG_IMAGE_DIR, F_OK) != 0) {
            system("mkdir -p " DEBUG_IMAGE_DIR);
        }
        
        // 保存预处理前的原始图片
        char jpg_path_ori[256];
        sprintf(jpg_path_ori, "%s/input_ori_%d.jpg", DEBUG_IMAGE_DIR, s_debug_index);
        cv::imwrite(jpg_path_ori, bgr_image);
        
        // 在图片上画框
        cv::Mat draw_img = bgr_image.clone();
        char text[256];
        
        for (int i = 0; i < results->count; i++) {
            OBJECT_DETECTION_RESULT_T* det = &(results->results[i]);
            
            // 限制坐标范围
            int x1 = std::max(0, std::min(det->left, draw_img.cols - 1));
            int y1 = std::max(0, std::min(det->top, draw_img.rows - 1));
            int x2 = std::max(0, std::min(det->right, draw_img.cols - 1));
            int y2 = std::max(0, std::min(det->bottom, draw_img.rows - 1));
            
            const char* cls_name = object_detector_get_class_name(det->class_id);
            
            PR_INFO("Result %d: %s @ (%d %d %d %d) %.3f\n", 
                   i, cls_name, x1, y1, x2, y2, det->confidence);
            
            cv::rectangle(draw_img, cv::Point(x1, y1), cv::Point(x2, y2), cv::Scalar(0, 255, 0), 3);
            
            sprintf(text, "%s %.1f%%", cls_name, det->confidence * 100);
            cv::putText(draw_img, text, cv::Point(x1, y1 - 8),
                       cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(0, 255, 0), 2);
        }
        
        // 保存画框后的图片
        char jpg_path_out[256];
        sprintf(jpg_path_out, "%s/output_refactored_%d.jpg", DEBUG_IMAGE_DIR, s_debug_index);
        cv::imwrite(jpg_path_out, draw_img);
        
        PR_INFO("Saved debug images to %s (index %d)\n", DEBUG_IMAGE_DIR, s_debug_index);
        
        s_debug_index++;
        if (s_debug_index > 5) {
            turnoff = 0;
            s_debug_index = 0;
            PR_INFO("Disabling debug image saving to improve performance\n");
        }
    }
    
    return 0;
}

int object_detector_detect_from_stream(
    OBJECT_DETECTION_LIST_T* results)
{
    if (!g_initialized || !g_detector) {
        PR_ERR("Detector not initialized");
        return -1;
    }
    
    if (!g_frame_buffer) {
        PR_ERR("Frame buffer not allocated");
        return -2;
    }
    
    if (!results) {
        PR_ERR("Invalid results pointer");
        return -3;
    }
    
    // 从视频流获取图像
    TKL_VENC_FRAME_T frame;
    frame.pbuf = (char*)g_frame_buffer;
    frame.buf_size = FRAME_BUFFER_SIZE;
    
    memset(g_frame_buffer, 0, FRAME_BUFFER_SIZE);
    robotics_svc_media_pic_get(&frame);
    
    // 调用检测函数
    return object_detector_detect(
        (const unsigned char*)frame.pbuf,
        frame.width,
        frame.height,
        results
    );
}

int object_detector_get_performance(
    OBJECT_DETECTOR_PERF_T* perf)
{
    if (!g_initialized || !g_detector) {
        return -1;
    }
    
    if (!perf) {
        return -2;
    }
    
    const auto& stats = g_detector->get_performance_stats();
    
    perf->preprocess_time = stats.preprocess_time;
    perf->inference_time = stats.inference_time;
    perf->postprocess_time = stats.postprocess_time;
    perf->total_time = stats.total_time;
    perf->fps = stats.get_fps();
    
    return 0;
}

const char* object_detector_get_class_name(int class_id) {
    if (!g_initialized || !g_detector) {
        return "unknown";
    }
    
    thread_local std::string class_name;
    class_name = g_detector->get_class_name(class_id);
    return class_name.c_str();
}

int object_detector_update_config(
    const OBJECT_DETECTOR_CONFIG_T* config)
{
    if (!g_initialized || !g_detector) {
        return -1;
    }
    
    if (!config) {
        return -2;
    }
    
    DetectorConfig cpp_config = convert_config(config);
    g_detector->update_config(cpp_config);
    
    return 0;
}

int object_detector_deinit(void) {
    if (!g_initialized) {
        return 0;
    }
    
    PR_INFO("Deinitializing object detector");
    
    g_detector.reset();
    
    if (g_frame_buffer) {
        free(g_frame_buffer);
        g_frame_buffer = nullptr;
    }
    
    g_initialized = false;
    
    PR_INFO("Object detector deinitialized");
    
    return 0;
}
