/**
 * @file object_detector_api.cpp
 * @brief 目标检测器API实现
 * @author lzq
 * @version 1.0
 * @date 2026-01-13 10:33:31
 * 
 * Copyright (c) tuya.inc 2023-2033.
 * 
 */

#include "object_detector_internal.h"
#include "yolo_detector.h"
#include "detector_utils.h"
#include "uni_log.h"
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <memory>
#include <cstring>
#include <unistd.h>
#include <sys/stat.h>

extern "C" {
#include "tkl_video_enc.h"

#include "tkl_media.h"
}

using namespace detector;

/* -------------------------------------------------------------------------- */
/*                              私有宏定义                                     */
/* -------------------------------------------------------------------------- */

#define DEFAULT_LABEL_FILE      "/tuya/data/coco_80_labels_list.txt" // 需要看情况修改
#define DEBUG_IMAGE_DIR         "/tuya/data/tuya_image"              // 调试图像保存目录
#ifdef DET_RUNNING_PLATFORM_2386
#define FRAME_BUFFER_SIZE       (4u * 672u * 896u)// (3u * 1024u * 1024u)  /* 1280*720*3 约 2.7MB，预留余量 */
#else
#define FRAME_BUFFER_SIZE       (3u * 1024u * 1024u)  /* 1280*720*3 约 2.7MB，预留余量 */
#endif

/* -------------------------------------------------------------------------- */
/*                              私有变量                                       */
/* -------------------------------------------------------------------------- */

static std::unique_ptr<YoloDetector> s_detector;
static bool_t s_detector_initialized = false;
static uint8_t* s_frame_buffer = nullptr;
static DET_GET_FRAME_CB s_get_frame_cb = nullptr;

/* -------------------------------------------------------------------------- */
/*                              私有函数                                       */
/* -------------------------------------------------------------------------- */

/**
 * @brief 配置转换函数
 * @param[in] c_config: C语言配置结构体
 * @return DetectorConfig: 检测器配置
 */
static DetectorConfig __convert_config(const DET_CONFIG_T* c_config)
{
    DetectorConfig config;
    
    if (nullptr != c_config) {
        config.yolo.model_width = static_cast<int>(c_config->model_width);
        config.yolo.model_height = static_cast<int>(c_config->model_height);
        config.yolo.conf_threshold = c_config->conf_threshold;
        config.yolo.nms_threshold = c_config->nms_threshold;
        config.yolo.max_detections = static_cast<int>(c_config->max_detections);
        config.performance.enable_timing = (0u != c_config->enable_timing);
        config.performance.save_debug_images = (0u != c_config->save_debug_images);
        config.performance.debug_image_interval = static_cast<int>(c_config->debug_image_interval);
    }
    
    return config;
}

/**
 * @brief 结果转换函数
 */
static void __convert_detections(const DetectionList& cpp_dets, DET_DETECTION_LIST_T* c_results)
{
    c_results->count = std::min(static_cast<int32_t>(cpp_dets.size()), static_cast<int32_t>(DET_MAX_RESULTS));
    
    for (int32_t i = 0; i < c_results->count; ++i) {
        const auto& det = cpp_dets[static_cast<size_t>(i)];
        c_results->results[i].left = det.box.left;
        c_results->results[i].top = det.box.top;
        c_results->results[i].right = det.box.right;
        c_results->results[i].bottom = det.box.bottom;
        c_results->results[i].class_id = det.class_id;
        c_results->results[i].confidence = det.confidence;
    }
}

/* -------------------------------------------------------------------------- */
/*                              公共接口                                       */
/* -------------------------------------------------------------------------- */

extern "C" {

DET_CONFIG_T det_detector_get_default_config(void)
{
    DET_CONFIG_T config;
    
    config.model_width = DET_DEFAULT_MODEL_WIDTH;
    config.model_height = DET_DEFAULT_MODEL_HEIGHT;
    config.conf_threshold = DET_DEFAULT_CONF_THRESHOLD;
    config.nms_threshold = DET_DEFAULT_NMS_THRESHOLD;
    config.max_detections = DET_DEFAULT_MAX_DETECTIONS;
    config.enable_timing = DET_DEFAULT_ENABLE_TIMING;
    config.save_debug_images = DET_DEFAULT_SAVE_DEBUG_IMAGES;
    config.debug_image_interval = DET_DEFAULT_DEBUG_INTERVAL;
    
    return config;
}

OPERATE_RET det_detector_init(const char* model_path,
    const char* label_path, const DET_CONFIG_T* config)
{
    if (s_detector_initialized) {
        PR_WARN("Detector already initialized");
        return OPRT_OK;
    }
    
    PR_INFO("Initializing object detector");
    
    // 仅在需要保存调试图像时才创建目录
    if (nullptr != config && 0 != config->save_debug_images) {
        system("mkdir -p " DEBUG_IMAGE_DIR);
        if (0 != access(DEBUG_IMAGE_DIR, F_OK)) {
            PR_WARN("Failed to create debug image directory: " DEBUG_IMAGE_DIR);
        }
    }
    
    s_frame_buffer = static_cast<uint8_t*>(malloc(FRAME_BUFFER_SIZE));
    if (nullptr == s_frame_buffer) {
        PR_ERR("Failed to allocate frame buffer");
        return OPRT_MALLOC_FAILED;
    }
    
    DetectorConfig cpp_config = __convert_config(config);
    cpp_config.yolo.label_file = (nullptr != label_path) ? label_path : DEFAULT_LABEL_FILE;
    s_detector = std::make_unique<YoloDetector>(cpp_config);
    s_get_frame_cb = config->get_frame_cb;
    
    if (OPRT_OK != s_detector->initialize(model_path)) {
        PR_ERR("Failed to initialize detector");
        s_detector.reset();
        free(s_frame_buffer);
        s_frame_buffer = nullptr;
        return OPRT_COM_ERROR;
    }
    
    s_detector_initialized = true;
    PR_INFO("Object detector initialized successfully");
    
    return OPRT_OK;
}

OPERATE_RET det_detector_detect(const uint8_t* image_data,
    uint32_t width, uint32_t height, DET_DETECTION_LIST_T* results)
{
    if (!s_detector_initialized || nullptr == s_detector) {
        PR_ERR("Detector not initialized");
        return OPRT_COM_ERROR;
    }
    
    if (nullptr == image_data || nullptr == results) {
        PR_ERR("Invalid parameters");
        return OPRT_INVALID_PARM;
    }

    #ifndef DET_RUNNING_PLATFORM_2386
    // 适配非2386平台RGB格式图像
    cv::Mat rgb_image(static_cast<int>(height), static_cast<int>(width), CV_8UC3, 
                      const_cast<uint8_t*>(image_data));
    
    cv::Mat bgr_image;
    cv::cvtColor(rgb_image, bgr_image, cv::COLOR_RGB2BGR);
    #else
    // 适配2386平台BGRA格式图像
    cv::Mat bgra_image(static_cast<int>(height), static_cast<int>(width), CV_8UC4, const_cast<uint8_t*>(image_data));
    // 转换为BGR
    cv::Mat bgr_image;
    cv::cvtColor(bgra_image, bgr_image, cv::COLOR_BGRA2BGR);
    #endif
    
    DetectionList detections = s_detector->detect(bgr_image);
    __convert_detections(detections, results);
    
    if (s_detector->get_config().performance.save_debug_images) {
        static int32_t s_debug_index = 0;
        
        if (0 != access(DEBUG_IMAGE_DIR, F_OK)) {
            system("mkdir -p " DEBUG_IMAGE_DIR);
        }
        
        char jpg_path_ori[256];
        snprintf(jpg_path_ori, sizeof(jpg_path_ori), "%s/input_ori_%d.jpg", 
                 DEBUG_IMAGE_DIR, s_debug_index);
        cv::imwrite(jpg_path_ori, bgr_image);
        
        cv::Mat draw_img = bgr_image.clone();
        char text[256];
        
        for (int32_t i = 0; i < results->count; i++) {
            DET_DETECTION_RESULT_T* det = &(results->results[i]);
            
            int x1 = std::max(0, std::min(det->left, draw_img.cols - 1));
            int y1 = std::max(0, std::min(det->top, draw_img.rows - 1));
            int x2 = std::max(0, std::min(det->right, draw_img.cols - 1));
            int y2 = std::max(0, std::min(det->bottom, draw_img.rows - 1));
            
            const char* cls_name = det_detector_get_class_name(det->class_id);
            
            cv::rectangle(draw_img, cv::Point(x1, y1), cv::Point(x2, y2), 
                         cv::Scalar(0, 255, 0), 3);
            
            snprintf(text, sizeof(text), "%s %.1f%%", cls_name, det->confidence * 100.0f);
            cv::putText(draw_img, text, cv::Point(x1, y1 - 8),
                       cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(0, 255, 0), 2);
        }
        
        char jpg_path_out[256];
        snprintf(jpg_path_out, sizeof(jpg_path_out), "%s/output_%d.jpg", 
                 DEBUG_IMAGE_DIR, s_debug_index);
        cv::imwrite(jpg_path_out, draw_img);
        
        s_debug_index++;
    }
    
    return OPRT_OK;
}

OPERATE_RET det_detector_detect_from_stream(DET_DETECTION_LIST_T* results)
{
    if (!s_detector_initialized || nullptr == s_detector || nullptr == s_frame_buffer) {
        PR_ERR("Detector not initialized");
        return OPRT_COM_ERROR;
    }
    
    if (nullptr == results) {
        PR_ERR("Invalid results pointer");
        return OPRT_INVALID_PARM;
    }
    
    if (nullptr == s_get_frame_cb) {
        PR_ERR("Get frame callback not set");
        return OPRT_COM_ERROR;
    }

    TKL_VENC_FRAME_T frame;
    frame.pbuf = reinterpret_cast<char*>(s_frame_buffer);
    frame.buf_size = static_cast<int>(FRAME_BUFFER_SIZE);
    
    OPERATE_RET rt = OPRT_OK;
    memset(s_frame_buffer, 0, FRAME_BUFFER_SIZE);
    TUYA_CALL_ERR_RETURN(s_get_frame_cb(&frame));
    TUYA_CALL_ERR_RETURN(det_detector_detect(s_frame_buffer, static_cast<uint32_t>(frame.width),
        static_cast<uint32_t>(frame.height), results));
    return OPRT_OK;
}

OPERATE_RET det_detector_get_performance(DET_PERF_T* perf)
{
    if (!s_detector_initialized || nullptr == s_detector) {
        return OPRT_COM_ERROR;
    }
    
    if (nullptr == perf) {
        return OPRT_INVALID_PARM;
    }
    
    const auto& stats = s_detector->get_performance_stats();
    
    perf->preprocess_time = static_cast<float>(stats.preprocess_time);
    perf->inference_time = static_cast<float>(stats.inference_time);
    perf->postprocess_time = static_cast<float>(stats.postprocess_time);
    perf->total_time = static_cast<float>(stats.total_time);
    perf->fps = static_cast<float>(stats.get_fps());
    
    return OPRT_OK;
}

const char* det_detector_get_class_name(int32_t class_id)
{
    if (!s_detector_initialized || nullptr == s_detector) {
        return "unknown";
    }
    
    thread_local std::string class_name;
    class_name = s_detector->get_class_name(class_id);
    return class_name.c_str();
}

OPERATE_RET det_detector_update_config(const DET_CONFIG_T* config)
{
    if (!s_detector_initialized || nullptr == s_detector) {
        return OPRT_COM_ERROR;
    }
    
    if (nullptr == config) {
        return OPRT_INVALID_PARM;
    }
    
    DetectorConfig cpp_config = __convert_config(config);
    s_detector->update_config(cpp_config);
    
    return OPRT_OK;
}

OPERATE_RET det_detector_deinit(void)
{
    if (!s_detector_initialized) {
        return OPRT_OK;
    }
    
    PR_INFO("Deinitializing object detector");
    
    s_detector.reset();
    
    if (nullptr != s_frame_buffer) {
        free(s_frame_buffer);
        s_frame_buffer = nullptr;
    }
    
    s_detector_initialized = false;
    s_get_frame_cb = nullptr;
    
    PR_INFO("Object detector deinit success");
    return OPRT_OK;
}

} /* extern "C" */
