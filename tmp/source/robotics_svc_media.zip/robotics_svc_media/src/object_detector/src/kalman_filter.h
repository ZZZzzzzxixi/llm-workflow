/**
 * @file kalman_filter.h
 * @brief 简化卡尔曼滤波器
 * @author lzq
 * @version 1.0
 * @date 2026-01-12 17:08:06
 * @note    6维状态向量: [x, y, w, h, vx, vy]
 *          4维观测向量: [x, y, w, h]
 *          使用对角矩阵简化，避免矩阵求逆运算
 * Copyright (c) tuya.inc 2023-2033.
 * 
 */

#ifndef __KALMAN_FILTER_H__
#define __KALMAN_FILTER_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "tuya_cloud_types.h"

/* -------------------------------------------------------------------------- */
/*                              常量定义                                       */
/* -------------------------------------------------------------------------- */

#define KF_STATE_DIM    6   /**< 状态向量维度: x, y, w, h, vx, vy */
#define KF_MEAS_DIM     4   /**< 观测向量维度: x, y, w, h */

/* -------------------------------------------------------------------------- */
/*                              类型定义                                       */
/* -------------------------------------------------------------------------- */

/**
 * @brief 卡尔曼滤波器配置
 */
typedef struct {
    float process_noise;    /**< 过程噪声系数 (Q) */
    float measurement_noise;/**< 观测噪声系数 (R) */
    float initial_velocity_var; /**< 初始速度方差 */
} KF_CONFIG_T;

/**
 * @brief 卡尔曼滤波器状态
 */
typedef struct {
    float x[KF_STATE_DIM];          /**< 状态向量: [x, y, w, h, vx, vy] */
    float P[KF_STATE_DIM];          /**< 对角协方差矩阵 (简化存储) */
    float Q[KF_STATE_DIM];          /**< 过程噪声对角矩阵 */
    float R[KF_MEAS_DIM];           /**< 观测噪声对角矩阵 */
    bool_t initialized;            /**< 是否已初始化 */
} KF_STATE_T;

/* -------------------------------------------------------------------------- */
/*                              接口函数                                       */
/* -------------------------------------------------------------------------- */

/**
 * @brief 获取卡尔曼滤波器默认配置
 * @return 默认配置结构体
 */
KF_CONFIG_T kf_get_default_config(void);

/**
 * @brief 初始化卡尔曼滤波器
 * @param[out] kf: 滤波器状态指针
 * @param[in] config: 配置参数
 * @param[in] initial_x: 初始x坐标
 * @param[in] initial_y: 初始y坐标
 * @param[in] initial_w: 初始宽度
 * @param[in] initial_h: 初始高度
 */
void kf_init(KF_STATE_T* kf, const KF_CONFIG_T* config, 
             float initial_x, float initial_y, float initial_w, float initial_h);

/**
 * @brief 预测步骤
 * @param[in,out] kf: 滤波器状态指针
 * @param[in] dt: 时间间隔(秒)
 */
void kf_predict(KF_STATE_T* kf, float dt);

/**
 * @brief 更新步骤
 * @param[in,out] kf: 滤波器状态指针
 * @param[in] z_x: 观测x坐标
 * @param[in] z_y: 观测y坐标
 * @param[in] z_w: 观测宽度
 * @param[in] z_h: 观测高度
 */
void kf_update(KF_STATE_T* kf, float z_x, float z_y, float z_w, float z_h);

/**
 * @brief 获取当前位置估计
 * @param[in] kf: 滤波器状态指针
 * @param[out] x: 输出x坐标
 * @param[out] y: 输出y坐标
 * @param[out] w: 输出宽度
 * @param[out] h: 输出高度
 */
void kf_get_position(const KF_STATE_T* kf, float* x, float* y, float* w, float* h);

/**
 * @brief 获取当前速度估计
 * @param[in] kf: 滤波器状态指针
 * @param[out] vx: 输出x方向速度
 * @param[out] vy: 输出y方向速度
 */
void kf_get_velocity(const KF_STATE_T* kf, float* vx, float* vy);

#ifdef __cplusplus
}
#endif

#endif /* __KALMAN_FILTER_H__ */
