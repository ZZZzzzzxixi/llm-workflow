/**
 * @file detector_types.cpp
 * @brief 目标检测器数据类型实现
 * @author lzq
 * @version 1.0
 * @date 2025-12-25 10:09:56
 * 
 * Copyright (c) tuya.inc 2023-2033.
 * 
 */

#include "detector_types.h"
#include <algorithm>

namespace detector {

float BoundingBox::iou(const BoundingBox& other) const {
    int x_left = std::max(left, other.left);
    int y_top = std::max(top, other.top);
    int x_right = std::min(right, other.right);
    int y_bottom = std::min(bottom, other.bottom);
    
    // 检查是否有交集
    if (x_right < x_left || y_bottom < y_top) {
        return 0.0f;
    }
    
    // 计算交集面积
    float intersection = static_cast<float>((x_right - x_left + 1) * (y_bottom - y_top + 1));
    
    // 计算并集面积
    float area1 = static_cast<float>(area());
    float area2 = static_cast<float>(other.area());
    float union_area = area1 + area2 - intersection;
    
    // 避免除零
    if (union_area <= 0.0f) {
        return 0.0f;
    }
    
    return intersection / union_area;
}

void BoundingBox::clip(int max_width, int max_height) {
    left = std::max(0, std::min(left, max_width - 1));
    top = std::max(0, std::min(top, max_height - 1));
    right = std::max(0, std::min(right, max_width - 1));
    bottom = std::max(0, std::min(bottom, max_height - 1));
}

} // namespace detector
