/**
 * @file object_detector_internal.h
 * @brief 目标检测器内部头文件
 * @author lzq
 * @version 1.0
 * @date 2026-01-12 14:18:07
 * 
 * Copyright (c) tuya.inc 2023-2033.
 * 
 */
#ifndef __OBJECT_DETECTOR_INTERNAL_H__
#define __OBJECT_DETECTOR_INTERNAL_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "tuya_cloud_types.h"
#include "tkl_video_in.h"
#include "object_detector_api.h"

/* -------------------------------------------------------------------------- */
/*                              Internal Macros                               */
/* -------------------------------------------------------------------------- */
#define DET_RUNNING_PLATFORM_2386   /**< 目标检测器运行平台：SSU2386,如果不是该平台，注释掉这个宏 */   

/** @brief 检测图像默认尺寸 */
#define DET_DEFAULT_IMG_WIDTH      1280u
#define DET_DEFAULT_IMG_HEIGHT     720u

/** @brief 检测模型默认路径 */
#define DET_DEFAULT_MODEL_PATH     "/tuya/data/test.img" // 需要看情况修改

// DET_MAX_TARGETS 已在 object_detector_api.h 中定义 

/** @brief 最大检测结果数 */
#define DET_MAX_RESULTS            100u

/* -------------------------------------------------------------------------- */
/*                         跟踪器默认配置                                       */
/* -------------------------------------------------------------------------- */
#define DET_DEFAULT_MAX_PREDICT_MS      180u    /**< 最大预测时间(ms) */
#define DET_PREDICT_MAX_TARGETS         5u      /**< 开启预测的最大目标数（超过此值不预测） */

/* 预测阈值不能超过系统最大跟踪数 */
#if defined(DET_MAX_TRACK_TARGETS) && (DET_PREDICT_MAX_TARGETS > DET_MAX_TRACK_TARGETS)
    #undef DET_PREDICT_MAX_TARGETS
    #define DET_PREDICT_MAX_TARGETS DET_MAX_TRACK_TARGETS
#endif

#define DET_DEFAULT_IOU_THRESHOLD       0.25f   /**< IOU匹配阈值 */
#define DET_DEFAULT_MAX_MISS_FRAMES     3u      /**< 最大丢失帧数 */
#define DET_DEFAULT_VELOCITY_SMOOTH     0.25f   /**< 速度平滑因子 */
#define DET_DEFAULT_SPEED_SQ_THRESHOLD  0.36f   /**< 速度平方阈值 */
#define DET_DEFAULT_OVERLAP_IOU         0.3f    /**< 重叠检测IOU阈值 */
#define DET_DEFAULT_MAX_DT_MS           500.0f  /**< 最大时间差(ms) */
#define DET_DEFAULT_DIST_SIZE_FACTOR    0.8f    /**< 距离阈值-尺寸因子 */
#define DET_DEFAULT_DIST_SPEED_FACTOR   1.5f    /**< 距离阈值-速度因子 */
#define DET_DEFAULT_DIST_BASE_FACTOR    0.3f    /**< 距离阈值-基础因子 */
#define DET_DEFAULT_DIST_SCORE_WEIGHT   0.6f    /**< 评分-距离权重 */
#define DET_DEFAULT_IOU_SCORE_WEIGHT    0.4f    /**< 评分-IOU权重 */

/* -------------------------------------------------------------------------- */
/*                         检测器默认配置                                       */
/* -------------------------------------------------------------------------- */
#ifdef DET_RUNNING_PLATFORM_2386
#define DET_DEFAULT_MODEL_WIDTH         640u    /**< 模型输入宽度 */
#define DET_DEFAULT_MODEL_HEIGHT        640u    /**< 模型输入高度 */
#else
#define DET_DEFAULT_MODEL_WIDTH         320u    /**< 模型输入宽度 */
#define DET_DEFAULT_MODEL_HEIGHT        320u    /**< 模型输入高度 */
#endif
#define DET_DEFAULT_CONF_THRESHOLD      0.45f    /**< 置信度阈值 */
#define DET_DEFAULT_NMS_THRESHOLD       0.6f    /**< NMS阈值 */
#define DET_DEFAULT_MAX_DETECTIONS      100u    /**< 最大检测数量 */
#define DET_DEFAULT_ENABLE_TIMING       0u      /**< 启用性能统计 */
#define DET_DEFAULT_SAVE_DEBUG_IMAGES   0u      /**< 保存调试图像 */
#define DET_DEFAULT_DEBUG_INTERVAL      10u     /**< 调试图像保存间隔 */

/* -------------------------------------------------------------------------- */
/*                              Internal Types                                */
/* -------------------------------------------------------------------------- */

/**
 * @brief 检测结果结构体
 */
typedef struct {
    int32_t  left;          /**< 边界框左上角x坐标 */
    int32_t  top;           /**< 边界框左上角y坐标 */
    int32_t  right;         /**< 边界框右下角x坐标 */
    int32_t  bottom;        /**< 边界框右下角y坐标 */
    int32_t  class_id;      /**< 类别ID */
    float    confidence;    /**< 置信度 */
} DET_DETECTION_RESULT_T;

/**
 * @brief 检测结果列表
 */
typedef struct {
    int32_t count;                                    /**< 检测到的目标数量 */
    DET_DETECTION_RESULT_T results[DET_MAX_RESULTS];  /**< 检测结果数组 */
} DET_DETECTION_LIST_T;

/**
 * @brief 性能统计结构
 */
typedef struct {
    float preprocess_time;   /**< 预处理时间(秒) */
    float inference_time;    /**< 推理时间(秒) */
    float postprocess_time;  /**< 后处理时间(秒) */
    float total_time;        /**< 总时间(秒) */
    float fps;               /**< 帧率 */
} DET_PERF_T;

/**
 * @brief 检测器配置结构
 */
typedef struct {
    uint32_t model_width;         /**< 模型输入宽度 */
    uint32_t model_height;        /**< 模型输入高度 */
    float    conf_threshold;      /**< 置信度阈值 */
    float    nms_threshold;       /**< NMS阈值 */
    uint32_t max_detections;      /**< 最大检测数量 */
    uint8_t  enable_timing;       /**< 启用性能统计 */
    uint8_t  save_debug_images;   /**< 保存调试图像 */
    uint32_t debug_image_interval;/**< 调试图像保存间隔 */
    OPERATE_RET (*get_frame_cb)(TKL_VENC_FRAME_T* frame);/**< 获取图像回调函数 */
} DET_CONFIG_T;

/**
 * @brief 跟踪器配置
 */
typedef struct {
    uint32_t max_predict_ms;        /**< 最大预测时间(毫秒) */
    float    iou_threshold;         /**< IOU匹配阈值 */
    uint32_t max_miss_frames;       /**< 最大丢失帧数 */
    float    velocity_smooth;       /**< 速度平滑因子 */
    float    speed_sq_threshold;    /**< 速度平方阈值(过滤高速目标) */
    float    overlap_iou_threshold; /**< 重叠检测IOU阈值 */
    float    max_dt_ms;             /**< 最大时间差(ms) */
    float    dist_size_factor;      /**< 距离阈值-尺寸因子 */
    float    dist_speed_factor;     /**< 距离阈值-速度因子 */
    float    dist_base_factor;      /**< 距离阈值-基础因子 */
    float    dist_score_weight;     /**< 评分-距离权重 */
    float    iou_score_weight;      /**< 评分-IOU权重 */
} DET_TRACKER_CONFIG_T;

/**
 * @brief 检测缓存结果结构
 */
typedef struct {
    TKL_VI_DETECT_TARGET_T targets[DET_MAX_TARGETS]; /**< 检测目标数组 */
    int32_t  count;                                  /**< 目标数量 */
    uint64_t timestamp;                              /**< 检测时间戳(ms) */
} DET_CACHE_RESULT_T;

/* -------------------------------------------------------------------------- */
/*                           Detector API (Internal)                          */
/* -------------------------------------------------------------------------- */

/**
 * @brief 获取检测器默认配置
 * @return 默认配置结构体
 */
DET_CONFIG_T det_detector_get_default_config(void);

/**
 * @brief 初始化检测器
 * @param[in] model_path: 模型文件路径
 * @param[in] label_path: 标签文件路径
 * @param[in] config: 配置结构体指针
 * @return OPRT_OK 成功，其余错误码表示失败
 */
OPERATE_RET det_detector_init(
    const char* model_path,
    const char* label_path,
    const DET_CONFIG_T* config
);

/**
 * @brief 对图像数据进行目标检测
 * @param[in] image_data: 图像数据指针
 * @param[in] width: 图像宽度
 * @param[in] height: 图像高度
 * @param[out] results: 检测结果列表指针
 * @return OPRT_OK 成功，其余错误码表示失败
 */
OPERATE_RET det_detector_detect(
    const uint8_t* image_data,
    uint32_t width,
    uint32_t height,
    DET_DETECTION_LIST_T* results
);

/**
 * @brief 从视频流获取图像并进行检测
 * @param[out] results: 检测结果列表指针
 * @return OPRT_OK 成功，其余错误码表示失败
 */
OPERATE_RET det_detector_detect_from_stream(DET_DETECTION_LIST_T* results);

/**
 * @brief 获取检测性能统计
 * @param[out] perf: 性能统计结构体指针
 * @return OPRT_OK 成功，其余错误码表示失败
 */
OPERATE_RET det_detector_get_performance(DET_PERF_T* perf);

/**
 * @brief 获取类别名称
 * @param[in] class_id: 类别ID
 * @return 类别名称字符串
 */
const char* det_detector_get_class_name(int32_t class_id);

/**
 * @brief 更新检测器配置
 * @param[in] config: 新配置结构体指针
 * @return OPRT_OK 成功，其余错误码表示失败
 */
OPERATE_RET det_detector_update_config(const DET_CONFIG_T* config);

/**
 * @brief 释放检测器资源
 * @return OPRT_OK 成功，其余错误码表示失败
 */
OPERATE_RET det_detector_deinit(void);

/* -------------------------------------------------------------------------- */
/*                           Tracker API (Internal)                           */
/* -------------------------------------------------------------------------- */

/**
 * @brief 获取跟踪器默认配置
 * @return 默认配置结构体
 */
DET_TRACKER_CONFIG_T det_tracker_get_default_config(void);

/**
 * @brief 初始化跟踪器
 * @param[in] config: 跟踪器配置指针
 * @return OPRT_OK 成功，其余错误码表示失败
 */
OPERATE_RET det_tracker_init(const DET_TRACKER_CONFIG_T* config);

/**
 * @brief 更新跟踪器状态
 * @param[in] detections: 当前帧检测结果
 * @param[in] count: 检测目标数量
 * @param[in] timestamp_ms: 当前帧时间戳(ms)
 * @return 当前跟踪目标数量
 */
int32_t det_tracker_update(
    const TKL_VI_DETECT_TARGET_T* detections,
    int32_t count,
    uint64_t timestamp_ms
);

/**
 * @brief 预测跟踪目标位置
 * @param[out] results: 预测结果数组
 * @param[in] max_count: 最大结果数量
 * @param[in] timestamp_ms: 预测时间戳(ms)
 * @return 实际预测目标数量
 */
int32_t det_tracker_predict(
    DET_TRACK_TARGET_T* results,
    int32_t max_count,
    uint64_t timestamp_ms
);

/**
 * @brief 获取当前跟踪目标数量
 * @return 跟踪目标数量
 */
int32_t det_tracker_get_count(void);

/**
 * @brief 释放跟踪器资源
 */
void det_tracker_deinit(void);
#ifdef __cplusplus
}
#endif

#endif /* __OBJECT_DETECTOR_INTERNAL_H__ */
