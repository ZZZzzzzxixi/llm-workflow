/**
 * @file preprocessor.h
 * @brief 图像预处理接口
 * @author lzq
 * @version 1.0
 * @date 2025-12-25
 * 
 * Copyright (c) tuya.inc 2023-2033.
 * 
 */

#ifndef __PREPROCESSOR_H__
#define __PREPROCESSOR_H__

#include "detector_types.h"
#include <opencv2/core/core.hpp>
#include <memory>

namespace detector {

/**
 * @brief 预处理结果
 */
struct PreprocessResult {
    cv::Mat processed_image;        // 处理后的图像
    PreprocessParams params;        // 变换参数（用于坐标还原）
    
    PreprocessResult() = default;
};

/**
 * @brief 预处理器接口
 */
class IPreprocessor {
public:
    virtual ~IPreprocessor() = default;

    /**
     * @brief 预处理图像
     * @param[in] input: 输入图像
     * @return PreprocessResult: 预处理结果
     */
    virtual PreprocessResult process(const cv::Mat& input) = 0;

    /**
     * @brief 还原坐标到原图
     * @param[in] box: 模型输出的边界框
     * @param[in] params:预处理参数
     * @return BoundingBox: 原图坐标的边界框
     */
    virtual BoundingBox restore_coordinates(
        const BoundingBox& box, 
        const PreprocessParams& params) const = 0;
};

/**
 * @brief LetterBox预处理器
 * @note 将图像缩放到目标尺寸，保持宽高比，用灰色填充
 */
class LetterBoxPreprocessor : public IPreprocessor {
public:
    /**
     * @brief Construct a new Letter Box Preprocessor object
     * @param[in] target_size: 目标尺寸
     * @param[in] fill_color: 填充颜色
     */
    LetterBoxPreprocessor(
        const cv::Size& target_size = cv::Size(640, 640),
        const cv::Scalar& fill_color = cv::Scalar(114, 114, 114));
    
    ~LetterBoxPreprocessor() override = default;
    
    PreprocessResult process(const cv::Mat& input) override;
    
    BoundingBox restore_coordinates(
        const BoundingBox& box, 
        const PreprocessParams& params) const override;

private:
    cv::Size target_size_;
    cv::Scalar fill_color_;
};

} // namespace detector

#endif // __PREPROCESSOR_H__
