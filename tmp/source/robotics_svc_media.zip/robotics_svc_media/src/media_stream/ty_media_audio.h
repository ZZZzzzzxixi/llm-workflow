#ifndef __MEDIA_AUDIO_H__
#define __MEDIA_AUDIO_H__


#ifdef __cplusplus
extern "C" {
#endif

#include <tuya_cloud_types.h>

/**
 * @brief  音频采集处理线程初始化
 * @param  [*]
 * @return [*]
 */
OPERATE_RET robotics_svc_media_audio_thrd_init(void);

/**
 * @brief  音频初始化
 * @param  void
 * @return OPERATE_RET: 0 成功，其余错误码表示失败
 */
OPERATE_RET robotics_svc_media_audio_init(void);

//放音测试
int Start_Audio_Output(void);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // __MEDIA_AUDIO_H__
