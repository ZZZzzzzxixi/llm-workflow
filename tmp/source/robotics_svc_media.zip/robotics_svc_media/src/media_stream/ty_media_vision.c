#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <uni_log.h>
#include <pthread.h>
#include <sched.h>

#include <tuya_error_code.h>
#include <tuya_cloud_types.h>
#include <ty_rvc_sdk_init.h>
#include <tuya_ipc_media.h>
#include <tuya_app_config.h>
#include <tuya_robot_nav_sdk.h>
#include <tuya_ring_buffer.h>

#include "tal_audio.h"
#include "tal_video_enc.h"
#include "tal_video_in.h"
#include "ty_media_base.h"
#include "ty_media_sei.h"
#include "object_detector_api.h"
#include "ty_media_vision.h"
#include "ty_media_audio.h"

OPERATE_RET tkl_ai_set_vqe(INT32_T card, TKL_AI_CHN_E chn, TKL_AUDIO_VQE_TYPE_E type, TKL_AUDIO_VQE_PARAM_T *pparam)
{
    return 0;
}

#define CAMERA_SAMPLE_TIME 100000
#define MAX_SNAPSHOT_BUFFER_SIZE (100 * 1024) // 子视频流一帧最大长度100K 最长的一帧数据,视频的封面快照
#define MAX_MEIDA_BUFFER_SIZE (300 * 1024) // 主高清视频一帧最大长度300K
#define MAX_CAPTURED_BUFFER_SIZE (896 * 672 * 4) ///> 采集图像的buffer大小
#define TY_DSP_MEDIA_AUDIO_MAX 1 //音频采集 支持1路
#define TY_DSP_MEDIA_VI_MAX 1 //视频输入 支持1路
#define TY_DSP_MEDIA_VENC_MAX 4 //视频编码，使用4路
// 目前读取的是子视频流，所以按照如下配置
#define MEDIA_VI_CHN_NUMBER 0 //视频输入通道号 可调整
#define MEDIA_VENC_CHN_NUMBER 0 //视频编码通道号 可调整。当改成1，获取的视频码流变成bgra；当改成0，获取的视频码流变成h264；
#define MEDIA_INUSE_BUFFER_SIZE MAX_MEIDA_BUFFER_SIZE //使用的buffer大小。bgra格式下大小为896*672*4；h264格式下大小为300*1024；

///> 控制句柄全局变量
SVC_CAMERA_CTRL_S g_pro_hdl = { 0 };

RING_BUFFER_USER_HANDLE_T s_ring_buffer_handles[E_IPC_STREAM_MAX] = {
    // ring buff 资源全局变量
    NULL,
};

///> 前置单目摄像头id
const int front_camera_id = 0;
static char storage_enable_oper_type = FALSE; //存储操作使能，测试用，开发者根据实际的业务逻辑来实现，如dp点来控制
static char vision_enable_oper_type = FALSE; //获取视频操作使能

// 设置存储操作使能
OPERATE_RET robotics_svc_media_save_control(bool oper_type)
{
    storage_enable_oper_type = oper_type;
    return 0;
}

// 设置视频操作使能
OPERATE_RET robotics_svc_media_vision_control(bool oper_type)
{
    vision_enable_oper_type = oper_type;
    return 0;
}

static void robotics_svc_media_sei_enable(bool_t enable) {
    g_pro_hdl.sei_enable = enable;
    PR_INFO("SEI Enable: %d", enable);
}

// bufSize:MAX_MEDIA_FRAME_SIZE  tkl_venc_get_frame(0, 0, &frame) 能获取到图像 tal_venc_get_frame == tkl_venc_get_frame
// bufSize:MAX_SNAPSHOT_BUFFER_SIZE  tal_venc_get_frame(0, 1, &frame) 不能获取到图像
// bufSize:MAX_MEDIA_FRAME_SIZE  tal_venc_get_frame(0, 1, &frame) 不能获取到图像
int get_h264(void* arg)
{
    UCHAR_T *frame_buff = NULL;
    TAL_VENC_FRAME_T frame = {0};
    int bufSize = MAX_MEDIA_FRAME_SIZE;
    const char *filename = "/tmp/tuya_image.h264";
    FILE *file;

    frame_buff = (UCHAR_T *)malloc(bufSize);
    if (NULL == frame_buff) {
        printf("malloc failed type = %d\n", 123);
        return -1;
    }
    frame.pbuf = (char *)frame_buff;
    frame.buf_size = bufSize;

    // 以二进制写入模式打开文件（如果不存在则创建，存在则覆盖）
    file = fopen(filename, "wb");
    if (file == NULL) {
        perror("Error opening file_jpeg");
        printf("can not open and create: %s\n", filename);
        return -1;
    }

    while(1)
    {
        memset(&frame, 0, sizeof(frame));
        frame.pbuf = (char *)frame_buff;
        frame.buf_size = bufSize;
        if (0 == tal_venc_get_frame(MEDIA_VI_CHN_NUMBER, MEDIA_VENC_CHN_NUMBER, &frame)) {
            // 写入数据
            size_t written = fwrite(frame.pbuf, 1, frame.used_size, file);
            if (written != frame.used_size) {
                printf("error write %zu bytes\n", written);
            } else {
                //printf("succeed write %zu bytes %s\n", written, filename);
            }
        } else {
            printf("error tkl_venc_get_frame != 0\n");
            usleep(10 * 1000);
        }
    }

    free(frame_buff);
    fclose(file);   // 关闭文件
    
    return 0;
}

/**
 * @brief 采集图像打包发送给nav sdk
 * @param[in] buffer: tkl采集的数据
 */
static void __pack_data_deal(TAL_VENC_FRAME_T* buffer)
{
    OPERATE_RET ret = 0;
    struct msg_robot_nav_image_sensor_s pub_data = { 0 };
    char encoding_buf[6] = "bgra8";

    struct timespec tsnow = {0};

    // u64ms = tsnow.tv_sec;
    // u64ms *= 1000ULL;
    // u64ms += tsnow.tv_nsec / (1000*1000);

    //pub_data.time_stamp = buffer->timestamp;
    
    clock_gettime(CLOCK_MONOTONIC, &tsnow);

    pub_data.time_stamp = (int64_t)tsnow.tv_sec * 1000000000L + tsnow.tv_nsec;
    pub_data.height = buffer->height;
    pub_data.width = buffer->width;
    pub_data.encoding = encoding_buf;
    pub_data.step = buffer->width * 4;

    pub_data.data = (unsigned char *)buffer->pbuf;

    // ret = tuya_robot_add_sensor_data(ROBOT_SENSOR_CAMERA, front_camera_id, &pub_data, sizeof(pub_data));
    // if (OPRT_OK != ret) {
    //     PR_ERR("camera data add to nav sdk err!");
    // }

    // 将采集到的视频数据放到ring buffer中，供后续存储使用
    if (s_ring_buffer_handles[E_IPC_STREAM_VIDEO_MAIN] == NULL) { //主视频流ring buffer空闲时，打开一个新的会话进行写入操作
        s_ring_buffer_handles[E_IPC_STREAM_VIDEO_MAIN] = tuya_ipc_ring_buffer_open(0, 0, E_IPC_STREAM_VIDEO_MAIN, E_RBUF_WRITE);
    }

    if (s_ring_buffer_handles[E_IPC_STREAM_VIDEO_MAIN]) { //新的会话打开之后，将原始视频流数据（来自tkl层）放到ring buffer中
        ret = tuya_ipc_ring_buffer_append_data(s_ring_buffer_handles[E_IPC_STREAM_VIDEO_MAIN], (UCHAR_T*)buffer->pbuf, buffer->used_size, buffer->frametype, buffer->pts);
        // PR_ERR("tuya_ipc_ring_buffer_append_data success,channle:%d,size:%d,pts:%d,ret:%d", E_IPC_STREAM_VIDEO_MAIN, buffer->used_size, buffer->pts, ret);
    } else {
        PR_ERR("tuya_ipc_ring_buffer_open failed,channle:%d\n", E_IPC_STREAM_VIDEO_MAIN);
    }

    return;
}

/**
 * @brief 获取一帧rgb数据
 * @param[in out] frame:  输出rgb数据帧
 * @return OPERATE_RET: 0 成功，其余错误码表示失败
 */
OPERATE_RET robotics_svc_media_pic_get(TKL_VENC_FRAME_T* frame)
{
    OPERATE_RET ret = 0;
    ret = tkl_venc_start(0, TKL_VENC_1);
	if (ret != 0) {
		PR_ERR("tkl_venc_start err : %d \n", ret);
		return;
	}

    while (1) {
        if (0 == tkl_venc_get_frame(0, TKL_VENC_1, frame)) {
            #if MEDIA_DEBUG_ENABLE
            // char filename[] = "/tuya/data/tuya_image/collect.bgra";
            // PR_ERR("save frame to %s\n", filename);
            // FILE *file = fopen(filename, "wb");
            // if (file == NULL) {
            //     PR_ERR("Error opening file_rgb");
            //     PR_ERR("can not open and create: %s\n", filename);
            //     return NULL;
            // }
            // size_t written = fwrite(frame->pbuf, 1, frame->used_size, file);
            // if (written != frame->used_size) {
            //     PR_INFO("error write %zu bytes\n", written);
            // } else {
            //     PR_INFO("succeed write %zu bytes %s\n", written, filename);
            //     fclose(file);   // 关闭文件
            //     // frame_count++;
            // }
            #endif
            break;
        }
    }

	ret = tkl_venc_stop(0, TKL_VENC_1);
	if (ret != 0) {
		PR_ERR("tkl_venc_stop err : %d \n", ret);
		return;
	}

    return OPRT_OK;
}


/**
 * @brief  图像采集处理线程 h264码流
 * @param  [void*] arg
 * @return [*]
 */
void* __sample_proc_task(void* arg)
{
    OPERATE_RET ret = 0;
    int timeout = -1;

    char* frame_buff = NULL;
    frame_buff = (char*)malloc(MEDIA_INUSE_BUFFER_SIZE + SEI_BUFFER_SIZE);
    if (NULL == frame_buff) {
        PR_ERR("monocular vision init malloc failed\n");
        return NULL;
    }
    g_pro_hdl.frame.pbuf = (char*)(frame_buff + SEI_BUFFER_SIZE); // 偏移指针，预留头部
    g_pro_hdl.frame.buf_size = MEDIA_INUSE_BUFFER_SIZE;

    char* sei_buffer = (char*)malloc(SEI_BUFFER_SIZE); 
    if (!sei_buffer) {
         free(frame_buff);
         PR_ERR("Failed to alloc sei buffer");
         return NULL;
    }

    BOOL_T is_det_running = FALSE; // Local state tracker

    PR_DEBUG("camera sample proc task begin___");

    while (1) {

        // 暂时不支持外部调用触发
        // if (!g_pro_hdl.sample_stat) {
        //     usleep(500000); // 500ms
        //     continue;
        // }

        if(vision_enable_oper_type == FALSE) {
            // Only call disable if it was previously enabled
            if (is_det_running) {
                det_task_set_enable(FALSE);
                is_det_running = FALSE;
            }
            usleep(500000); // 500ms
            continue;
        }

        uint64_t start_time = ty_time_tick_us();

        memset(g_pro_hdl.frame.pbuf, 0, g_pro_hdl.frame.buf_size);
        ret = tal_venc_get_frame(MEDIA_VI_CHN_NUMBER, MEDIA_VENC_CHN_NUMBER, &g_pro_hdl.frame);
        if (ret != 0) {
            PR_ERR("camera sample err : %d \n", ret);
            // continue;
        } else {
            // 成功获取到视频流后，开启目标检测流程 
            // SUCCESS: Only enable if not already running
            if (!is_det_running) {
                det_task_set_enable(TRUE);
                is_det_running = TRUE;
                PR_INFO("Detection task started.");
            }
            // g_pro_hdl.detect_stat = TRUE;
            // __pack_data_deal(&g_pro_hdl.frame);
            // // PR_ERR("do sample camera ok");

            int sei_len = 0;
            
            // SEI 尝试过：I 帧：必须插入，保证首帧即有数据；P 帧：降频插入（每5帧一次），减少开销，但app那边会导致闪烁
            // 每帧都插入 SEI
            sei_len = __embed_sei_to_frame(&g_pro_hdl.frame, sei_buffer, SEI_BUFFER_SIZE);
        
            if (sei_len > 0) {
                // 将 SEI 放在视频帧数据之前
                memcpy(g_pro_hdl.frame.pbuf - sei_len, sei_buffer, sei_len);
                
                __push_frame_to_buffer(E_IPC_STREAM_VIDEO_MAIN, 
                    (UCHAR_T*)(g_pro_hdl.frame.pbuf - sei_len), 
                    g_pro_hdl.frame.used_size + sei_len, 
                    g_pro_hdl.frame.frametype, 
                    g_pro_hdl.frame.pts);
            } else {
                // 无 SEI，直接推送
                __push_frame_to_buffer(E_IPC_STREAM_VIDEO_MAIN, 
                    (UCHAR_T*)g_pro_hdl.frame.pbuf, 
                    g_pro_hdl.frame.used_size, 
                    g_pro_hdl.frame.frametype, 
                    g_pro_hdl.frame.pts);
            }
        }
        
        uint64_t end_time = ty_time_tick_us();

        if (end_time - start_time > CAMERA_SAMPLE_TIME) {
            usleep(1);
        } else if (end_time - start_time < 0) {
            usleep(1);
        } else {
            #if MEDIA_DEBUG_ENABLE
            // PR_ERR("camera sample dur time : %d \n", end_time - start_time); 帧间隔约33ms
            // usleep(CAMERA_SAMPLE_TIME - (end_time - start_time)); // unit:ms
            #endif
        }
    }
    if (frame_buff != NULL) {
        free(frame_buff); //异常情况需释放buff,并关闭会话。
    }

    if (s_ring_buffer_handles[E_IPC_STREAM_VIDEO_MAIN] != NULL) { //关闭会话
        tuya_ipc_ring_buffer_close(s_ring_buffer_handles[E_IPC_STREAM_VIDEO_MAIN]);
    }
    PR_DEBUG("camera sample task end___");

    return NULL;
}

/**
 * @brief  注册摄像头到rockstar nav sdk
 * @return [*]
 */
static OPERATE_RET __camera_register_to_nav_sdk(void)
{
    OPERATE_RET ret = 0;

    char cmd[64] = { 0 };
    char buffer[64] = { 0 };
    char temp[64] = { 0 };
    int len = 64;
    float imu_roll = 0.0;
    float imu_pitch = 0.0;

#if 0 
    memset(buffer, 0, sizeof(buffer));
    snprintf(cmd, sizeof(cmd), "nvram get IMU_ROLL");  //从nvram中加载roll值及pitch值
    PR_DEBUG("shell set ->%s", cmd);
    if (0 != ty_cmd_excute_shell(cmd, buffer, &len)) {
        PR_ERR("get right wheel err");
    }
    if(len > 0) {
        float load_temp = 0.0;
        strcpy(temp, buffer);
        load_temp = (float)(atoi(temp) / 10000.0);
        if(IMU_ROLL_EFFECT_RANGE > fabs(load_temp)){
            imu_roll = load_temp;
            PR_DEBUG("get nvram imu_roll data = %0.4f",imu_roll);
        }
    }

    len = 64;
    memset(buffer, 0, sizeof(buffer));
    snprintf(cmd, sizeof(cmd), "nvram get IMU_PITCH");  //从nvram中加载roll值及pitch值
    PR_DEBUG("shell set ->%s", cmd);
    if (0 != ty_cmd_excute_shell(cmd, buffer, &len)) {
        PR_ERR("get right wheel err");
    }
    if(len > 0) {
        float load_temp = 0.0;
        strcpy(temp, buffer);
        load_temp = (float)(atoi(temp) / 10000.0);
        if(IMU_PITCH_EFFECT_RANGE > fabs(load_temp)){
            imu_pitch = load_temp;
            PR_DEBUG("get nvram  imu_roll data = %0.4f",imu_pitch);
        }
    }
#endif

    // float offset_x;  // 相对机器人中心x轴方向的坐标, 机器人正前方方向为x轴正方向, 单位m
    //     float offset_y;  // 相对机器人中心y轴方向的坐标, 机器人左侧方方向为y轴正方向，单位m
    //     float offset_z;  // 相对机器人中心z轴方向的坐标, 机器人上侧方方向为z轴正方向, 单位m
    //     float roll;      // 传感器的roll角， 单位rad
    //     float pitch;     // 传感器的pitch角， 单位rad
    //     float yaw;       // 传感器的yaw角， 单位rad

    // 登记单目摄像头到导航包
    struct msg_robot_nav_sensor_pose_s camera_pose = { 0.34, 0.0, 0.225, 0.0, 0.0, 0.0 };

    ret = tuya_robot_register_new_sensor(ROBOT_SENSOR_CAMERA, front_camera_id, &camera_pose);
    if (ret != OPRT_OK) {
        PR_ERR("register camer position err %d", ret);
        return OPRT_COM_ERROR;
    }

    //     struct msg_robot_nav_camera_info {
    //     unsigned int height;
    //     unsigned int width;
    //     char* distortion_model;       // 畸变模型
    //                                   // eg. plumb_bob 对应 D 5个参数
    //                                   // eg. rational_polynomial 对应 D 8个参数
    //                                   // eg. equidistant 鱼眼畸变校准 对应 D 4个参数
    //                                   // eg. kannala_brandt 广角和鱼眼 对应 D 4个参数
    //                                   // eg. scaramuzza 全景和鱼眼，对应 D n个参数
    //     int D_param_size;       // 畸变模型参数个数
    //     double* D;              // 畸变模型参数
    //     double K[9];            // 相机内参
    //                             //     [fx  0 cx]
    //                             // K = [ 0 fy cy]
    //                             //     [ 0  0  1]
    //     unsigned int binning_x;     // x方向上的合并因子 0 和 1 都 表示不合并 合并图像宽度为 width / binning_x
    //     unsigned int binning_y;     // x方向上的合并因子 0 和 1 都 表示不合并 合并图像宽度为 height / binning_y
    // };
    struct msg_robot_nav_camera_info camera_info = { 0 };
    camera_info.height = 896;
    camera_info.width = 672;
    camera_info.distortion_model = malloc(10);
    memcpy(camera_info.distortion_model, "plumb_bob", strlen("plumb_bob") + 1);
    PR_DEBUG("camera distorition model is %s", camera_info.distortion_model);
    camera_info.D_param_size = 5;
    camera_info.D = malloc(camera_info.D_param_size * sizeof(double));
    memset(camera_info.D, 0, (sizeof(double) * camera_info.D_param_size));

    camera_info.K[0] = 292.828;
    camera_info.K[1] = 0.0;
    camera_info.K[2] = 442.784;
    camera_info.K[3] = 0.0;
    camera_info.K[4] = 292.949;
    camera_info.K[5] = 336.805;
    camera_info.K[6] = 0.0;
    camera_info.K[7] = 0.0;
    camera_info.K[8] = 1.0;

    camera_info.D[0] = 0.00966626;
    camera_info.D[1] = -0.0112811;
    camera_info.D[2] = 0;
    camera_info.D[3] = -0.000818592;
    camera_info.D[4] = -0.00010548; 

    ret = tuya_robot_set_camera_info(front_camera_id, &camera_info);
    if (ret != OPRT_OK) {
        PR_ERR("register camer model err %d", ret);
        return OPRT_COM_ERROR;
    }

    // struct msg_robot_nav_camera_bev_model {
    //     double perspective_matrix[9];  // 透视变换矩阵
    //     double resolution;             // 透视变换后，图片每格像素的距离分辨率，单位米
    //     double origin_x;               // 透视变换后，图像原点的坐标x, 单位米
    //     double origin_y;               // 透视变换后，图像原点的坐标y, 单位米
    // };

    struct msg_robot_nav_camera_bev_model bev_model = { 0 };
    bev_model.resolution = 0.004;
    bev_model.origin_x = 2.775000;
    bev_model.origin_y = 1.664000;
    bev_model.perspective_matrix[0] = -0.1621195979433952;
    bev_model.perspective_matrix[1] = -1.233220621612862;
    bev_model.perspective_matrix[2] = 483.1985733475384;
    bev_model.perspective_matrix[3] = 4.45450982554884e-15;
    bev_model.perspective_matrix[4] = -2.02973736625134;
    bev_model.perspective_matrix[5] = 729.2577238408456;
    bev_model.perspective_matrix[6] = 7.084535344109867e-18;
    bev_model.perspective_matrix[7] = -0.002964472648107844;
    bev_model.perspective_matrix[8] = 1;

    ret = tuya_robot_set_camera_bev_model(front_camera_id, &bev_model);
    if (ret != OPRT_OK) {
        PR_ERR("register camer bev module err %d", ret);
        return OPRT_COM_ERROR;
    }

    return OPRT_OK;
}

/**
 * @brief 摄像头硬件初始化
 * @return OPERATE_RET: 0 成功，其余错误码表示失败
 */
OPERATE_RET robotics_svc_media_vision_init(void)
{
    OPERATE_RET ret = 0;

    #if 1
    ret = tal_vi_init(NULL, TY_DSP_MEDIA_VI_MAX); //底层TKL硬件视频采集初始化接口
    if (OPRT_OK != ret) {
        PR_ERR("ty_dsp_init failed,%d\n", ret);
        return ret;
    }

    ret = tal_venc_init(0, NULL, TY_DSP_MEDIA_VI_MAX); //底层TKL视频编码初始化接口
    if (OPRT_OK != ret) {
        PR_ERR("ty_dsp_init failed,%d\n", ret);
        return ret;
    }
    #else

    TKL_VI_CONFIG_T pvi = {
        .enable = TRUE,
        .chn = TKL_VI_0,
        .filp = 0,
        .mirror = 0,
        .isp = {
            .width = 640,
            .height = 360,
            .fps = 15,
        }
    };
    ret = tkl_vi_init(&pvi, TY_DSP_MEDIA_VI_MAX); //底层TKL硬件视频采集初始化接口
    if (OPRT_OK != ret) {
        PR_ERR("ty_dsp_init failed,%d\n", ret);
        return ret;
    }
    
    TKL_VENC_CONFIG_T config = {
        .enable = TRUE,
        .chn = TKL_VENC_0,
        .type = TKL_VENC_MAIN,
        .fps = 20,
        .gop = 40,
        .bitrate = 1024,
        .width = 1920,
        .height = 1080,
        .codectype = 4,
        .min_qp = 26,
        .max_qp = 48
    };
    ret = tkl_venc_init(0, &config, TY_DSP_MEDIA_VI_MAX); //底层TKL视频编码初始化接口
    if (OPRT_OK != ret) {
        PR_ERR("ty_dsp_init failed,%d\n", ret);
        return ret;
    }

    #endif

    return OPRT_OK;
}

/**
 * @brief  图像采集处理线程初始化
 * @param  [*]
 * @return [*]
 */
OPERATE_RET __vision_sample_thrd_init(void)
{
    OPERATE_RET ret = 0;
    pthread_attr_t attr;

    int size = 10 * 1024;
    struct sched_param param;
    /* 初始化属性 */
    pthread_attr_init(&attr);
    pthread_attr_setstacksize(&attr, size);

    /*设置优先级*/
    pthread_attr_getschedparam(&attr, &param);
    param.sched_priority = 99;
    pthread_attr_setschedparam(&attr, &param);
    #if MEDIA_DEBUG_ENABLE
        ret = pthread_create(&g_pro_hdl.sample_pid, &attr, get_h264, NULL);     // 调试代码
    #else
        ret = pthread_create(&g_pro_hdl.sample_pid, &attr, __sample_proc_task, NULL);
    #endif
    if (0 != ret) {
        PR_ERR("camera deal pthread create failed");
        g_pro_hdl.sample_pid = 0;
        pthread_attr_destroy(&attr);
        return -1;
    }

    cpu_set_t cpu_mask;
    CPU_ZERO(&cpu_mask);
    CPU_SET(0, &cpu_mask);
    pthread_setaffinity_np(g_pro_hdl.sample_pid, sizeof(cpu_mask), &cpu_mask);

    cpu_set_t cpu_check;
    pthread_getaffinity_np(g_pro_hdl.sample_pid, sizeof(cpu_check), &cpu_check);

    for (int j = 0; j < 4; j++) {
        if (CPU_ISSET(j, &cpu_check)) {
            PR_DEBUG("camera upload %d cpu %d", g_pro_hdl.sample_pid, j);
        }
    }

    g_pro_hdl.sample_stat = FALSE;

    pthread_attr_destroy(&attr);
    return OPRT_OK;
}

/**
 * @brief  单目视觉 采集开始
 * @return [*]
 */
OPERATE_RET robotics_svc_monocular_vision_open(void)
{
    OPERATE_RET ret = 0;

    ret = tkl_venc_start(MEDIA_VI_CHN_NUMBER, MEDIA_VENC_CHN_NUMBER);
    if (ret != OPRT_OK) {
        PR_ERR("monocular vision sample open err : %d", ret);
        return ret;
    }

    // 启动时间等待1s
	usleep(1000 * 1000);

    g_pro_hdl.sample_stat = TRUE;

    return OPRT_OK;
}

/**
 * @brief  单目视觉 采集停止
 * @return [*]
 */
OPERATE_RET robotics_svc_monocular_vision_close(void)
{
    OPERATE_RET ret = 0;

    ret = tkl_venc_stop(MEDIA_VI_CHN_NUMBER, MEDIA_VENC_CHN_NUMBER);
    if (ret != 0) {
        PR_ERR("monocular vision sample close err : %d", ret);
        return -1;
    }

    return OPRT_OK;
}

/**
 * @brief  音视频处理 服务初始化
 * @return [*]
 */
OPERATE_RET robotics_svc_media_proc_init(void)
{
    OPERATE_RET ret = 0;

    if (g_pro_hdl.init_flag) {
        PR_NOTICE("monocular vision have init!");
        return OPRT_OK;
    }

    ret = __camera_register_to_nav_sdk();
    if (ret != OPRT_OK) {
        PR_ERR("camera register to nav sdk err");
        return ret;
    }

    ret = robotics_svc_media_vision_init();
    if (ret != OPRT_OK) {
        PR_ERR("camera hardware init err");
        return ret;
    }

    ret = robotics_svc_media_audio_init();
    if (ret != OPRT_OK) {
        PR_ERR("camera hardware init err");
        return ret;
    }

    ret = __vision_sample_thrd_init();
    if (ret != OPRT_OK) {
        PR_ERR("camera sample thread init err");
        return ret;
    }

    // ret = __vision_detect_thrd_init();
    // if (ret != OPRT_OK) {
    //     PR_ERR("camera detect thread init err");
    //     return ret;
    // }

    #if MEDIA_DEBUG_ENABLE
        // Start_Audio_Output(); // 调试：测试放音功能
    #endif

    // ssu9386没有麦克风
    // ret = robotics_svc_media_audio_thrd_init();
    // if (ret != OPRT_OK) {
    //     PR_ERR("camera sample thread init err");
    //     return ret;
    // }

    // 预先开启 RingBuffer，确保推流时立即可用
    s_ring_buffer_handles[E_IPC_STREAM_VIDEO_MAIN] = tuya_ipc_ring_buffer_open(0, 0, E_IPC_STREAM_VIDEO_MAIN, E_RBUF_WRITE);
    // s_ring_buffer_handles[E_IPC_STREAM_VIDEO_SUB]  = tuya_ipc_ring_buffer_open(0, 0, E_IPC_STREAM_VIDEO_SUB,  E_RBUF_WRITE);
    s_ring_buffer_handles[E_IPC_STREAM_AUDIO_MAIN] = tuya_ipc_ring_buffer_open(0, 0, E_IPC_STREAM_AUDIO_MAIN, E_RBUF_WRITE);

    // 初始化检测任务(检测任务默认暂停)
    DET_TASK_CONFIG_T config = det_task_get_default_config();
    config.get_frame_cb = robotics_svc_media_pic_get;
    if (det_task_init(&config) != OPRT_OK) {
        PR_WARN("Detection task init failed, but stream continues");
    }

    robotics_svc_media_sei_enable(TRUE);

    g_pro_hdl.init_flag = TRUE;

    return OPRT_OK;
}

/**
 * @brief  启动存储任务
 * @param
 * @return [*]
 */
VOID* thread_md_proc(VOID* arg)
{
    int alarm_is_triggerd = FALSE;
    char snap_addr[MAX_SNAPSHOT_BUFFER_SIZE] = { 0 };
    int snap_size = MAX_SNAPSHOT_BUFFER_SIZE;
    while (1) {
        usleep(100 * 1000);
        if (storage_enable_oper_type) { //什么时候开启存储的逻辑，开发者自己做，如可以DP控制，也可以条件触发
            PR_ERR("ipc start storage event");
            if (!alarm_is_triggerd) {
                alarm_is_triggerd = TRUE;
                //启动“本地SD卡事件存储”和“云存储事件”
                tuya_ipc_start_storage(E_ALARM_SD_STORAGE); //启动本地SD卡存储,注意：SD卡存储，demo无法测试，需要硬件支持，开发者自行在硬件上验证。
                tuya_ipc_start_storage(E_ALARM_CLOUD_STORAGE); //启动云存储
                sweeper_app_get_snapshot(snap_addr, &snap_size); //获取一帧数据，视频的快照
                if (snap_size > 0) {
                    tuya_ipc_notify_alarm(snap_addr, snap_size, NOTIFICATION_NAME_MOTION, TRUE, NULL); //云存储的一个封面推送，查看云端视频时，不至于是空白封面。
                }
            } else {
                /*
                事件存储开启后，超过SDK中事件的最大时间会自动停止（默认最大600秒，可以通过tuya_ipc_ss_set_max_event_duration接口设置）。
                如果你需要维护存储长时间而不丢失，你可以使用以下接口，监控SDK中是否有停止事件视频，之后选择重新启动新事件。
                */
                if (SS_WRITE_MODE_EVENT == tuya_ipc_ss_get_write_mode() && E_STORAGE_STOP == tuya_ipc_ss_get_status()) { //有本地存储事件，但是处于暂停状态
                    tuya_ipc_start_storage(E_ALARM_SD_STORAGE); //重新开启
                }

                if (ClOUD_STORAGE_TYPE_EVENT == tuya_ipc_cloud_storage_get_store_mode() //有云存储事件，但是处于暂停状态
                    && FALSE == tuya_ipc_cloud_storage_get_status()) {
                    tuya_ipc_start_storage(E_ALARM_CLOUD_STORAGE); //重新开启
                }
            }
        } else {
            if (alarm_is_triggerd) { //已经开始有存储事件
                tuya_ipc_stop_storage(E_ALARM_SD_STORAGE); //暂停SD存储
                tuya_ipc_stop_storage(E_ALARM_CLOUD_STORAGE); //暂停云存储
                alarm_is_triggerd = FALSE;
            }
        }
    }
}

/**
 * @brief  创建存储任务
 * @param [*]
 * @return OPRT_OK on success. Others on error, please refer to tuya_error_code.h
 */
static OPERATE_RET tuya_enable_storage_deal(VOID)
{

    pthread_t enable_storage_thread;
    pthread_create(&enable_storage_thread, NULL, thread_md_proc, NULL);
    pthread_detach(enable_storage_thread);

    return OPRT_OK;
}

OPERATE_RET robotics_svc_media_init(void)
{
    OPERATE_RET ret = OPRT_OK;
    ret = robotics_svc_media_proc_init();
    if (ret != OPRT_OK) {
        PR_ERR("svc monocular vision init failed");
        return ret;
    }

    ret = tuya_enable_storage_deal(); //音视频存储任务
    if (ret != OPRT_OK) {
        return ret;
    }    
    return OPRT_OK;
}