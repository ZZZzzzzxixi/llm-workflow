#define _GNU_SOURCE
#include "ty_media_audio.h"
#include "tal_audio.h"
#include "ty_media_vision.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <uni_log.h>
#include <pthread.h>
#include <sched.h>
#include <tuya_ipc_media.h>
#include <tuya_ring_buffer.h>

#define MAX_AUDIO_FRAME_BUFFER_SIZE (640) ////音频一帧最大长度640，开发者根据自身的硬件来确定 16000*2/25=1280  8000*2/25=640 ak帧长:512(pcm),256(g711u)

extern SVC_CAMERA_CTRL_S g_pro_hdl;

extern RING_BUFFER_USER_HANDLE_T s_ring_buffer_handles[E_IPC_STREAM_MAX];

//放音测试
int Start_Audio_Output(void)
{
    TKL_AUDIO_FRAME_INFO_T tkl_frame = {0};
    char *pInPath = "/tmp/ai.pcm";
    printf("Open %s v777-- O_RDONLY \n", pInPath);

    static FILE *ao_file;
    ao_file = fopen(pInPath, "rb");
    if (!ao_file) {
        printf("ERROR: open file: %s fail, exit\n", pInPath);
        return -1;
    }
	// tkl_ao_start(0, 0, NULL);

    printf("%s initial finish\n", __func__);

	unsigned char *srcData = NULL;
	int srcSize = 0;
	int s32MilliSec = -1;
	srcData = calloc(1024, sizeof(unsigned char));
	memset(srcData, 0, 1024);
    
    while (1) {
		srcSize = fread(srcData, 1, 1024, ao_file); 
        tkl_frame.buf_size = srcSize;
        tkl_frame.pbuf = srcData;
		tkl_frame.used_size = srcSize;

		tkl_ao_put_frame(0, 0, NULL, &tkl_frame);
        if (srcSize <= 0) {
			printf("eof");
			//RK_MPI_AO_WaitEos(0, 0, s32MilliSec);
			break;
		}
	}

    if (ao_file) {
		fclose(ao_file);
		ao_file = NULL;
	}
	free(srcData);

    tkl_ao_uninit(NULL);

	return 0;
}

/**
 * @brief  启动音频流任务
 * @param
 * @return [*]
 */
void* __audio_sample_proc_task(void* arg)
{
    // const char *filename = "/tmp/tuya_audio.h264";
    // FILE *file;

    char* audio_buff = NULL;
    audio_buff = (char*)malloc(MAX_AUDIO_FRAME_BUFFER_SIZE); //音频一帧最大长度640字节
    if (NULL == audio_buff) {
        PR_ERR("audio init malloc failed\n");
        return NULL;
    }
    g_pro_hdl.audio_frame.pbuf = audio_buff;
    g_pro_hdl.audio_frame.buf_size = MAX_AUDIO_FRAME_BUFFER_SIZE;

    PR_DEBUG("camera audio proc task begin___");
    // // 以二进制写入模式打开文件（如果不存在则创建，存在则覆盖）
    // file = fopen(filename, "wb");
    // if (file == NULL) {
    //     perror("Error opening file_jpeg");
    //     printf("can not open and create: %s\n", filename);
    //     return -1;
    // }

    while (1) {
        /*获取到底层的音频流数据，该接口实际映射的是tkl_ai_get_frame,需要开发者去适配(可参考开发者文档)，
           demo中是强制把固定的数据放到tkl_ai_get_frame中，去实现播放的闭环。*/
        memset(g_pro_hdl.audio_frame.pbuf, 0, g_pro_hdl.audio_frame.buf_size);
        if (0 == tal_ai_get_frame(0, 0, &g_pro_hdl.audio_frame)) {
            if (s_ring_buffer_handles[E_IPC_STREAM_AUDIO_MAIN] == NULL) { //音频流ring buffer空闲时，打开一个新的会话进行写入操作
                s_ring_buffer_handles[E_IPC_STREAM_AUDIO_MAIN] = tuya_ipc_ring_buffer_open(0, 0, E_IPC_STREAM_AUDIO_MAIN, E_RBUF_WRITE);
            }

            if (s_ring_buffer_handles[E_IPC_STREAM_AUDIO_MAIN]) { //新的会话打开之后，将原始音频流数据放到ring buffer中
                OPERATE_RET ret = tuya_ipc_ring_buffer_append_data(s_ring_buffer_handles[E_IPC_STREAM_AUDIO_MAIN], (UCHAR_T*)g_pro_hdl.audio_frame.pbuf, g_pro_hdl.audio_frame.used_size,
                    g_pro_hdl.audio_frame.type, g_pro_hdl.audio_frame.pts);
                    if(ret != OPRT_OK)
                    {
                PR_ERR("tuya_ipc_ring_buffer_append_data success,channle:%d,size:%d,pts:%d,ret:%d", 
                    E_IPC_STREAM_VIDEO_MAIN, g_pro_hdl.audio_frame.used_size, g_pro_hdl.audio_frame.pts, ret);
                    }

            } else {
                PR_ERR("tuya_ipc_ring_buffer_open failed,channle:%d\n", E_IPC_STREAM_AUDIO_MAIN);
            }
            // size_t written = fwrite(g_pro_hdl.audio_frame.pbuf, 1, g_pro_hdl.audio_frame.used_size, file);
            // if (written != g_pro_hdl.audio_frame.used_size) {
            //     printf("error write %zu bytes\n", written);
            // } else {
            //     printf("succeed write %zu bytes %s\n", written, filename);
            // }
        } else {
            usleep(10 * 1000);
        }
    }
    if (audio_buff != NULL) {
        free(audio_buff); //异常情况需释放buff,并关闭会话。
    }
    
    if (s_ring_buffer_handles[E_IPC_STREAM_AUDIO_MAIN] != NULL) { //关闭会话
        tuya_ipc_ring_buffer_close(s_ring_buffer_handles[E_IPC_STREAM_AUDIO_MAIN]);
    }
    return NULL;
}

/**
 * @brief  音频采集处理线程初始化
 * @param  [*]
 * @return [*]
 */
OPERATE_RET robotics_svc_media_audio_thrd_init(void)
{
    OPERATE_RET ret = 0;
    pthread_attr_t attr;
  
    int size = 10 * 1024;
    struct sched_param param;
    /* 初始化属性 */
    pthread_attr_init(&attr);
    pthread_attr_setstacksize(&attr, size);

    /*设置优先级*/
    pthread_attr_getschedparam(&attr, &param);
    param.sched_priority = 99;
    pthread_attr_setschedparam(&attr, &param);

    ret = pthread_create(&g_pro_hdl.sample_pid, &attr, __audio_sample_proc_task, NULL);
    if (0 != ret) {
        PR_ERR("camera deal pthread create failed");
        g_pro_hdl.sample_pid = 0;
        pthread_attr_destroy(&attr);
        return -1;
    }

    cpu_set_t cpu_mask;
    CPU_ZERO(&cpu_mask);
    CPU_SET(0, &cpu_mask);
    pthread_setaffinity_np(g_pro_hdl.sample_pid, sizeof(cpu_mask), &cpu_mask);

    cpu_set_t cpu_check;
    pthread_getaffinity_np(g_pro_hdl.sample_pid, sizeof(cpu_check), &cpu_check);

    for (int j = 0; j < 4; j++) {
        if (CPU_ISSET(j, &cpu_check)) {
            PR_DEBUG("camera upload %d cpu %d", g_pro_hdl.sample_pid, j);
        }
    }

    pthread_attr_destroy(&attr);
    return OPRT_OK;
}

/**
 * @brief  音频初始化
 * @param  void
 * @return OPERATE_RET: 0 成功，其余错误码表示失败
 */
OPERATE_RET robotics_svc_media_audio_init(void)
{
    OPERATE_RET ret = 0;
    //TAL_AUDIO_CONFIG_T pconfig = { -1 };
    TAL_AUDIO_CONFIG_T pconfig = { 
        .enable = TRUE,
        .card = 0,
        .ai_chn = TKL_AI_0,
        .sample = 16000,
        .datebits = TUYA_AUDIO_DATABITS_16,
        .channel = TKL_AUDIO_CHANNEL_STEREO,// TKL_AUDIO_CHANNEL_MONO,
        .codectype = TKL_CODEC_AUDIO_PCM, // 相比下有修改 
        .fps = 25,
        .mic_volume = 50,
        .spk_volume = 50,
        .spk_volume_offset = 50,
        // .sec = -1
    };

    // 当前ssu9386板子没有麦克风，不在初始化音频采集
    // ret = tal_ai_init(&pconfig, TY_DSP_MEDIA_AUDIO_MAX); //底层TKL硬件音频采集初始化接口
    // if (OPRT_OK != ret) {
    //     PR_ERR("tal_ai_init failed,%d\n", ret);
    //     return ret;
    // }

    ret = tkl_ao_init(&pconfig, 1, NULL); //底层TKL硬件音频输出初始化接口
    if (OPRT_OK != ret) {
        PR_ERR("tkl_ao_init failed,%d\n", ret);
        return ret;
    }

    ret = tkl_ao_set_vol(0, 0, NULL, 80);
    if (OPRT_OK != ret) {
        PR_ERR("tkl_ao_set_vol failed,%d\n", ret);
        return ret;
    }

    ret = tkl_ao_start(0, 0, NULL);
    if (OPRT_OK != ret) {
        PR_ERR("tkl_ao_start failed,%d\n", ret);
        return ret;
    }

    return OPRT_OK;

}