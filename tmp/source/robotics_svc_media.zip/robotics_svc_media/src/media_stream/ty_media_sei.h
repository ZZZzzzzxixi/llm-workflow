#ifndef __MEDIA_SEI_H__
#define __MEDIA_SEI_H__


#ifdef __cplusplus
extern "C" {
#endif

#include "tkl_video_enc.h"
#include <tuya_cloud_types.h>

// SEI 相关定义
#define SEI_UUID_SIZE                16
#define NALU_H264_TYPE_SEI           6
#define SEI_PAYLOAD_TYPE_USER_DATA   5
#define SEI_BUFFER_SIZE              1024
#define SEI_LOG_INTERVAL             90 // SEI 日志打印间隔（约5-6秒）
#define MAX_DETECT_TARGETS           10 // SEI 中最大目标数限制

/**
 * @brief 在视频帧前嵌入 SEI
 */
int __embed_sei_to_frame(const TKL_VENC_FRAME_T* frame, char* sei_nalu, int sei_nalu_size);

/**
 * @brief 向 RingBuffer 推送数据
 */
void __push_frame_to_buffer(int stream_type, UCHAR_T* data, int size, int frame_type, uint64_t pts);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // __MEDIA_SEI_H__
