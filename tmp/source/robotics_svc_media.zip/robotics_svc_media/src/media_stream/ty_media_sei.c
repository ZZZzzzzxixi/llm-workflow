#include <string.h>
#include <stdio.h>
#include <uni_log.h>
#include <tuya_ring_buffer.h>
#include "ty_media_sei.h"
#include "ty_media_base.h"
#include "ty_media_vision.h"
#include "tal_time_service.h"
#include "object_detector_api.h"

static const char s_sei_uuid[SEI_UUID_SIZE] = {
    0xaa, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
    0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F
};

extern SVC_CAMERA_CTRL_S g_pro_hdl;

extern RING_BUFFER_USER_HANDLE_T s_ring_buffer_handles[E_IPC_STREAM_MAX];

/**
 * @brief 计算 H264 SEI NALU 大小
 */
int __get_h264_sei_nalu_size(int sei_info_size) {
    // 4(start) + 1(header) + 1(type) + size_bytes + UUID + content + 1(trailing)
    return 4 + 1 + 1 + (SEI_UUID_SIZE + sei_info_size) / 255 + 1 + SEI_UUID_SIZE + sei_info_size + 1;
}

/**
 * @brief 创建 H264 SEI NALU
 * @param[in] sei_info: SEI 信息内容
 * @param[in] sei_info_size: SEI 信息大小(bytes)
 * @param[out] nalu: 输出 NALU 缓冲区
 * @return NALU 字节数，0 表示失败
 */
int __create_h264_sei_nalu(const char* sei_info, int sei_info_size, char* nalu) {
    if (nalu == NULL || sei_info == NULL) return 0;

    char* data = nalu;

    // Start code prefix (00 00 00 01)
    *data++ = 0; *data++ = 0; *data++ = 0; *data++ = 1;
    
    // NALU Header (SEI type)
    *data++ = (NALU_H264_TYPE_SEI & 0x1F);
    
    // SEI payload type (User Data Unregistered)
    *data++ = SEI_PAYLOAD_TYPE_USER_DATA;
    
    // SEI payload size
    int sei_payload_size = SEI_UUID_SIZE + sei_info_size;
    while (sei_payload_size >= 255) {
        *data++ = 255;
        sei_payload_size -= 255;
    }
    *data++ = sei_payload_size;
    
    // UUID
    memcpy(data, s_sei_uuid, SEI_UUID_SIZE);
    data += SEI_UUID_SIZE;
    
    // SEI info content
    memcpy(data, sei_info, sei_info_size);
    data += sei_info_size;
    
    // RBSP trailing bits
    *data = 0x80;

    return (int)(data - nalu);
}

/**
 * @brief 生成智能分析结果 JSON
 * @param[in] chn: 通道号
 * @param[out] buf: 输出 JSON 缓冲区
 * @param[in] buf_size: 缓冲区大小
 * @return JSON 字节数，0 表示无目标或失败
 */
int __generate_sei_json(int chn, char* buf, int buf_size) {
    uint64_t now_ms = tal_time_get_posix_ms();
    DET_TRACK_TARGET_T targets[DET_MAX_TARGETS];

    // 获取用于显示的目标列表（优先预测，缓存回退）
    int count = det_tracker_get_display_targets(targets, DET_MAX_TARGETS, now_ms);

    #if MEDIA_DEBUG_ENABLE 
        // ========== 打印缩放前原始数据 ==========
        printf("\n===== before scale (chn=%d, 原图像尺寸896*672) =====\n", chn);
        for (int i = 0; i < count; i++) {
            if (targets[i].is_valid) {
                printf("ID=%d: x=%.2f, y=%.2f, width=%.2f, height=%.2f (is_valid=%d)\n",
                    targets[i].id, targets[i].x, targets[i].y,
                    targets[i].width, targets[i].height, targets[i].is_valid);
            } else {
                printf("ID=%d: invalid target)\n", targets[i].id);
            }
        }
    #endif

    // 2. 第一步：先剔除所有无效目标（单独循环，逻辑清晰）
    for (int i = 0; i < count; i++) {
        if (!targets[i].is_valid) { // 简化判断：!is_valid 直接处理
            PR_ERR("SEI invalid target id=%d", targets[i].id);
            // 剔除无效目标：后面的元素往前移
            for (int j = i; j < count - 1; j++) {
                targets[j] = targets[j + 1];
            }
            count--; // 有效目标数减1
            i--;     // 回退i，避免漏检下一个目标
        }
    }

    // 3. 第二步：统一缩放（仅执行1次，所有有效目标）
    // 缩放比例：目标图像尺寸 / 原图像尺寸（2048*1536 / 896*672）
    float scale_x = (float)2048 / (float)896;  // ≈2.285714
    float scale_y = (float)1536 / (float)672;  // ≈2.285714
    for (int k = 0; k < count; k++) {
        // 对有效目标的坐标/宽高统一缩放
        targets[k].x *= scale_x;
        targets[k].y *= scale_y;
        targets[k].width *= scale_x;
        targets[k].height *= scale_y;
        
        // 可选：防止缩放后坐标超出2048*1536图像范围（边界保护）
        targets[k].x = (targets[k].x < 0) ? 0 : targets[k].x;
        targets[k].y = (targets[k].y < 0) ? 0 : targets[k].y;
        targets[k].x = (targets[k].x > 2048) ? 2048 : targets[k].x;
        targets[k].y = (targets[k].y > 1536) ? 1536 : targets[k].y;
    }

    #if MEDIA_DEBUG_ENABLE 
        // ========== 打印缩放后数据（调试核心） ==========
        printf("\n===== after scale (目标图像2048*1536) =====\n");
        printf("scale ratio scale_x=%.4f (2048/896), scale_y=%.4f (1536/672)\n", scale_x, scale_y);
        for (int i = 0; i < count; i++) {
            printf("ID=%d: x=%.2f, y=%.2f, width=%.2f, height=%.2f\n",
                targets[i].id, targets[i].x, targets[i].y,
                targets[i].width, targets[i].height);
            // 额外打印目标框右下角坐标（便于验证是否在2048*1536内）
            printf("       right location:x=%.2f, y=%.2f\n",
                targets[i].x + targets[i].width, targets[i].y + targets[i].height);
        }
    #endif

    if (count <= 0) return 0;
    if (count > MAX_DETECT_TARGETS) count = MAX_DETECT_TARGETS;

    // 预估 JSON 长度，避免 buffer 溢出风险 (简单的过大截断保护在 snprintf 中已有)
    int offset = 0;
    
    // Header
    offset += snprintf(buf + offset, buf_size - offset,
        "{\"agtx\":{\"time\":%llu,\"chn\":%d,\"key\":1,\"v\":1,\"iva\":{\"od\":[",
        (unsigned long long)now_ms, chn);
        
    if (offset >= buf_size) return 0;

    // Objects
    for (int i = 0; i < count; i++) {
        DET_TRACK_TARGET_T* t = &targets[i];
        
        // 坐标取整
        int left = (int)t->x;
        int top = (int)t->y;
        int w = (int)t->width;
        int h = (int)t->height;
        int vx = (int)(t->vx * 1000);
        int vy = (int)(t->vy * 1000);

        int n = snprintf(buf + offset, buf_size - offset,
            "{\"obj\":{\"id\":%d,\"type\":0,\"rect\":[%d,%d,%d,%d],\"vel\":[%d,%d],\"cat\":\"PEDESTRIAN\"}}%s",
            t->id, left, top, left + w, top + h, vx, vy,
            (i < count - 1) ? "," : "");
            
        if (n < 0 || offset + n >= buf_size) break;
        offset += n;
    }

    int n = snprintf(buf + offset, buf_size - offset, "]}}}");
    if (n < 0 || offset + n >= buf_size) return 0; // JSON 不完整，弃用
    
    #if MEDIA_DEBUG_ENABLE 
        // ========== 新增：打印最终生成的JSON内容 ==========
        printf("\n===== final SEI JSON =====\n");
        printf("%s\n", buf);
        printf("=====================================\n");  
    #endif

    return offset + n;
}

/**
 * @brief 在视频帧前嵌入 SEI
 * @param[in] frame: 视频帧结构
 * @param[out] sei_nalu: SEI NALU 输出缓冲区
 * @param[in] sei_nalu_size: 缓冲区大小
 * @return SEI NALU 字节数，0 表示无需插入或失败
 */
int __embed_sei_to_frame(const TKL_VENC_FRAME_T* frame, char* sei_nalu, int sei_nalu_size) {
    if (!g_pro_hdl.sei_enable || !frame || !sei_nalu) 
    {
        PR_ERR("SEI not enabled or invalid parameters");;
        if(!g_pro_hdl.sei_enable) {
            PR_ERR("SEI not enabled\n");
        } else {
            if(!frame) PR_ERR("invalid frame pointer");
            if(!sei_nalu) PR_ERR("invalid parameters\n");
        }
        return 0;
    }

    char json_buf[SEI_BUFFER_SIZE]; // 栈上分配，注意栈大小
    // 生成 JSON
    int json_len = __generate_sei_json(0, json_buf, sizeof(json_buf));
    if (json_len <= 0) {
        PR_ERR("Generated SEI JSON length: %d", json_len);
        return 0;
    }

    // 封装 NALU
    int nalu_len = __create_h264_sei_nalu(json_buf, json_len, sei_nalu);
    if (nalu_len <= 0 || nalu_len > sei_nalu_size) {
        PR_ERR("Failed to create SEI NALU or buffer too small");
        return 0;
    }

    // 日志
    static int s_log_cnt = 0;
    if (++s_log_cnt >= SEI_LOG_INTERVAL) {
        s_log_cnt = 0;
        PR_ERR("SEI Embedded: JSON=%d bytes, NALU=%d bytes", json_len, nalu_len);
    }

    return nalu_len;
}

/**
 * @brief 向 RingBuffer 推送数据
 * @param[in] stream_type: 流类型
 * @param[in] data: 数据指针
 * @param[in] size: 数据大小
 * @param[in] frame_type: 帧类型(I/P)
 * @param[in] pts: 时间戳
 */
void __push_frame_to_buffer(int stream_type, UCHAR_T* data, int size, int frame_type, uint64_t pts) {
    RING_BUFFER_USER_HANDLE_T handle = s_ring_buffer_handles[stream_type];
    if (handle) {
        // PR_ERR("Pushing frame to ring buffer: stream=%d, size=%d, pts=%llu", stream_type, size, (unsigned long long)pts);
        tuya_ipc_ring_buffer_append_data(handle, data, size, frame_type, pts);
    }
}
