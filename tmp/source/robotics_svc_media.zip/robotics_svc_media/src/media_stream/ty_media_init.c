#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <uni_log.h>

#include <tuya_cloud_types.h>
#include <ty_rvc_sdk_init.h>
#include <tuya_ipc_media.h>
#include "ty_media_base.h"

#define MEDIA_RECORD_DURATION 2 // 视频录制时间 单位秒
#define MEDIA_PARAM_FILE_PATH "/tuya/data/"
#define MEDIA_PARAM_FILE_NAME "/tuya/data/media_sdk_params.ini"

static uint8_t file_exit_flag = 2; // 参数文件存在标志，0-不存在，1-存在，2-未检测
/**
 * @brief 保存音视频SDK参数到/tuya/data/media_sdk_params.ini
 * @param p_media_infos 待保存的媒体参数结构体指针
 * @return OPRT_OK-成功，OPRT_ERR-失败
 */
static OPERATE_RET save_media_sdk_params(const DEVICE_SDK_MEDIA_INFO_S *p_media_infos)
{
    if (p_media_infos == NULL) {
        PR_ERR("save_media_sdk_params: input param is NULL\n");
        return OPRT_COM_ERROR;
    }

    // 1. 检查/tuya/data目录是否存在，不存在则创建
    const char *dir_path = MEDIA_PARAM_FILE_PATH;
    struct stat st;
    if (stat(dir_path, &st) != 0) {
        if (mkdir(dir_path, 0755) != 0) {
            PR_ERR("save_media_sdk_params: create dir %s failed\n", dir_path);
            return OPRT_COM_ERROR;
        }
        PR_INFO("save_media_sdk_params: create dir %s success\n", dir_path);
    }

    // 2. 打开/创建参数文件（覆盖写入，调试用）
    const char *file_path = MEDIA_PARAM_FILE_NAME;
    FILE *fp = fopen(file_path, "w");
    if (fp == NULL) {
        PR_ERR("save_media_sdk_params: open file %s failed\n", file_path);
        return OPRT_COM_ERROR;
    }

    // 3. 写入参数（INI格式，分节存储，易读易改）
    // 3.1 主码流（高清）视频参数
    fprintf(fp, "[MAIN_VIDEO]\n");
    fprintf(fp, "stream_enable = %d\n", p_media_infos->av_encode_info.stream_enable[E_IPC_STREAM_VIDEO_MAIN]);
    fprintf(fp, "video_fps = %d\n", p_media_infos->av_encode_info.video_fps[E_IPC_STREAM_VIDEO_MAIN]);
    fprintf(fp, "video_gop = %d\n", p_media_infos->av_encode_info.video_gop[E_IPC_STREAM_VIDEO_MAIN]);
    fprintf(fp, "video_bitrate = %d\n", p_media_infos->av_encode_info.video_bitrate[E_IPC_STREAM_VIDEO_MAIN]);
    fprintf(fp, "video_width = %d\n", p_media_infos->av_encode_info.video_width[E_IPC_STREAM_VIDEO_MAIN]);
    fprintf(fp, "video_height = %d\n", p_media_infos->av_encode_info.video_height[E_IPC_STREAM_VIDEO_MAIN]);
    fprintf(fp, "video_freq = %d\n", p_media_infos->av_encode_info.video_freq[E_IPC_STREAM_VIDEO_MAIN]);
    fprintf(fp, "video_codec = %d\n", p_media_infos->av_encode_info.video_codec[E_IPC_STREAM_VIDEO_MAIN]);
    fprintf(fp, "\n");

    // 3.2 子码流（标清）视频参数
    fprintf(fp, "[SUB_VIDEO]\n");
    fprintf(fp, "stream_enable = %d\n", p_media_infos->av_encode_info.stream_enable[E_IPC_STREAM_VIDEO_SUB]);
    fprintf(fp, "video_fps = %d\n", p_media_infos->av_encode_info.video_fps[E_IPC_STREAM_VIDEO_SUB]);
    fprintf(fp, "video_gop = %d\n", p_media_infos->av_encode_info.video_gop[E_IPC_STREAM_VIDEO_SUB]);
    fprintf(fp, "video_bitrate = %d\n", p_media_infos->av_encode_info.video_bitrate[E_IPC_STREAM_VIDEO_SUB]);
    fprintf(fp, "video_width = %d\n", p_media_infos->av_encode_info.video_width[E_IPC_STREAM_VIDEO_SUB]);
    fprintf(fp, "video_height = %d\n", p_media_infos->av_encode_info.video_height[E_IPC_STREAM_VIDEO_SUB]);
    fprintf(fp, "video_freq = %d\n", p_media_infos->av_encode_info.video_freq[E_IPC_STREAM_VIDEO_SUB]);
    fprintf(fp, "video_codec = %d\n", p_media_infos->av_encode_info.video_codec[E_IPC_STREAM_VIDEO_SUB]);
    fprintf(fp, "\n");

    // 3.3 音频主流参数
    fprintf(fp, "[MAIN_AUDIO]\n");
    fprintf(fp, "stream_enable = %d\n", p_media_infos->av_encode_info.stream_enable[E_IPC_STREAM_AUDIO_MAIN]);
    fprintf(fp, "audio_codec = %d\n", p_media_infos->av_encode_info.audio_codec[E_IPC_STREAM_AUDIO_MAIN]);
    fprintf(fp, "audio_sample = %d\n", p_media_infos->av_encode_info.audio_sample[E_IPC_STREAM_AUDIO_MAIN]);
    fprintf(fp, "audio_databits = %d\n", p_media_infos->av_encode_info.audio_databits[E_IPC_STREAM_AUDIO_MAIN]);
    fprintf(fp, "audio_channel = %d\n", p_media_infos->av_encode_info.audio_channel[E_IPC_STREAM_AUDIO_MAIN]);
    fprintf(fp, "audio_fps = %d\n", p_media_infos->av_encode_info.audio_fps[E_IPC_STREAM_AUDIO_MAIN]);
    fprintf(fp, "\n");

    // 3.4 音频解码参数
    fprintf(fp, "[AUDIO_DECODE]\n");
    fprintf(fp, "enable = %d\n", p_media_infos->audio_decode_info.enable);
    fprintf(fp, "audio_codec = %d\n", p_media_infos->audio_decode_info.audio_codec);
    fprintf(fp, "audio_sample = %d\n", p_media_infos->audio_decode_info.audio_sample);
    fprintf(fp, "audio_databits = %d\n", p_media_infos->audio_decode_info.audio_databits);
    fprintf(fp, "audio_channel = %d\n", p_media_infos->audio_decode_info.audio_channel);
    fprintf(fp, "\n");

    // 4. 刷新并关闭文件
    fflush(fp);
    fclose(fp);

    PR_INFO("save_media_sdk_params: save params to %s success\n", file_path);
    return OPRT_OK;
}

// 先读取默认值
static void ty_robot_media_default_param_read(DEVICE_SDK_MEDIA_INFO_S *p_media_infos)
{
    /* 媒体信息（必需）*/
    /* 主码流（高清），视频配置*/
    /* 注意：首先：如果主码流支持多个视频流配置，将每个项目设置为允许配置的上限。
       其次：E_IPC_STREAM_VIDEO_MAIN必须存在。这是SDK的数据来源。
    */
    // h264下的分辨率是640*360，360-height; bgra下的分辨率是896*672，672-height
    p_media_infos->av_encode_info.stream_enable[E_IPC_STREAM_VIDEO_MAIN] = TRUE; /* 是否启用本地高清录像流 */
    p_media_infos->av_encode_info.video_fps[E_IPC_STREAM_VIDEO_MAIN] = 30; /* FPS */ //一秒钟内连续播放的30帧
    p_media_infos->av_encode_info.video_gop[E_IPC_STREAM_VIDEO_MAIN] = 30; /* GOP */ //关键帧，该值的大小影响视频解密的效率及质量
    p_media_infos->av_encode_info.video_bitrate[E_IPC_STREAM_VIDEO_MAIN] = TUYA_VIDEO_BITRATE_1M; /* 传输速率 */
    p_media_infos->av_encode_info.video_width[E_IPC_STREAM_VIDEO_MAIN] = MEDIA_PICTURE_WIDTH; /* 单帧分辨率的宽度*/
    p_media_infos->av_encode_info.video_height[E_IPC_STREAM_VIDEO_MAIN] = MEDIA_PICTURE_HEIGHT; /* 单帧分辨率的高度 */
    p_media_infos->av_encode_info.video_freq[E_IPC_STREAM_VIDEO_MAIN] = 90000; /* 摄像头的时钟频率 */
    p_media_infos->av_encode_info.video_codec[E_IPC_STREAM_VIDEO_MAIN] = TUYA_CODEC_VIDEO_H264; /* 编码方式 */

    /*
    子流(标清)，视频配置。请注意，如果子流支持多个视频流配置，请将每个项设置为允许配置的上限。
    */
    p_media_infos->av_encode_info.stream_enable[E_IPC_STREAM_VIDEO_SUB] = TRUE; /* 是否启用本地标清录像流 */
    p_media_infos->av_encode_info.video_fps[E_IPC_STREAM_VIDEO_SUB] = 30; /* FPS */ //一秒钟内连续播放的30帧
    p_media_infos->av_encode_info.video_gop[E_IPC_STREAM_VIDEO_SUB] = 30; /* GOP */ //关键帧，该值的大小影响视频解密的效率及质量
    p_media_infos->av_encode_info.video_bitrate[E_IPC_STREAM_VIDEO_SUB] = TUYA_VIDEO_BITRATE_512K; /* 传输速率 */
    p_media_infos->av_encode_info.video_width[E_IPC_STREAM_VIDEO_SUB] = MEDIA_PICTURE_WIDTH; /* 单帧分辨率的宽度 */
    p_media_infos->av_encode_info.video_height[E_IPC_STREAM_VIDEO_SUB] = MEDIA_PICTURE_HEIGHT; /* 单帧分辨率的高度 */
    p_media_infos->av_encode_info.video_freq[E_IPC_STREAM_VIDEO_SUB] = 90000; /* 摄像头的时钟频率 */
    p_media_infos->av_encode_info.video_codec[E_IPC_STREAM_VIDEO_SUB] = TUYA_CODEC_VIDEO_H264; /* 编码方式 */

    /*
    音频流编解码配置。
    注:SDK的内部P2P预览、云存储、本地存储均使用E_IPC_STREAM_AUDIO_MAIN数据。
    */
    p_media_infos->av_encode_info.stream_enable[E_IPC_STREAM_AUDIO_MAIN] = TRUE; /* 是否启用本地声音采集 */
    p_media_infos->av_encode_info.audio_codec[E_IPC_STREAM_AUDIO_MAIN] = TUYA_CODEC_AUDIO_PCM; /* 编码方式 */
    p_media_infos->av_encode_info.audio_sample[E_IPC_STREAM_AUDIO_MAIN] = TUYA_AUDIO_SAMPLE_16K; /* 音频采样率 */
    p_media_infos->av_encode_info.audio_databits[E_IPC_STREAM_AUDIO_MAIN] = TUYA_AUDIO_DATABITS_16; /* 音频位宽 */
    p_media_infos->av_encode_info.audio_channel[E_IPC_STREAM_AUDIO_MAIN] = TUYA_AUDIO_CHANNEL_STERO; /* 音频通道 */
    p_media_infos->av_encode_info.audio_fps[E_IPC_STREAM_AUDIO_MAIN] = 25; /* 一秒钟内连续播放的25帧 */

    p_media_infos->audio_decode_info.enable = TRUE;
    p_media_infos->audio_decode_info.audio_codec = TUYA_CODEC_AUDIO_PCM; /*解码方式*/
    p_media_infos->audio_decode_info.audio_sample = TUYA_AUDIO_SAMPLE_16K; /* 音频采样率 */
    p_media_infos->audio_decode_info.audio_databits = TUYA_AUDIO_DATABITS_16; /* 音频位宽 */
    p_media_infos->audio_decode_info.audio_channel = TUYA_AUDIO_CHANNEL_STERO; /* 音频通道 */
}

// 从文件读取参数
static OPERATE_RET ty_robot_media_file_param_read(DEVICE_SDK_MEDIA_INFO_S *p_media_infos)
{
    // 检查参数文件是否存在，不存在则使用默认值返回
    const char *file_path = MEDIA_PARAM_FILE_PATH;
    if (access(file_path, F_OK) != 0) {
        file_exit_flag = 0;
        PR_INFO("load_media_sdk_params: file %s not exist, use default params\n", file_path);
        return OPRT_OK;
    }

    // 打开参数文件（只读）
    FILE *fp = fopen(file_path, "r");
    if (fp == NULL) {
        PR_ERR("load_media_sdk_params: open file %s failed, use default params\n", file_path);
        return OPRT_OK;
    }

    file_exit_flag = 1;
    // 逐节读取参数（覆盖默认值）
    char line[256];
    int section = 0;  // 0-未识别节，1-MAIN_VIDEO，2-SUB_VIDEO，3-MAIN_AUDIO，4-AUDIO_DECODE
    while (fgets(line, sizeof(line), fp) != NULL) {
        // 跳过空行和注释行
        if (line[0] == '\n' || line[0] == ';' || line[0] == '#') {
            continue;
        }

        // 识别节标识
        if (strstr(line, "[MAIN_VIDEO]")) {
            section = 1;
            continue;
        } else if (strstr(line, "[SUB_VIDEO]")) {
            section = 2;
            continue;
        } else if (strstr(line, "[MAIN_AUDIO]")) {
            section = 3;
            continue;
        } else if (strstr(line, "[AUDIO_DECODE]")) {
            section = 4;
            continue;
        }

        // 读取各节参数（按key-value格式解析）
        int value = 0;
        if (section == 1) {  // MAIN_VIDEO
            if (sscanf(line, "stream_enable = %d", &value) == 1) {
                p_media_infos->av_encode_info.stream_enable[E_IPC_STREAM_VIDEO_MAIN] = value;
            } else if (sscanf(line, "video_fps = %d", &value) == 1) {
                p_media_infos->av_encode_info.video_fps[E_IPC_STREAM_VIDEO_MAIN] = value;
            } else if (sscanf(line, "video_gop = %d", &value) == 1) {
                p_media_infos->av_encode_info.video_gop[E_IPC_STREAM_VIDEO_MAIN] = value;
            } else if (sscanf(line, "video_bitrate = %d", &value) == 1) {
                p_media_infos->av_encode_info.video_bitrate[E_IPC_STREAM_VIDEO_MAIN] = value;
            } else if (sscanf(line, "video_width = %d", &value) == 1) {
                p_media_infos->av_encode_info.video_width[E_IPC_STREAM_VIDEO_MAIN] = value;
            } else if (sscanf(line, "video_height = %d", &value) == 1) {
                p_media_infos->av_encode_info.video_height[E_IPC_STREAM_VIDEO_MAIN] = value;
            } else if (sscanf(line, "video_freq = %d", &value) == 1) {
                p_media_infos->av_encode_info.video_freq[E_IPC_STREAM_VIDEO_MAIN] = value;
            } else if (sscanf(line, "video_codec = %d", &value) == 1) {
                p_media_infos->av_encode_info.video_codec[E_IPC_STREAM_VIDEO_MAIN] = (TUYA_CODEC_ID_E)value;
            }
        } else if (section == 2) {  // SUB_VIDEO
            if (sscanf(line, "stream_enable = %d", &value) == 1) {
                p_media_infos->av_encode_info.stream_enable[E_IPC_STREAM_VIDEO_SUB] = value;
            } else if (sscanf(line, "video_fps = %d", &value) == 1) {
                p_media_infos->av_encode_info.video_fps[E_IPC_STREAM_VIDEO_SUB] = value;
            } else if (sscanf(line, "video_gop = %d", &value) == 1) {
                p_media_infos->av_encode_info.video_gop[E_IPC_STREAM_VIDEO_SUB] = value;
            } else if (sscanf(line, "video_bitrate = %d", &value) == 1) {
                p_media_infos->av_encode_info.video_bitrate[E_IPC_STREAM_VIDEO_SUB] = value;
            } else if (sscanf(line, "video_width = %d", &value) == 1) {
                p_media_infos->av_encode_info.video_width[E_IPC_STREAM_VIDEO_SUB] = value;
            } else if (sscanf(line, "video_height = %d", &value) == 1) {
                p_media_infos->av_encode_info.video_height[E_IPC_STREAM_VIDEO_SUB] = value;
            } else if (sscanf(line, "video_freq = %d", &value) == 1) {
                p_media_infos->av_encode_info.video_freq[E_IPC_STREAM_VIDEO_SUB] = value;
            } else if (sscanf(line, "video_codec = %d", &value) == 1) {
                p_media_infos->av_encode_info.video_codec[E_IPC_STREAM_VIDEO_SUB] = (TUYA_CODEC_ID_E)value;
            }
        } else if (section == 3) {  // MAIN_AUDIO
            if (sscanf(line, "stream_enable = %d", &value) == 1) {
                p_media_infos->av_encode_info.stream_enable[E_IPC_STREAM_AUDIO_MAIN] = value;
            } else if (sscanf(line, "audio_codec = %d", &value) == 1) {
                p_media_infos->av_encode_info.audio_codec[E_IPC_STREAM_AUDIO_MAIN] = value;
            } else if (sscanf(line, "audio_sample = %d", &value) == 1) {
                p_media_infos->av_encode_info.audio_sample[E_IPC_STREAM_AUDIO_MAIN] = value;
            } else if (sscanf(line, "audio_databits = %d", &value) == 1) {
                p_media_infos->av_encode_info.audio_databits[E_IPC_STREAM_AUDIO_MAIN] = value;
            } else if (sscanf(line, "audio_channel = %d", &value) == 1) {
                p_media_infos->av_encode_info.audio_channel[E_IPC_STREAM_AUDIO_MAIN] = value;
            } else if (sscanf(line, "audio_fps = %d", &value) == 1) {
                p_media_infos->av_encode_info.audio_fps[E_IPC_STREAM_AUDIO_MAIN] = value;
            }
        } else if (section == 4) {  // AUDIO_DECODE
            if (sscanf(line, "enable = %d", &value) == 1) {
                p_media_infos->audio_decode_info.enable = value;
            } else if (sscanf(line, "audio_codec = %d", &value) == 1) {
                p_media_infos->audio_decode_info.audio_codec = (TUYA_CODEC_ID_E)value;
            } else if (sscanf(line, "audio_sample = %d", &value) == 1) {
                p_media_infos->audio_decode_info.audio_sample = (TUYA_AUDIO_SAMPLE_E)value;
            } else if (sscanf(line, "audio_databits = %d", &value) == 1) {
                p_media_infos->audio_decode_info.audio_databits = (TUYA_AUDIO_DATABITS_E)value;
            } else if (sscanf(line, "audio_channel = %d", &value) == 1) {
                p_media_infos->audio_decode_info.audio_channel = (TUYA_AUDIO_CHANNEL_E)value;
            }
        }
    }

    // 关闭文件
    fclose(fp);

    PR_INFO("load_media_sdk_params: load params from %s success\n", file_path);
    return OPRT_OK;
}

static OPERATE_RET ty_robot_media_sdk_init(void)
{
    OPERATE_RET ret = OPRT_OK;
    //适配多媒体接口
    TY_SDK_MEDIA_ADAPTER_S p_media_adatper_info = { 0 }; //音视频接口回调
    DEVICE_SDK_MEDIA_INFO_S p_media_infos = { 0 }; //音视频编解码参数

    ty_robot_media_default_param_read(&p_media_infos);

    // 暂时不写入文件
    // ret = ty_robot_media_file_param_read(&p_media_infos);
    // if (OPRT_OK != ret) {
    //     PR_ERR("media sdk file read error\n");
    //     return ret;
    // }

    p_media_adatper_info.rev_audio_cb = tuya_sweeper_app_rev_audio_cb; //接收音频参数
    p_media_adatper_info.rev_video_cb = tuya_sweeper_app_rev_video_cb; //接收视频参数
    p_media_adatper_info.rev_file_cb = tuya_sweeper_app_rev_file_cb; // APP下载文件到设备端
    p_media_adatper_info.get_snapshot_cb = tuya_sweeper_app_get_snapshot_cb; //音视频数据通过该接口上传，有SDK实现本地或者云端的存储

    ty_rvc_media_adapter_init(&p_media_adatper_info, &p_media_infos); //带音视频扫地机，初始化媒体抽象层

    ret = ty_rvc_media_ring_buffer_init(&p_media_infos, 0, 0); //音视频ring buffer初始化
    if (OPRT_OK != ret) {
        PR_ERR("create ring buffer is error\n");
        return ret;
    }
    ret = ty_rvc_media_av_event_init(tuya_sweeper_av_event_cb); //注册音视频上报P2P事件
    if (OPRT_OK != ret) {
        PR_ERR("tuya sweeper event failed\n");
        return ret;
    }

    // ========== 调试用 - 保存参数到文件（验证参数是否正确） ==========
    if (file_exit_flag == 0) {
        PR_INFO("media sdk param file not exist, save default params to file\n");
        ret = save_media_sdk_params(&p_media_infos);
        if (OPRT_OK != ret) {
            PR_ERR("tuya sweeper event failed\n");
            return ret;
        }
    }

    return ret;
}

/**
 * @brief  ty media 本地存储处理
 * @param  [*]
 * @return OPRT_OK on success. Others on error, please refer to tuya_error_code.h
 */
static OPERATE_RET ty_robot_media_local_storage(void)
{
    #define MAX_EVENT_PER_DAY 500 //最大存储500天，用户根据自己的SD大小设置
    OPERATE_RET ret = OPRT_OK;
    static BOOL_T s_stream_storage_inited = FALSE;
    char* mount_path = tuya_ipc_get_sd_mount_path(); //获取sd卡存储路径

    if (s_stream_storage_inited == TRUE) {
        PR_INFO("The Stream Storage Is Already Inited");
        return OPRT_OK;
    }
    TUYA_IPC_STORAGE_VAR_T stg_var;
    memset(&stg_var, 0, sizeof(TUYA_IPC_STORAGE_VAR_T));
    strncpy(stg_var.base_path, MEDIA_PARAM_FILE_PATH, SS_BASE_PATH_LEN); //路径
    strncpy(mount_path, MEDIA_PARAM_FILE_PATH, SS_BASE_PATH_LEN);
    stg_var.max_event_per_day = MAX_EVENT_PER_DAY; //录制天数
    stg_var.sd_status_changed_cb = tuya_robot_sd_status_upload; //状态回调
    stg_var.skills = 0; //默认回放倍速全部支持
    // stg_var.skills = TUYA_IPC_SKILL_BASIC | TUYA_IPC_SKILL_DELETE_BY_DAY | TUYA_IPC_SKILL_SPEED_PLAY_0Point5 | TUYA_IPC_SKILL_SPEED_PLAY_2 | TUYA_IPC_SKILL_SPEED_PLAY_4 | TUYA_IPC_SKILL_SPEED_PLAY_8 ;
    PR_INFO("Init Stream_Storage SD:%s", MEDIA_PARAM_FILE_PATH);
    ret = tuya_ipc_ss_init(&stg_var); // sd卡初始化
    if (ret != OPRT_OK) {
        PR_ERR("Init Main Video Stream_Storage Fail. %d", ret);
        return OPRT_COM_ERROR;
    }
    s_stream_storage_inited = TRUE;
    return OPRT_OK;
}

/**
 * @brief  云端存储初始化
 * @param  [INT_T] en_audio_mode 设置音频开关
 * @param  [INT_T] pre_recode_time  录制时长
 * @return OPRT_OK on success. Others on error, please refer to tuya_error_code.h
 */
static OPERATE_RET ty_robot_media_cloud_storage(INT_T en_audio_mode, INT_T pre_recode_time)
{
    OPERATE_RET ret = 0;
    PR_INFO("Init cloud_storage start");
    ret = tuya_ipc_cloud_storage_init(); //云存储初始化
    if (ret != OPRT_OK) {
        PR_ERR("Cloud Storage Init Err! ret :%d", ret);
        return ret;
    }

    if (en_audio_mode == TRUE) {
        tuya_ipc_cloud_storage_set_audio_stat(en_audio_mode); //设置云端音频录制标识
        PR_INFO("Enable audio record");
    }

    if (pre_recode_time >= 0) {
        ret = tuya_ipc_cloud_storage_set_pre_record_time(pre_recode_time); //设置预录时间，默认预录时间：2秒。
        PR_ERR("Set pre-record time to [%d], [%s]", pre_recode_time, ret == OPRT_OK ? "success" : "failure");
    }
    return OPRT_OK;
}


static OPERATE_RET ty_robot_media_storage_init(void)
{
    OPERATE_RET ret = OPRT_OK;

    PR_ERR("ty robot media storage init start\n");

    // ret = ty_robot_media_local_storage();
    // if (OPRT_OK != ret) {
    //     PR_ERR("ty robot media init failed\n");
    //     return ret;
    // }

    ret = ty_robot_media_cloud_storage(TRUE, MEDIA_RECORD_DURATION);
    if (OPRT_OK != ret) {
        PR_ERR("ty robot media storage init failed\n");
        return ret;
    }
    return ret;
}

OPERATE_RET ty_robot_media_init(void)
{
    OPERATE_RET ret = OPRT_OK;

    PR_INFO("ty robot media init start\n");

    ret = ty_robot_media_sdk_init();
    if (OPRT_OK != ret) {
        PR_ERR("ty robot media init failed\n");
        return ret;
    }

    ret = ty_robot_media_storage_init();
    if (OPRT_OK != ret) {
        PR_ERR("ty robot media storage init failed\n");
        return ret;
    }

    PR_INFO("ty robot media init end\n");

    return ret;
}