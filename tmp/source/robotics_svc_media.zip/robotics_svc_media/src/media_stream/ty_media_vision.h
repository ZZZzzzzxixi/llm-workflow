#ifndef __MEDIA_VISION_H__
#define __MEDIA_VISION_H__


#ifdef __cplusplus
extern "C" {
#endif

#include <pthread.h>
#include <tuya_cloud_types.h>
#include "tal_audio.h"
#include "tal_video_enc.h"

/**
 * @brief 单目摄像头服务控制句柄结构体
 */
typedef struct {
    pthread_t sample_pid;
    int init_flag; // 初始化标识
    int sample_stat; // 采集运行状态
    int detect_stat; // 检测运行状态
    TAL_VENC_FRAME_T frame; // 图像帧结构体
    TAL_AUDIO_FRAME_INFO_T audio_frame; // 音频帧结构体
    TAL_VENC_FRAME_T detect_frame; // 用于目标检测的图像帧结构体
} SVC_CAMERA_CTRL_S;

// 设置存储操作使能
OPERATE_RET robotics_svc_media_save_control(bool oper_type);

// 设置视频操作使能
OPERATE_RET robotics_svc_media_vision_control(bool oper_type);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // __MEDIA_VISION_H__

